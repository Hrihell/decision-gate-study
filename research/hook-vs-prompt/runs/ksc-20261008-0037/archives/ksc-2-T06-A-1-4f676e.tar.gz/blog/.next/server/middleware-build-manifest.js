globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Vbv7oRHV8Bs77j0lNDKKk/_buildManifest.js",
    "static/Vbv7oRHV8Bs77j0lNDKKk/_ssgManifest.js",
    "static/Vbv7oRHV8Bs77j0lNDKKk/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/2r4s4h5xul1n-.js",
    "static/chunks/3dmm3v_fq28gc.js",
    "static/chunks/0rm4bmi_uaeqm.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/3dmm3v_fq28gc.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/3dmm3v_fq28gc.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/3dmm3v_fq28gc.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/posts/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/3dmm3v_fq28gc.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
