module.exports=[20635,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},43285,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/dynamic-access-async-storage.external.js",()=>require("next/dist/server/app-render/dynamic-access-async-storage.external.js"))},56704,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(a,b,c)=>{b.exports=a.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},67555,a=>{"use strict";let b=[{id:"first-post",title:"Next.js 블로그 시작하기",date:"2026-10-08",excerpt:"Next.js를 사용해서 간단한 블로그를 만들어보았습니다.",author:"Admin",content:`
# Next.js 블로그 시작하기

Next.js는 React 기반의 강력한 프레임워크입니다.

## 주요 특징

- **서버 사이드 렌더링**: SEO 최적화
- **정적 생성**: 빠른 로딩 속도
- **API 라우트**: 백엔드 없이 API 구현 가능
- **자동 최적화**: 이미지, 폰트 자동 최적화

## 블로그 구축

이 블로그는 Next.js의 App Router를 사용하여 구축되었습니다.
간단하고 효율적인 구조로 블로그를 시작할 수 있습니다.

더 많은 포스트를 작성해보세요!
    `},{id:"second-post",title:"React 강력한 라이브러리",date:"2026-10-07",excerpt:"React는 현대적인 웹 개발의 표준입니다.",author:"Admin",content:`
# React 강력한 라이브러리

React는 Facebook에서 개발한 JavaScript 라이브러리입니다.

## React의 장점

- **컴포넌트 기반**: 재사용 가능한 UI 컴포넌트
- **선언형 프로그래밍**: 더 직관적인 코드 작성
- **효율적인 렌더링**: Virtual DOM을 통한 최적화

## 상태 관리

React Hooks를 사용하면 함수형 컴포넌트에서도
복잡한 상태 관리를 쉽게 할 수 있습니다.

useState, useEffect, useContext 등 다양한 hooks를 활용하세요!
    `},{id:"third-post",title:"JavaScript 핵심 개념",date:"2026-10-06",excerpt:"JavaScript의 핵심 개념들을 알아봅니다.",author:"Admin",content:`
# JavaScript 핵심 개념

JavaScript는 웹 개발의 필수 언어입니다.

## 중요한 개념들

### 클로저 (Closure)
내부 함수가 외부 함수의 변수에 접근하는 메커니즘

### 프로토타입 (Prototype)
JavaScript의 상속 메커니즘

### 비동기 프로그래밍
콜백, Promise, async/await를 통한 비동기 처리

## ES6+ 문법

const, let, 화살표 함수, 디스트럭처링 등
현대 JavaScript의 다양한 문법을 활용하세요.
    `}];a.s(["K",0,function(){return b.sort((a,b)=>new Date(b.date).getTime()-new Date(a.date).getTime())},"i",0,function(a){return b.find(b=>b.id===a)},"u",0,function(){return b.map(a=>a.id)}])},14465,(a,b,c)=>{(()=>{"use strict";var a={86:a=>{a.exports=function(a,b){return"string"==typeof a?g(a):"number"==typeof a?f(a,b):null},a.exports.format=f,a.exports.parse=g;var b=/\B(?=(\d{3})+(?!\d))/g,c=/(?:\.0*|(\.[^0]+)0+)$/,d={b:1,kb:1024,mb:1048576,gb:0x40000000,tb:0x10000000000,pb:0x4000000000000},e=/^((-|\+)?(\d+(?:\.\d+)?)) *(kb|mb|gb|tb|pb)$/i;function f(a,e){if(!Number.isFinite(a))return null;var f=Math.abs(a),g=e&&e.thousandsSeparator||"",h=e&&e.unitSeparator||"",i=e&&void 0!==e.decimalPlaces?e.decimalPlaces:2,j=!!(e&&e.fixedDecimals),k=e&&e.unit||"";k&&d[k.toLowerCase()]||(k=f>=d.pb?"PB":f>=d.tb?"TB":f>=d.gb?"GB":f>=d.mb?"MB":f>=d.kb?"KB":"B");var l=(a/d[k.toLowerCase()]).toFixed(i);return j||(l=l.replace(c,"$1")),g&&(l=l.split(".").map(function(a,c){return 0===c?a.replace(b,g):a}).join(".")),l+h+k}function g(a){if("number"==typeof a&&!isNaN(a))return a;if("string"!=typeof a)return null;var b,c=e.exec(a),f="b";return c?(b=parseFloat(c[1]),f=c[4].toLowerCase()):(b=parseInt(a,10),f="b"),Math.floor(d[f]*b)}}},c={};function d(b){var e=c[b];if(void 0!==e)return e.exports;var f=c[b]={exports:{}},g=!0;try{a[b](f,f.exports,d),g=!1}finally{g&&delete c[b]}return f.exports}d.ab="/ROOT/node_modules/next/dist/compiled/bytes/",b.exports=d(86)})()},717,(a,b,c)=>{"use strict";b.exports=a.r(24951).vendored["react-rsc"].React}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1u9mqmal5d_gf._.js.map