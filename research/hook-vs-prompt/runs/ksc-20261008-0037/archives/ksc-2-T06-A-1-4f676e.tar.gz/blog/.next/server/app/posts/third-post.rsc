1:"$Sreact.fragment"
2:"/_next/static/chunks/0umf92h1sb77c.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
5:"/_next/static/chunks/2n5qeheznvl4u.js"
6:I[22016,["$2","$5"],""]
c:I[97367,["$2"],"OutletBoundary"]
d:"$Sreact.suspense"
f:"ViewportBoundary"
10:I[97367,["$2"],"$f"]
12:"MetadataBoundary"
13:I[97367,["$2"],"$12"]
15:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/33b31n9lxfa1i.css","style"]
8:X
a:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":["$Lb",[["$","script","script-0",{"src":"/_next/static/chunks/2n5qeheznvl4u.js","async":true,"nonce":"$undefined"}]],["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}],"p":false,"v":null}}]]
9:[["children",{"s":{"n":"slug","t":"d","k":"third-post","s":[]},"h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$8"},"c":"$Qa"}]]
7:[["children",{"s":"posts","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$8"},"c":"$Q9"}]]
0:{"P":null,"c":["","posts","third-post"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/33b31n9lxfa1i.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0umf92h1sb77c.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"ko","children":["$","body",null,{"children":[["$","nav",null,{"className":"bg-gray-800 text-white p-4 mb-8","children":["$","div",null,{"className":"max-w-4xl mx-auto","children":["$","a",null,{"href":"/","className":"text-2xl font-bold","children":"My Blog"}]}]}],["$","main",null,{"className":"max-w-4xl mx-auto px-4","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"text-center py-12","children":[["$","h1",null,{"className":"text-4xl font-bold mb-4","children":"404"}],["$","p",null,{"className":"text-xl text-gray-600 mb-6","children":"페이지를 찾을 수 없습니다."}],["$","$L6",null,{"href":"/","className":"text-blue-600 font-semibold hover:underline","children":"홈으로 돌아가기"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","footer",null,{"className":"bg-gray-100 mt-8 p-4 text-center text-gray-600","children":["$","p",null,{"children":"© 2026 My Blog. All rights reserved."}]}]]}]}]]}],"p":false,"v":null},"c":"$Q7"},"h":{"r":["$","$1","h",{"children":[null,["$","$L10",null,{"children":"$L11"}],["$","$L13",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$d",null,{"name":"Next.Metadata","children":"$L14"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$15",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/33b31n9lxfa1i.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"Vbv7oRHV8Bs77j0lNDKKk"}
b:E{"digest":"NEXT_HTTP_ERROR_FALLBACK;404"}
8:C
11:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
e:null
14:[["$","title","0",{"children":"My Blog"}],["$","meta","1",{"name":"description","content":"A simple blog built with Next.js"}]]
