1:"$Sreact.fragment"
2:"/_next/static/chunks/0umf92h1sb77c.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
5:"/_next/static/chunks/2n5qeheznvl4u.js"
6:I[22016,["$2","$5"],""]
d:I[97367,["$2"],"OutletBoundary"]
e:"$Sreact.suspense"
11:"ViewportBoundary"
12:I[97367,["$2"],"$11"]
13:"MetadataBoundary"
14:I[97367,["$2"],"$13"]
:HL["/_next/static/chunks/33b31n9lxfa1i.css","style"]
8:X
b:X
b:C
c:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"className":"text-center py-12","children":[["$","h1",null,{"className":"text-4xl font-bold mb-4","children":"404"}],["$","p",null,{"className":"text-xl text-gray-600 mb-6","children":"페이지를 찾을 수 없습니다."}],["$","$L6",null,{"href":"/","className":"text-blue-600 font-semibold hover:underline","children":"홈으로 돌아가기"}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/2n5qeheznvl4u.js","async":true}]],["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}],"p":"$@10","v":null,"s":"$8"}}]]
9:[["children",{"s":"/_not-found","h":96,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@a","v":"$b","s":"$8"},"c":"$Qc"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/33b31n9lxfa1i.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0umf92h1sb77c.js","async":true}]],["$","html",null,{"lang":"ko","children":["$","body",null,{"children":[["$","nav",null,{"className":"bg-gray-800 text-white p-4 mb-8","children":["$","div",null,{"className":"max-w-4xl mx-auto","children":["$","a",null,{"href":"/","className":"text-2xl font-bold","children":"My Blog"}]}]}],["$","main",null,{"className":"max-w-4xl mx-auto px-4","children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[["$","div",null,{"className":"text-center py-12","children":[["$","h1",null,{"className":"text-4xl font-bold mb-4","children":"404"}],["$","p",null,{"className":"text-xl text-gray-600 mb-6","children":"페이지를 찾을 수 없습니다."}],["$","$L6",null,{"href":"/","className":"text-blue-600 font-semibold hover:underline","children":"홈으로 돌아가기"}]]}],[]]}]}],["$","footer",null,{"className":"bg-gray-100 mt-8 p-4 text-center text-gray-600","children":["$","p",null,{"children":"© 2026 My Blog. All rights reserved."}]}]]}]}]]}],"p":"$@7","v":null,"s":"$8"},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L12",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L14",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$e",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"My Blog"}],["$","meta","1",{"name":"description","content":"A simple blog built with Next.js"}]]}]}],null]}],null]}],"p":"$@15","v":null,"s":"$8"}},"a":"$@16","u":"$@17","b":"Vbv7oRHV8Bs77j0lNDKKk"}
f:null
8:300
17:true
8:C
16:0
a:"$undefined"
7:"$undefined"
15:"$undefined"
10:"$undefined"
