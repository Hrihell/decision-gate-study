module.exports=[3527,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_posts_%5Bslug%5D_page_actions_0jsrn6zyeal12.js.map