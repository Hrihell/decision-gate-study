1:"$Sreact.fragment"
2:"/_next/static/chunks/0umf92h1sb77c.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
5:"/_next/static/chunks/2n5qeheznvl4u.js"
6:I[22016,["$2","$5"],""]
a:I[97367,["$2"],"OutletBoundary"]
b:"$Sreact.suspense"
e:"ViewportBoundary"
f:I[97367,["$2"],"$e"]
10:"MetadataBoundary"
11:I[97367,["$2"],"$10"]
:HL["/_next/static/chunks/33b31n9lxfa1i.css","style"]
8:X
9:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"children":[["$","h1",null,{"children":"블로그"}],["$","p",null,{"className":"text-gray-600 mb-8","children":"최신 게시물을 확인하세요"}],["$","div",null,{"className":"space-y-6","children":[["$","article","first-post",{"className":"post-card","children":[["$","div",null,{"className":"post-meta","children":["2026-10-08"," • ","Admin"]}],["$","h2",null,{"className":"text-xl font-bold mb-2","children":["$","$L6",null,{"href":"/posts/first-post","className":"hover:text-blue-600","children":"Next.js 블로그 시작하기"}]}],["$","p",null,{"className":"text-gray-700 mb-3","children":"Next.js를 사용해서 간단한 블로그를 만들어보았습니다."}],["$","$L6",null,{"href":"/posts/first-post","className":"text-blue-600 font-semibold hover:underline","children":"전체 보기 →"}]]}],["$","article","second-post",{"className":"post-card","children":[["$","div",null,{"className":"post-meta","children":["2026-10-07"," • ","Admin"]}],["$","h2",null,{"className":"text-xl font-bold mb-2","children":["$","$L6",null,{"href":"/posts/second-post","className":"hover:text-blue-600","children":"React 강력한 라이브러리"}]}],["$","p",null,{"className":"text-gray-700 mb-3","children":"React는 현대적인 웹 개발의 표준입니다."}],["$","$L6",null,{"href":"/posts/second-post","className":"text-blue-600 font-semibold hover:underline","children":"전체 보기 →"}]]}],["$","article","third-post",{"className":"post-card","children":[["$","div",null,{"className":"post-meta","children":["2026-10-06"," • ","Admin"]}],["$","h2",null,{"className":"text-xl font-bold mb-2","children":["$","$L6",null,{"href":"/posts/third-post","className":"hover:text-blue-600","children":"JavaScript 핵심 개념"}]}],["$","p",null,{"className":"text-gray-700 mb-3","children":"JavaScript의 핵심 개념들을 알아봅니다."}],["$","$L6",null,{"href":"/posts/third-post","className":"text-blue-600 font-semibold hover:underline","children":"전체 보기 →"}]]}]]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/2n5qeheznvl4u.js","async":true}]],["$","$La",null,{"children":["$","$b",null,{"name":"Next.MetadataOutlet","children":"$@c"}]}]]}],"p":"$@d","v":null,"s":"$8"}}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/33b31n9lxfa1i.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0umf92h1sb77c.js","async":true}]],["$","html",null,{"lang":"ko","children":["$","body",null,{"children":[["$","nav",null,{"className":"bg-gray-800 text-white p-4 mb-8","children":["$","div",null,{"className":"max-w-4xl mx-auto","children":["$","a",null,{"href":"/","className":"text-2xl font-bold","children":"My Blog"}]}]}],["$","main",null,{"className":"max-w-4xl mx-auto px-4","children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[["$","div",null,{"className":"text-center py-12","children":[["$","h1",null,{"className":"text-4xl font-bold mb-4","children":"404"}],["$","p",null,{"className":"text-xl text-gray-600 mb-6","children":"페이지를 찾을 수 없습니다."}],["$","$L6",null,{"href":"/","className":"text-blue-600 font-semibold hover:underline","children":"홈으로 돌아가기"}]]}],[]]}]}],["$","footer",null,{"className":"bg-gray-100 mt-8 p-4 text-center text-gray-600","children":["$","p",null,{"children":"© 2026 My Blog. All rights reserved."}]}]]}]}]]}],"p":"$@7","v":null,"s":"$8"},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[null,["$","$Lf",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L11",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$b",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"My Blog"}],["$","meta","1",{"name":"description","content":"A simple blog built with Next.js"}]]}]}],null]}],null]}],"p":"$@12","v":null,"s":"$8"}},"a":"$@13","u":"$@14","b":"Vbv7oRHV8Bs77j0lNDKKk"}
c:null
8:300
14:true
8:C
13:0
7:"$undefined"
12:"$undefined"
d:"$undefined"
