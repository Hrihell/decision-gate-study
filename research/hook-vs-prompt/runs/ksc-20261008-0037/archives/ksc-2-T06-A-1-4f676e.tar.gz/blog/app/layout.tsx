import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'My Blog',
  description: 'A simple blog built with Next.js',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ko">
      <body>
        <nav className="bg-gray-800 text-white p-4 mb-8">
          <div className="max-w-4xl mx-auto">
            <a href="/" className="text-2xl font-bold">
              My Blog
            </a>
          </div>
        </nav>
        <main className="max-w-4xl mx-auto px-4">
          {children}
        </main>
        <footer className="bg-gray-100 mt-8 p-4 text-center text-gray-600">
          <p>&copy; 2026 My Blog. All rights reserved.</p>
        </footer>
      </body>
    </html>
  )
}
