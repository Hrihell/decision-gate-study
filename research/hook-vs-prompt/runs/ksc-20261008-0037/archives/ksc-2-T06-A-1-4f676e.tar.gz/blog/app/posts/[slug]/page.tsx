import { getPostBySlug, getPostSlugs } from '@/lib/posts'
import Link from 'next/link'
import { notFound } from 'next/navigation'

export async function generateStaticParams() {
  const slugs = getPostSlugs()
  return slugs.map(slug => ({ slug }))
}

export default function PostPage({ params }: { params: { slug: string } }) {
  const post = getPostBySlug(params.slug)

  if (!post) {
    notFound()
  }

  return (
    <article>
      <div className="mb-4">
        <Link href="/" className="text-blue-600 hover:underline">
          ← 블로그로 돌아가기
        </Link>
      </div>

      <header className="mb-8">
        <h1>{post.title}</h1>
        <div className="post-meta">
          {post.date} • {post.author}
        </div>
      </header>

      <div className="prose prose-sm max-w-none mb-8">
        {post.content.split('\n').map((line, idx) => {
          if (line.startsWith('# ')) {
            return <h2 key={idx}>{line.substring(2)}</h2>
          } else if (line.startsWith('## ')) {
            return <h3 key={idx} className="text-lg font-bold mt-4 mb-2">{line.substring(3)}</h3>
          } else if (line.startsWith('- ')) {
            return <li key={idx}>{line.substring(2)}</li>
          } else if (line.startsWith('### ')) {
            return <h4 key={idx} className="font-bold mt-2 mb-1">{line.substring(4)}</h4>
          } else if (line.trim()) {
            return <p key={idx}>{line}</p>
          } else {
            return null
          }
        })}
      </div>

      <hr className="my-8" />

      <div>
        <Link href="/" className="text-blue-600 hover:underline">
          ← 블로그로 돌아가기
        </Link>
      </div>
    </article>
  )
}
