import { getAllPosts } from '@/lib/posts'
import Link from 'next/link'

export default function Home() {
  const posts = getAllPosts()

  return (
    <div>
      <h1>블로그</h1>
      <p className="text-gray-600 mb-8">최신 게시물을 확인하세요</p>

      <div className="space-y-6">
        {posts.map(post => (
          <article key={post.id} className="post-card">
            <div className="post-meta">
              {post.date} • {post.author}
            </div>
            <h2 className="text-xl font-bold mb-2">
              <Link href={`/posts/${post.id}`} className="hover:text-blue-600">
                {post.title}
              </Link>
            </h2>
            <p className="text-gray-700 mb-3">{post.excerpt}</p>
            <Link
              href={`/posts/${post.id}`}
              className="text-blue-600 font-semibold hover:underline"
            >
              전체 보기 →
            </Link>
          </article>
        ))}
      </div>
    </div>
  )
}
