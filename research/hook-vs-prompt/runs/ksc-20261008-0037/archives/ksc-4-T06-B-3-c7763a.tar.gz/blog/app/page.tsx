import Link from "next/link";

const posts = [
  {
    id: 1,
    title: "Welcome to My Blog",
    excerpt: "This is my first blog post. I'm excited to share my thoughts!",
    date: "2025-10-01",
    slug: "welcome",
  },
  {
    id: 2,
    title: "Next.js 13 Features",
    excerpt: "Exploring the latest features of Next.js 13 App Router.",
    date: "2025-10-02",
    slug: "nextjs-features",
  },
  {
    id: 3,
    title: "React Best Practices",
    excerpt: "Tips and tricks for writing better React code.",
    date: "2025-10-03",
    slug: "react-best-practices",
  },
];

export default function Home() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-8">Latest Posts</h2>
      <div className="space-y-6">
        {posts.map((post) => (
          <article key={post.id} className="border-b pb-6">
            <Link href={`/post/${post.slug}`}>
              <h3 className="text-2xl font-bold hover:text-blue-600 cursor-pointer">
                {post.title}
              </h3>
            </Link>
            <p className="text-gray-600 text-sm mb-2">{post.date}</p>
            <p className="text-gray-700">{post.excerpt}</p>
            <Link href={`/post/${post.slug}`}>
              <span className="text-blue-600 hover:underline cursor-pointer">
                Read more →
              </span>
            </Link>
          </article>
        ))}
      </div>
    </div>
  );
}
