import Link from "next/link";
import { notFound } from "next/navigation";

interface PostPageProps {
  params: {
    slug: string;
  };
}

const posts: Record<string, { title: string; date: string; content: string }> = {
  welcome: {
    title: "Welcome to My Blog",
    date: "2025-10-01",
    content: `This is my first blog post! I'm excited to start this blogging journey.

In this post, I'll be sharing my thoughts on various topics including web development,
technology trends, and personal experiences.

Stay tuned for more posts coming soon!`,
  },
  "nextjs-features": {
    title: "Next.js 13 Features",
    date: "2025-10-02",
    content: `Next.js 13 introduced the App Router, which brings a lot of new features and improvements.

Some key features include:
- App Router with nested layouts
- Server Components for better performance
- Streaming and Suspense support
- Built-in image optimization
- Font optimization

These features make it easier to build fast and scalable web applications.`,
  },
  "react-best-practices": {
    title: "React Best Practices",
    date: "2025-10-03",
    content: `Here are some best practices for writing React code:

1. Use functional components and hooks
2. Keep components small and focused
3. Avoid prop drilling by using Context API or state management
4. Memoize expensive computations with useMemo
5. Use proper key props in lists
6. Write meaningful component names
7. Keep your state as local as possible

Following these practices will help you write cleaner and more maintainable code.`,
  },
};

export default function PostPage({ params }: PostPageProps) {
  const post = posts[params.slug];

  if (!post) {
    notFound();
  }

  return (
    <div>
      <Link href="/">
        <span className="text-blue-600 hover:underline cursor-pointer mb-4 inline-block">
          ← Back to Posts
        </span>
      </Link>

      <article className="mt-8">
        <h1 className="text-4xl font-bold mb-2">{post.title}</h1>
        <p className="text-gray-600 mb-8">{post.date}</p>

        <div className="prose max-w-none">
          {post.content.split("\n\n").map((paragraph, index) => (
            <p key={index} className="mb-4 text-gray-800 leading-relaxed">
              {paragraph}
            </p>
          ))}
        </div>
      </article>
    </div>
  );
}

export function generateStaticParams() {
  return Object.keys(posts).map((slug) => ({
    slug,
  }));
}
