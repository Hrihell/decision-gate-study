import React, { useState } from 'react';
import './TransactionForm.css';

function TransactionForm({ onAdd }) {
  const [type, setType] = useState('expense');
  const [category, setCategory] = useState('food');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);

  const expenseCategories = ['food', 'transport', 'entertainment', 'shopping', 'utilities', 'other'];
  const incomeCategories = ['salary', 'bonus', 'investment', 'other'];

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0) return;

    setLoading(true);
    try {
      await onAdd({
        type,
        category,
        amount: parseFloat(amount),
        description,
        date
      });
      setAmount('');
      setDescription('');
      setDate(new Date().toISOString().split('T')[0]);
      setCategory(type === 'expense' ? 'food' : 'salary');
    } finally {
      setLoading(false);
    }
  };

  const categories = type === 'expense' ? expenseCategories : incomeCategories;

  return (
    <div className="transaction-form">
      <h2>Add Transaction</h2>
      <form onSubmit={handleSubmit}>
        <div className="type-selector">
          <button
            type="button"
            className={`type-btn ${type === 'expense' ? 'active' : ''}`}
            onClick={() => {
              setType('expense');
              setCategory('food');
            }}
          >
            💸 Expense
          </button>
          <button
            type="button"
            className={`type-btn ${type === 'income' ? 'active' : ''}`}
            onClick={() => {
              setType('income');
              setCategory('salary');
            }}
          >
            💵 Income
          </button>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Category</label>
            <select value={category} onChange={(e) => setCategory(e.target.value)}>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Amount</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              step="0.01"
              min="0"
              required
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Description (Optional)</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter description"
            />
          </div>
        </div>

        <button type="submit" className="btn-submit" disabled={loading}>
          {loading ? 'Adding...' : 'Add Transaction'}
        </button>
      </form>
    </div>
  );
}

export default TransactionForm;
