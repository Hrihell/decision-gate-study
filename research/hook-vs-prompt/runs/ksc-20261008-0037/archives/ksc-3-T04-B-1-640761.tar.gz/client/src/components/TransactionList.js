import React from 'react';
import './TransactionList.css';

function TransactionList({ transactions, onDelete }) {
  if (transactions.length === 0) {
    return <div className="no-transactions">No transactions yet. Add one to get started!</div>;
  }

  return (
    <div className="transaction-list">
      {transactions.map(transaction => (
        <div key={transaction.id} className={`transaction-item ${transaction.type}`}>
          <div className="transaction-left">
            <div className="transaction-category">{transaction.category}</div>
            <div className="transaction-description">{transaction.description || '-'}</div>
            <div className="transaction-date">{transaction.date}</div>
          </div>
          <div className="transaction-right">
            <div className={`transaction-amount ${transaction.type}`}>
              {transaction.type === 'income' ? '+' : '-'}₩{transaction.amount.toLocaleString()}
            </div>
            <button
              className="btn-delete"
              onClick={() => onDelete(transaction.id)}
              title="Delete"
            >
              ✕
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default TransactionList;
