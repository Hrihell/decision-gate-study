import React from 'react';
import './Summary.css';

function Summary({ transactions }) {
  const income = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const expense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = income - expense;

  return (
    <div className="summary">
      <div className="summary-card income-card">
        <div className="summary-icon">💵</div>
        <div className="summary-content">
          <div className="summary-label">Income</div>
          <div className="summary-amount">₩{income.toLocaleString()}</div>
        </div>
      </div>

      <div className="summary-card expense-card">
        <div className="summary-icon">💸</div>
        <div className="summary-content">
          <div className="summary-label">Expense</div>
          <div className="summary-amount">₩{expense.toLocaleString()}</div>
        </div>
      </div>

      <div className={`summary-card balance-card ${balance >= 0 ? 'positive' : 'negative'}`}>
        <div className="summary-icon">💰</div>
        <div className="summary-content">
          <div className="summary-label">Balance</div>
          <div className="summary-amount">₩{balance.toLocaleString()}</div>
        </div>
      </div>
    </div>
  );
}

export default Summary;
