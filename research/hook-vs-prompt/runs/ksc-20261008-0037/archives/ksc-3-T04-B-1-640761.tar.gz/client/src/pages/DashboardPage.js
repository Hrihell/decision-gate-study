import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TransactionForm from '../components/TransactionForm';
import TransactionList from '../components/TransactionList';
import Summary from '../components/Summary';
import './DashboardPage.css';

function DashboardPage({ user, token, onLogout }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/transactions', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTransactions(response.data);
      setError('');
    } catch (err) {
      setError('Failed to load transactions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  const handleAddTransaction = async (transaction) => {
    try {
      const response = await axios.post('/api/transactions', transaction, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTransactions([response.data, ...transactions]);
      setError('');
    } catch (err) {
      setError('Failed to add transaction');
    }
  };

  const handleDeleteTransaction = async (id) => {
    try {
      await axios.delete(`/api/transactions/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTransactions(transactions.filter(t => t.id !== id));
    } catch (err) {
      setError('Failed to delete transaction');
    }
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <h1>💰 가계부</h1>
          <div className="header-right">
            <span className="user-email">{user?.email}</span>
            <button className="btn-logout" onClick={onLogout}>Logout</button>
          </div>
        </div>
      </header>

      <div className="dashboard-container">
        <div className="dashboard-main">
          <Summary transactions={transactions} />
          <TransactionForm onAdd={handleAddTransaction} />
        </div>

        <div className="dashboard-list">
          <h2>Recent Transactions</h2>
          {error && <div className="error-message">{error}</div>}
          {loading ? (
            <div className="loading">Loading...</div>
          ) : (
            <TransactionList
              transactions={transactions}
              onDelete={handleDeleteTransaction}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default DashboardPage;
