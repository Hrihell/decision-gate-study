const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { db, bcrypt } = require('./db');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

app.use(cors());
app.use(express.json());

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

app.post('/api/register', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (db.users.some(u => u.email === email)) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
      id: Math.max(...db.users.map(u => u.id), 0) + 1,
      email,
      password: hashedPassword,
      created_at: new Date().toISOString()
    };

    db.users.push(newUser);
    db.save();

    res.json({ id: newUser.id, email: newUser.email });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = db.users.find(u => u.email === email);

    if (!user) {
      return res.status(400).json({ error: 'User not found' });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(400).json({ error: 'Invalid password' });
    }

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, email: user.email } });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/transactions', authenticate, async (req, res) => {
  try {
    const { category, amount, description, type, date } = req.body;

    const newTransaction = {
      id: Math.max(...db.transactions.map(t => t.id), 0) + 1,
      user_id: req.userId,
      category,
      amount,
      description,
      type,
      date,
      created_at: new Date().toISOString()
    };

    db.transactions.push(newTransaction);
    db.save();

    res.json(newTransaction);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/transactions', authenticate, async (req, res) => {
  try {
    const transactions = db.transactions
      .filter(t => t.user_id === req.userId)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
    res.json(transactions);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/transactions/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const index = db.transactions.findIndex(t => t.id === parseInt(id) && t.user_id === req.userId);

    if (index > -1) {
      db.transactions.splice(index, 1);
      db.save();
    }

    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.use(express.static(path.join(__dirname, '../client/build')));

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
