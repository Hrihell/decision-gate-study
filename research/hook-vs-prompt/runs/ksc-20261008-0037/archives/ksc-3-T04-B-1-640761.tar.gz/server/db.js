const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

const usersFile = path.join(dataDir, 'users.json');
const transactionsFile = path.join(dataDir, 'transactions.json');

if (!fs.existsSync(usersFile)) {
  fs.writeFileSync(usersFile, JSON.stringify([]));
}
if (!fs.existsSync(transactionsFile)) {
  fs.writeFileSync(transactionsFile, JSON.stringify([]));
}

const db = {
  users: [],
  transactions: [],

  load() {
    this.users = JSON.parse(fs.readFileSync(usersFile, 'utf8'));
    this.transactions = JSON.parse(fs.readFileSync(transactionsFile, 'utf8'));
  },

  save() {
    fs.writeFileSync(usersFile, JSON.stringify(this.users, null, 2));
    fs.writeFileSync(transactionsFile, JSON.stringify(this.transactions, null, 2));
  }
};

db.load();

module.exports = { db, bcrypt };
