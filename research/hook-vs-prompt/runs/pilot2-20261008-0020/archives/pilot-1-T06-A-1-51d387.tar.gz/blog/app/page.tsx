import Link from "next/link";

const posts = [
  {
    id: 1,
    title: "Getting Started with Next.js",
    excerpt: "Learn how to build fast web applications with Next.js",
    date: "2024-01-15",
    slug: "getting-started-nextjs",
  },
  {
    id: 2,
    title: "React Hooks Explained",
    excerpt: "Deep dive into React hooks and how to use them effectively",
    date: "2024-01-10",
    slug: "react-hooks-explained",
  },
  {
    id: 3,
    title: "Tailwind CSS Tips",
    excerpt: "Useful tips and tricks for working with Tailwind CSS",
    date: "2024-01-05",
    slug: "tailwind-css-tips",
  },
];

export default function Home() {
  return (
    <div>
      <section className="mb-12">
        <h2 className="text-4xl font-bold mb-4 text-gray-900">
          Welcome to My Blog
        </h2>
        <p className="text-xl text-gray-600">
          Exploring web development, design, and technology insights.
        </p>
      </section>

      <section>
        <h2 className="text-3xl font-bold mb-8 text-gray-900">Latest Posts</h2>
        <div className="grid gap-6">
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow p-6"
            >
              <div className="mb-3">
                <time className="text-sm text-gray-500">{post.date}</time>
              </div>
              <h3 className="text-2xl font-bold mb-2 text-gray-900">
                <Link
                  href={`/posts/${post.slug}`}
                  className="hover:text-blue-600 transition-colors"
                >
                  {post.title}
                </Link>
              </h3>
              <p className="text-gray-600 mb-4">{post.excerpt}</p>
              <Link
                href={`/posts/${post.slug}`}
                className="text-blue-600 hover:text-blue-800 font-semibold"
              >
                Read More →
              </Link>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
