import Link from "next/link";

export default function PostsPage() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-8 text-gray-900">All Posts</h1>
      <p className="text-lg text-gray-600 mb-6">
        Browse all blog posts below.
      </p>
      <div className="flex gap-4">
        <Link
          href="/"
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Back to Home
        </Link>
      </div>
    </div>
  );
}
