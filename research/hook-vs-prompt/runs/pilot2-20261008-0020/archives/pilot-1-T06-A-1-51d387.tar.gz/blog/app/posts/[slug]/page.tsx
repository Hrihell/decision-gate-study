import Link from "next/link";

interface PostParams {
  params: {
    slug: string;
  };
}

const posts: Record<string, { title: string; date: string; content: string }> =
  {
    "getting-started-nextjs": {
      title: "Getting Started with Next.js",
      date: "2024-01-15",
      content: `
        Next.js is a powerful React framework for building web applications.

        ## Why Next.js?

        Next.js provides several benefits:
        - Server-side rendering (SSR)
        - Static site generation (SSG)
        - API routes
        - Built-in CSS support
        - Automatic code splitting

        ## Getting Started

        To create a new Next.js project, use create-next-app or set it up manually.
        This blog is built with Next.js and Tailwind CSS!
      `,
    },
    "react-hooks-explained": {
      title: "React Hooks Explained",
      date: "2024-01-10",
      content: `
        React Hooks allow you to use state and other React features in functional components.

        ## Common Hooks

        - useState: Manage component state
        - useEffect: Handle side effects
        - useContext: Access context values
        - useReducer: Complex state management
        - useCallback: Memoize functions
        - useMemo: Memoize values

        ## Best Practices

        Always follow the rules of hooks when using them in your applications.
      `,
    },
    "tailwind-css-tips": {
      title: "Tailwind CSS Tips",
      date: "2024-01-05",
      content: `
        Tailwind CSS is a utility-first CSS framework that helps you build modern designs.

        ## Tips for Success

        - Use responsive prefixes (sm, md, lg, xl, 2xl)
        - Leverage the config file for customization
        - Take advantage of arbitrary values
        - Use the official Tailwind CSS IntelliSense plugin
        - Keep your markup clean with @apply

        This blog demonstrates many Tailwind CSS features in action.
      `,
    },
  };

export default function PostPage({ params }: PostParams) {
  const post = posts[params.slug];

  if (!post) {
    return (
      <div className="text-center py-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Post Not Found</h1>
        <p className="text-gray-600 mb-6">
          The post you're looking for doesn't exist.
        </p>
        <Link
          href="/"
          className="text-blue-600 hover:text-blue-800 font-semibold"
        >
          Back to Home →
        </Link>
      </div>
    );
  }

  return (
    <article>
      <header className="mb-8">
        <Link
          href="/"
          className="text-blue-600 hover:text-blue-800 font-semibold mb-4 inline-block"
        >
          ← Back to Home
        </Link>
        <h1 className="text-4xl font-bold text-gray-900 mb-3">{post.title}</h1>
        <time className="text-gray-500">{post.date}</time>
      </header>

      <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed">
        {post.content.split("\n").map((line, index) => {
          if (line.startsWith("##")) {
            return (
              <h2
                key={index}
                className="text-2xl font-bold text-gray-900 mt-8 mb-4"
              >
                {line.replace("##", "").trim()}
              </h2>
            );
          }
          if (line.startsWith("-")) {
            return (
              <li key={index} className="ml-6 mb-2">
                {line.replace("-", "").trim()}
              </li>
            );
          }
          if (line.trim()) {
            return (
              <p key={index} className="mb-4">
                {line}
              </p>
            );
          }
          return null;
        })}
      </div>
    </article>
  );
}
