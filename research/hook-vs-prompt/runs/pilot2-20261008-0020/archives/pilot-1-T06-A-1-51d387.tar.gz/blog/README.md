# Next.js Blog

A modern blog built with Next.js 15, React 19, TypeScript, and Tailwind CSS.

## Features

- ✨ Modern design with Tailwind CSS
- 📝 Dynamic blog posts with dynamic routing
- ⚡ Fast performance with Next.js App Router
- 🎨 Fully responsive design
- 📱 Mobile-first approach

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

### Build for Production

```bash
npm run build
npm run start
```

## Project Structure

```
blog/
├── app/
│   ├── layout.tsx           # Root layout with navigation and footer
│   ├── page.tsx             # Homepage with blog posts list
│   ├── globals.css          # Global styles and Tailwind imports
│   └── posts/
│       ├── page.tsx         # All posts page
│       └── [slug]/
│           └── page.tsx     # Dynamic post page
├── public/                  # Static assets
├── package.json
├── tsconfig.json
├── tailwind.config.ts
├── next.config.ts
└── README.md
```

## Technologies Used

- **Next.js 15** - React framework for production
- **React 19** - JavaScript library for building UI
- **TypeScript** - Typed superset of JavaScript
- **Tailwind CSS** - Utility-first CSS framework

## Customization

### Adding New Posts

Edit the `posts` object in `app/posts/[slug]/page.tsx` to add new blog posts:

```typescript
const posts: Record<string, { title: string; date: string; content: string }> = {
  "your-post-slug": {
    title: "Your Post Title",
    date: "2024-01-20",
    content: "Your post content here...",
  },
};
```

### Styling

- Tailwind CSS classes are used throughout the project
- Customize colors and typography in `tailwind.config.ts`
- Global styles are in `app/globals.css`

## License

MIT
