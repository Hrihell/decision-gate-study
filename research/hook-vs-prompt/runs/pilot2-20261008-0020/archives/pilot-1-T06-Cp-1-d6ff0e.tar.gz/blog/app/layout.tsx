import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'My Blog',
  description: 'A simple blog built with Next.js',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-white text-gray-900">
        <header className="bg-blue-600 text-white py-6">
          <div className="max-w-4xl mx-auto px-4">
            <h1 className="text-3xl font-bold">
              <a href="/">My Blog</a>
            </h1>
            <p className="text-blue-100 mt-2">Welcome to my blog</p>
          </div>
        </header>
        <main className="max-w-4xl mx-auto px-4 py-8">
          {children}
        </main>
        <footer className="bg-gray-200 text-gray-700 py-4 mt-8">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <p>&copy; 2026 My Blog. All rights reserved.</p>
          </div>
        </footer>
      </body>
    </html>
  )
}
