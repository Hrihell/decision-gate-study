import Link from 'next/link'
import { getAllPosts } from '@/lib/posts'

export default function Home() {
  const posts = getAllPosts()

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Latest Posts</h2>
      
      {posts.length === 0 ? (
        <p className="text-gray-500">No posts yet.</p>
      ) : (
        <div className="space-y-6">
          {posts.map((post) => (
            <article
              key={post.slug}
              className="border-l-4 border-blue-600 pl-4 py-2"
            >
              <Link href={`/blog/${post.slug}`}>
                <h3 className="text-xl font-semibold hover:text-blue-600 mb-2">
                  {post.title}
                </h3>
              </Link>
              <p className="text-gray-500 text-sm mb-2">{post.date}</p>
              <p className="text-gray-700">{post.excerpt}</p>
              <Link
                href={`/blog/${post.slug}`}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                Read more →
              </Link>
            </article>
          ))}
        </div>
      )}
    </div>
  )
}
