import Link from 'next/link'
import { getPostBySlug, getSlugs } from '@/lib/posts'
import { notFound } from 'next/navigation'

export function generateStaticParams() {
  const slugs = getSlugs()
  return slugs.map((slug) => ({ slug }))
}

export default function BlogPost({
  params,
}: {
  params: { slug: string }
}) {
  const post = getPostBySlug(params.slug)

  if (!post) {
    notFound()
  }

  return (
    <article className="prose max-w-none">
      <Link href="/" className="text-blue-600 hover:text-blue-800 mb-6 inline-block">
        ← Back to home
      </Link>
      
      <h1 className="text-4xl font-bold mb-2">{post.title}</h1>
      <p className="text-gray-500 mb-6">{post.date}</p>
      
      <div className="prose max-w-none">
        {post.content.split('\n').map((line, index) => {
          if (line.startsWith('# ')) {
            return (
              <h2 key={index} className="text-3xl font-bold mt-6 mb-4">
                {line.replace(/^# /, '')}
              </h2>
            )
          }
          if (line.startsWith('## ')) {
            return (
              <h3 key={index} className="text-2xl font-bold mt-4 mb-3">
                {line.replace(/^## /, '')}
              </h3>
            )
          }
          if (line.startsWith('- ')) {
            return (
              <li key={index} className="ml-4 mb-1">
                {line.replace(/^- /, '')}
              </li>
            )
          }
          if (line.startsWith('> ')) {
            return (
              <blockquote key={index}>
                {line.replace(/^> /, '')}
              </blockquote>
            )
          }
          if (line.trim() === '') {
            return <br key={index} />
          }
          return (
            <p key={index} className="mb-4">
              {line}
            </p>
          )
        })}
      </div>
    </article>
  )
}
