'use client'

import Link from 'next/link'
import { useParams } from 'next/navigation'

const posts = {
  welcome: {
    title: 'Welcome to My Blog',
    date: '2026-10-01',
    content: `
      Welcome to my new blog! I'm excited to share my thoughts, experiences, and knowledge
      with you. This blog will cover topics ranging from web development to personal insights.

      Feel free to explore the different posts and let me know if you have any questions
      or feedback. I hope you find the content helpful and inspiring.
    `
  },
  'nextjs-getting-started': {
    title: 'Getting Started with Next.js',
    date: '2026-10-03',
    content: `
      Next.js is a powerful React framework that makes it easy to build fast, scalable
      web applications. Here are some key features:

      • Server-side rendering (SSR)
      • Static site generation (SSG)
      • API routes
      • Image optimization
      • Built-in CSS support

      Getting started is simple. Just run 'npx create-next-app' and you'll have a
      fully functional Next.js project ready to go!
    `
  },
  'react-tips': {
    title: 'React Tips and Tricks',
    date: '2026-10-05',
    content: `
      React is a fantastic library for building user interfaces. Here are some tips
      to help you write better React code:

      • Use functional components and hooks for cleaner code
      • Memoize expensive computations with useMemo
      • Use useCallback to optimize performance
      • Keep your component tree shallow
      • Use key prop correctly when rendering lists

      These practices will help you write more efficient and maintainable React applications.
    `
  }
}

export default function Post() {
  const params = useParams()
  const post = posts[params.slug]

  if (!post) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-semibold mb-4 text-gray-800">Post not found</h2>
        <Link href="/" className="text-blue-600 hover:text-blue-800">← Back to home</Link>
      </div>
    )
  }

  return (
    <article>
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">{post.title}</h1>
        <time className="text-gray-600">
          {new Date(post.date).toLocaleDateString()}
        </time>
      </div>

      <div className="prose prose-slate max-w-none">
        {post.content.split('\n').map((paragraph, idx) =>
          paragraph.trim() && (
            <p key={idx} className="text-gray-700 leading-relaxed mb-4 text-lg">
              {paragraph.trim()}
            </p>
          )
        )}
      </div>

      <div className="mt-8 pt-8 border-t border-gray-200">
        <Link href="/" className="text-blue-600 hover:text-blue-800">← Back to all posts</Link>
      </div>
    </article>
  )
}
