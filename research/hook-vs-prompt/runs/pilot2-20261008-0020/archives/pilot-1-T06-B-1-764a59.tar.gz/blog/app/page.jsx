'use client'

import Link from 'next/link'

const posts = [
  {
    id: 1,
    title: 'Welcome to My Blog',
    excerpt: 'This is my first blog post. Learn about what I\'ll be sharing here.',
    date: '2026-10-01',
    slug: 'welcome'
  },
  {
    id: 2,
    title: 'Getting Started with Next.js',
    excerpt: 'Discover how to build fast, modern web applications with Next.js.',
    date: '2026-10-03',
    slug: 'nextjs-getting-started'
  },
  {
    id: 3,
    title: 'React Tips and Tricks',
    excerpt: 'Useful React patterns and best practices for building better components.',
    date: '2026-10-05',
    slug: 'react-tips'
  }
]

export default function Home() {
  return (
    <div>
      <h2 className="text-4xl font-bold mb-8">Latest Posts</h2>
      <div className="grid gap-6">
        {posts.map((post) => (
          <article
            key={post.id}
            className="p-6 border border-gray-200 rounded-lg bg-gray-50 hover:shadow-md transition-shadow"
          >
            <h3 className="text-2xl font-semibold mb-2">
              <Link href={`/posts/${post.slug}`} className="text-blue-600 hover:text-blue-800">
                {post.title}
              </Link>
            </h3>
            <p className="text-gray-600 mb-3">{post.excerpt}</p>
            <time className="text-gray-400 text-sm">
              {new Date(post.date).toLocaleDateString()}
            </time>
          </article>
        ))}
      </div>
    </div>
  )
}
