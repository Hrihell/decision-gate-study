import './globals.css'

export const metadata = {
  title: 'My Blog',
  description: 'A simple blog built with Next.js',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-white text-gray-900">
        <nav className="bg-slate-900 text-white shadow-lg">
          <div className="max-w-4xl mx-auto px-6 py-4">
            <h1 className="text-3xl font-bold">📝 My Blog</h1>
          </div>
        </nav>
        <main className="max-w-4xl mx-auto px-6 py-12">
          {children}
        </main>
        <footer className="bg-gray-100 text-center py-8 mt-12 border-t border-gray-200">
          <p className="text-gray-600">&copy; 2026 My Blog. All rights reserved.</p>
        </footer>
      </body>
    </html>
  )
}
