const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function setCurrentUser(email) {
  localStorage.setItem(CURRENT_USER_KEY, email);
}

function clearCurrentUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
}

function getUserTodos(email) {
  return JSON.parse(localStorage.getItem(`todos_${email}`) || '[]');
}

function saveUserTodos(email, todos) {
  localStorage.setItem(`todos_${email}`, JSON.stringify(todos));
}

function toggleForms() {
  document.getElementById('login-form').classList.toggle('active');
  document.getElementById('signup-form').classList.toggle('active');
  document.getElementById('login-error').textContent = '';
  document.getElementById('signup-error').textContent = '';
}

function showAuthScreen() {
  document.getElementById('auth-screen').style.display = 'block';
  document.getElementById('app-screen').style.display = 'none';
}

function showAppScreen() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('app-screen').style.display = 'block';
}

function renderTodos(todos) {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const email = getCurrentUser();
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveUserTodos(email, next);
      renderTodos(next);
    });
    list.appendChild(item);
  });
}

function login(email, password) {
  const users = getUsers();
  const errorEl = document.getElementById('login-error');

  if (!users[email]) {
    errorEl.textContent = '이메일을 찾을 수 없습니다.';
    return;
  }

  if (users[email] !== password) {
    errorEl.textContent = '비밀번호가 틀렸습니다.';
    return;
  }

  setCurrentUser(email);
  errorEl.textContent = '';
  document.getElementById('user-info').textContent = `로그인: ${email}`;
  renderTodos(getUserTodos(email));
  showAppScreen();
}

function signup(email, password, confirmPassword) {
  const users = getUsers();
  const errorEl = document.getElementById('signup-error');

  if (!email || !password || !confirmPassword) {
    errorEl.textContent = '모든 필드를 입력해주세요.';
    return;
  }

  if (password !== confirmPassword) {
    errorEl.textContent = '비밀번호가 일치하지 않습니다.';
    return;
  }

  if (users[email]) {
    errorEl.textContent = '이미 존재하는 이메일입니다.';
    return;
  }

  users[email] = password;
  saveUsers(users);
  errorEl.textContent = '';

  document.getElementById('signup-email').value = '';
  document.getElementById('signup-password').value = '';
  document.getElementById('signup-confirm').value = '';

  alert('회원가입이 완료되었습니다. 로그인해주세요.');
  toggleForms();
}

function logout() {
  clearCurrentUser();
  document.getElementById('add-form').reset();
  document.getElementById('login-email').value = '';
  document.getElementById('login-password').value = '';
  showAuthScreen();
}

// 로그인 버튼
document.getElementById('login-btn').addEventListener('click', () => {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  login(email, password);
});

// Enter 키로 로그인
document.getElementById('login-password').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    login(email, password);
  }
});

// 회원가입 버튼
document.getElementById('signup-btn').addEventListener('click', () => {
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;
  const confirmPassword = document.getElementById('signup-confirm').value;
  signup(email, password, confirmPassword);
});

// Enter 키로 회원가입
document.getElementById('signup-confirm').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('signup-confirm').value;
    signup(email, password, confirmPassword);
  }
});

// 로그아웃 버튼
document.getElementById('logout-btn').addEventListener('click', logout);

// 할 일 추가
document.getElementById('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = document.getElementById('new-todo');
  const email = getCurrentUser();
  if (input.value.trim() === '') return;
  const todos = getUserTodos(email);
  const next = [...todos, { text: input.value.trim(), done: false }];
  saveUserTodos(email, next);
  renderTodos(next);
  input.value = '';
});

// 초기화
const currentUser = getCurrentUser();
if (currentUser) {
  document.getElementById('user-info').textContent = `로그인: ${currentUser}`;
  renderTodos(getUserTodos(currentUser));
  showAppScreen();
} else {
  showAuthScreen();
}
