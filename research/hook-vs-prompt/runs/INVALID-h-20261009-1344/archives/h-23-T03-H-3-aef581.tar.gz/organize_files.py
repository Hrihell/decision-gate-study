#!/usr/bin/env python3
import os
import shutil
from pathlib import Path
from collections import defaultdict

downloads_dir = Path("downloads")

if not downloads_dir.exists():
    print("❌ downloads 폴더를 찾을 수 없습니다.")
    exit(1)

files_by_ext = defaultdict(list)

for file_path in downloads_dir.iterdir():
    if file_path.is_file():
        if file_path.suffix:
            ext = file_path.suffix[1:]
        else:
            ext = "기타"
        
        files_by_ext[ext].append(file_path)

print("\n📁 파일 정리 시작...")
print("=" * 50)

for ext, files in sorted(files_by_ext.items()):
    folder_name = downloads_dir / ext
    
    folder_name.mkdir(exist_ok=True)
    
    for file_path in files:
        dest_path = folder_name / file_path.name
        shutil.move(str(file_path), str(dest_path))
        print(f"✓ {file_path.name} → {ext}/ 폴더로 이동")
    
    print(f"📊 [{ext}] 폴더: {len(files)}개 파일\n")

print("=" * 50)
print("✅ 파일 정리 완료!")
