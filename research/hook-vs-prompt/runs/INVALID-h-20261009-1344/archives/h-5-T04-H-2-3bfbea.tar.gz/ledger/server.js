const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static('public'));

app.use(session({
  secret: 'ledger-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 1000 * 60 * 60 * 24 }
}));

app.post('/api/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: '이메일과 비밀번호를 입력해주세요.' });
    }

    if (db.findUser(email)) {
      return res.status(400).json({ error: '이미 존재하는 이메일입니다.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = db.createUser(email, hashedPassword);
    
    req.session.userId = user.id;
    res.json({ message: '가입 완료', userId: user.id });
  } catch (error) {
    res.status(500).json({ error: '가입 실패' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: '이메일과 비밀번호를 입력해주세요.' });
    }

    const user = db.findUser(email);
    if (!user) {
      return res.status(400).json({ error: '없는 이메일입니다.' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ error: '비밀번호가 틀렸습니다.' });
    }

    req.session.userId = user.id;
    req.session.email = user.email;
    res.json({ message: '로그인 완료', userId: user.id });
  } catch (error) {
    res.status(500).json({ error: '로그인 실패' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ message: '로그아웃 완료' });
});

app.get('/api/user', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: '로그인이 필요합니다.' });
  }
  res.json({ userId: req.session.userId, email: req.session.email });
});

app.post('/api/transactions', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: '로그인이 필요합니다.' });
  }

  const { type, amount, category, description, date } = req.body;
  
  if (!type || !amount || !category) {
    return res.status(400).json({ error: '필수 정보를 입력해주세요.' });
  }

  const transaction = db.addTransaction(req.session.userId, {
    type,
    amount: parseFloat(amount),
    category,
    description: description || '',
    date
  });

  res.json(transaction);
});

app.get('/api/transactions', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: '로그인이 필요합니다.' });
  }

  const transactions = db.getUserTransactions(req.session.userId);
  res.json(transactions);
});

app.delete('/api/transactions/:id', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: '로그인이 필요합니다.' });
  }

  const success = db.deleteTransaction(req.params.id, req.session.userId);
  if (!success) {
    return res.status(404).json({ error: '거래를 찾을 수 없습니다.' });
  }

  res.json({ message: '삭제 완료' });
});

app.put('/api/transactions/:id', (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: '로그인이 필요합니다.' });
  }

  const { type, amount, category, description, date } = req.body;
  const updates = {};
  
  if (type) updates.type = type;
  if (amount) updates.amount = parseFloat(amount);
  if (category) updates.category = category;
  if (description) updates.description = description;
  if (date) updates.date = date;

  const transaction = db.updateTransaction(req.params.id, req.session.userId, updates);
  if (!transaction) {
    return res.status(404).json({ error: '거래를 찾을 수 없습니다.' });
  }

  res.json(transaction);
});

app.listen(PORT, () => {
  console.log(`가계부 앱이 http://localhost:${PORT} 에서 실행 중입니다.`);
});
