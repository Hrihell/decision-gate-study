const API = 'http://localhost:3000/api';

let currentUser = null;

const switchTab = (tab) => {
  document.getElementById('loginTab').classList.toggle('active');
  document.getElementById('registerTab').classList.toggle('active');
  document.getElementById('loginForm').classList.toggle('active');
  document.getElementById('registerForm').classList.toggle('active');
};

const register = async () => {
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;
  const passwordConfirm = document.getElementById('registerPasswordConfirm').value;
  const errorEl = document.getElementById('registerError');

  errorEl.textContent = '';

  if (!email || !password || !passwordConfirm) {
    errorEl.textContent = '모든 필드를 입력해주세요.';
    return;
  }

  if (password !== passwordConfirm) {
    errorEl.textContent = '비밀번호가 일치하지 않습니다.';
    return;
  }

  try {
    const res = await fetch(`${API}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
      credentials: 'include'
    });

    const data = await res.json();
    if (!res.ok) {
      errorEl.textContent = data.error || '가입 실패';
      return;
    }

    currentUser = { userId: data.userId, email };
    showMainScreen();
  } catch (error) {
    errorEl.textContent = '네트워크 오류';
  }
};

const login = async () => {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  const errorEl = document.getElementById('loginError');

  errorEl.textContent = '';

  if (!email || !password) {
    errorEl.textContent = '이메일과 비밀번호를 입력해주세요.';
    return;
  }

  try {
    const res = await fetch(`${API}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
      credentials: 'include'
    });

    const data = await res.json();
    if (!res.ok) {
      errorEl.textContent = data.error || '로그인 실패';
      return;
    }

    currentUser = { userId: data.userId, email };
    showMainScreen();
  } catch (error) {
    errorEl.textContent = '네트워크 오류';
  }
};

const logout = async () => {
  try {
    await fetch(`${API}/logout`, {
      method: 'POST',
      credentials: 'include'
    });
    currentUser = null;
    showAuthScreen();
  } catch (error) {
    console.error('로그아웃 실패:', error);
  }
};

const showAuthScreen = () => {
  document.getElementById('authScreen').style.display = 'flex';
  document.getElementById('mainScreen').style.display = 'none';
  document.getElementById('loginEmail').value = '';
  document.getElementById('loginPassword').value = '';
  document.getElementById('registerEmail').value = '';
  document.getElementById('registerPassword').value = '';
  document.getElementById('registerPasswordConfirm').value = '';
};

const showMainScreen = () => {
  document.getElementById('authScreen').style.display = 'none';
  document.getElementById('mainScreen').style.display = 'flex';
  document.getElementById('userEmail').textContent = currentUser.email;
  
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('date').value = today;
  
  loadTransactions();
};

const addTransaction = async () => {
  const type = document.getElementById('type').value;
  const amount = document.getElementById('amount').value;
  const category = document.getElementById('category').value;
  const description = document.getElementById('description').value;
  const date = document.getElementById('date').value;
  const errorEl = document.getElementById('addError');

  errorEl.textContent = '';

  if (!amount) {
    errorEl.textContent = '금액을 입력해주세요.';
    return;
  }

  try {
    const res = await fetch(`${API}/transactions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, amount, category, description, date }),
      credentials: 'include'
    });

    if (!res.ok) {
      const data = await res.json();
      errorEl.textContent = data.error || '추가 실패';
      return;
    }

    document.getElementById('amount').value = '';
    document.getElementById('description').value = '';
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('date').value = today;
    
    loadTransactions();
  } catch (error) {
    errorEl.textContent = '네트워크 오류';
  }
};

const deleteTransaction = async (id) => {
  if (!confirm('이 거래를 삭제하시겠습니까?')) {
    return;
  }

  try {
    const res = await fetch(`${API}/transactions/${id}`, {
      method: 'DELETE',
      credentials: 'include'
    });

    if (!res.ok) {
      alert('삭제 실패');
      return;
    }

    loadTransactions();
  } catch (error) {
    alert('네트워크 오류');
  }
};

const loadTransactions = async () => {
  try {
    const res = await fetch(`${API}/transactions`, {
      credentials: 'include'
    });

    if (!res.ok) {
      if (res.status === 401) {
        showAuthScreen();
      }
      return;
    }

    const transactions = await res.json();
    renderTransactions(transactions);
    updateStats(transactions);
  } catch (error) {
    console.error('거래 로드 실패:', error);
  }
};

const renderTransactions = (transactions) => {
  const list = document.getElementById('transactionList');

  if (transactions.length === 0) {
    list.innerHTML = '<p class="empty">거래 내역이 없습니다.</p>';
    return;
  }

  list.innerHTML = transactions.map(t => `
    <div class="transaction-item ${t.type}">
      <div class="transaction-info">
        <div class="transaction-category">${getCategoryName(t.category)}</div>
        <div class="transaction-date">${new Date(t.date).toLocaleDateString('ko-KR')}</div>
        ${t.description ? `<div class="transaction-description">${t.description}</div>` : ''}
      </div>
      <div class="transaction-amount ${t.type}">
        ${t.type === 'income' ? '+' : '-'}${t.amount.toLocaleString()}
      </div>
      <div class="transaction-actions">
        <button class="btn-delete" onclick="deleteTransaction('${t.id}')">삭제</button>
      </div>
    </div>
  `).join('');
};

const updateStats = (transactions) => {
  const income = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const expense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const net = income - expense;

  document.getElementById('totalIncome').textContent = income.toLocaleString();
  document.getElementById('totalExpense').textContent = expense.toLocaleString();
  document.getElementById('netAmount').textContent = net.toLocaleString();
  document.getElementById('netAmount').style.color = net >= 0 ? '#27ae60' : '#e74c3c';
};

const getCategoryName = (category) => {
  const names = {
    salary: '급여',
    food: '식비',
    transport: '교통',
    entertainment: '오락',
    utilities: '공과금',
    health: '의료',
    shopping: '쇼핑',
    other: '기타'
  };
  return names[category] || category;
};

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loginTab').addEventListener('click', () => switchTab('login'));
  document.getElementById('registerTab').addEventListener('click', () => switchTab('register'));
  showAuthScreen();
});
