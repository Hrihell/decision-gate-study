const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, 'data');
const usersFile = path.join(dataDir, 'users.json');
const transactionsFile = path.join(dataDir, 'transactions.json');

const ensureDir = () => {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
};

const loadJson = (file, defaultValue = []) => {
  if (!fs.existsSync(file)) {
    return defaultValue;
  }
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return defaultValue;
  }
};

const saveJson = (file, data) => {
  ensureDir();
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

const getUsers = () => loadJson(usersFile, []);
const saveUsers = (users) => saveJson(usersFile, users);

const getTransactions = () => loadJson(transactionsFile, []);
const saveTransactions = (transactions) => saveJson(transactionsFile, transactions);

const findUser = (email) => {
  const users = getUsers();
  return users.find(u => u.email === email);
};

const createUser = (email, hashedPassword) => {
  const users = getUsers();
  const user = {
    id: Date.now().toString(),
    email,
    password: hashedPassword,
    createdAt: new Date().toISOString()
  };
  users.push(user);
  saveUsers(users);
  return user;
};

const addTransaction = (userId, { type, amount, category, description, date }) => {
  const transactions = getTransactions();
  const transaction = {
    id: Date.now().toString(),
    userId,
    type,
    amount,
    category,
    description,
    date: date || new Date().toISOString(),
    createdAt: new Date().toISOString()
  };
  transactions.push(transaction);
  saveTransactions(transactions);
  return transaction;
};

const getUserTransactions = (userId) => {
  const transactions = getTransactions();
  return transactions.filter(t => t.userId === userId).sort((a, b) => 
    new Date(b.date) - new Date(a.date)
  );
};

const deleteTransaction = (id, userId) => {
  const transactions = getTransactions();
  const idx = transactions.findIndex(t => t.id === id && t.userId === userId);
  if (idx !== -1) {
    transactions.splice(idx, 1);
    saveTransactions(transactions);
    return true;
  }
  return false;
};

const updateTransaction = (id, userId, updates) => {
  const transactions = getTransactions();
  const transaction = transactions.find(t => t.id === id && t.userId === userId);
  if (transaction) {
    Object.assign(transaction, updates);
    saveTransactions(transactions);
    return transaction;
  }
  return null;
};

module.exports = {
  findUser,
  createUser,
  getUsers,
  addTransaction,
  getUserTransactions,
  deleteTransaction,
  updateTransaction
};
