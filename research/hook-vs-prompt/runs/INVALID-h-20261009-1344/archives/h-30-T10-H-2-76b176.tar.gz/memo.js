#!/usr/bin/env node
// 메모 프로그램. 메모는 memos.json 파일에 저장된다.
import readline from 'node:readline';
import fs from 'node:fs';
import path from 'node:path';

const dbFile = path.join(process.cwd(), 'memos.json');

function loadMemos() {
  try {
    if (fs.existsSync(dbFile)) {
      return JSON.parse(fs.readFileSync(dbFile, 'utf8'));
    }
  } catch (e) {
    console.error('메모 파일을 읽는 중 오류 발생:', e.message);
  }
  return [];
}

function saveMemos(memos) {
  try {
    fs.writeFileSync(dbFile, JSON.stringify(memos, null, 2), 'utf8');
  } catch (e) {
    console.error('메모를 저장하는 중 오류 발생:', e.message);
  }
}

const memos = loadMemos();
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log('메모를 입력하세요. "목록" 은 전체 보기, "끝" 은 종료.');
rl.on('line', (line) => {
  const text = line.trim();
  if (text === '끝') {
    saveMemos(memos);
    rl.close();
    return;
  }
  if (text === '목록') {
    memos.forEach((memo, i) => console.log(`${i + 1}. ${memo}`));
    return;
  }
  if (text !== '') {
    memos.push(text);
    saveMemos(memos);
  }
});
