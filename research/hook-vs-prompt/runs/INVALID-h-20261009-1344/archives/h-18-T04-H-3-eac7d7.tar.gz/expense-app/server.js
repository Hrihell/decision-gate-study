import express from 'express';
import cors from 'cors';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const app = express();
const JWT_SECRET = 'your-secret-key-change-in-production';

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// 데이터베이스 초기화
const db = new sqlite3.Database('./expenses.db');

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY,
      email TEXT UNIQUE,
      password TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY,
      user_id INTEGER,
      amount REAL,
      category TEXT,
      description TEXT,
      date TEXT,
      created_at TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )
  `);
});

// 인증 미들웨어
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: '인증이 필요합니다' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: '유효하지 않은 토큰입니다' });
    }
    req.user = user;
    next();
  });
}

// 회원가입
app.post('/api/auth/register', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: '이메일과 비밀번호가 필요합니다' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);

  db.run('INSERT INTO users (email, password) VALUES (?, ?)', [email, hashedPassword], function(err) {
    if (err) {
      return res.status(400).json({ error: '이미 존재하는 이메일입니다' });
    }

    const token = jwt.sign({ id: this.lastID, email }, JWT_SECRET);
    res.json({ token, email });
  });
});

// 로그인
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: '이메일과 비밀번호가 필요합니다' });
  }

  db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
    if (err || !user) {
      return res.status(400).json({ error: '사용자를 찾을 수 없습니다' });
    }

    if (!bcrypt.compareSync(password, user.password)) {
      return res.status(400).json({ error: '비밀번호가 잘못되었습니다' });
    }

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
    res.json({ token, email: user.email });
  });
});

// 지출 추가
app.post('/api/expenses', authenticateToken, (req, res) => {
  const { amount, category, description, date } = req.body;

  if (!amount || !category || !date) {
    return res.status(400).json({ error: '필수 필드가 누락되었습니다' });
  }

  const created_at = new Date().toISOString();

  db.run(
    'INSERT INTO expenses (user_id, amount, category, description, date, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    [req.user.id, amount, category, description || '', date, created_at],
    function(err) {
      if (err) {
        return res.status(500).json({ error: '지출 추가 실패' });
      }
      res.json({ id: this.lastID, amount, category, description, date, created_at });
    }
  );
});

// 지출 목록
app.get('/api/expenses', authenticateToken, (req, res) => {
  db.all('SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC', [req.user.id], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: '지출 조회 실패' });
    }
    res.json(rows || []);
  });
});

// 지출 수정
app.put('/api/expenses/:id', authenticateToken, (req, res) => {
  const { amount, category, description, date } = req.body;

  db.run(
    'UPDATE expenses SET amount = ?, category = ?, description = ?, date = ? WHERE id = ? AND user_id = ?',
    [amount, category, description || '', date, req.params.id, req.user.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: '지출 수정 실패' });
      }
      if (this.changes === 0) {
        return res.status(404).json({ error: '지출을 찾을 수 없습니다' });
      }
      res.json({ id: req.params.id, amount, category, description, date });
    }
  );
});

// 지출 삭제
app.delete('/api/expenses/:id', authenticateToken, (req, res) => {
  db.run('DELETE FROM expenses WHERE id = ? AND user_id = ?', [req.params.id, req.user.id], function(err) {
    if (err) {
      return res.status(500).json({ error: '지출 삭제 실패' });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: '지출을 찾을 수 없습니다' });
    }
    res.json({ success: true });
  });
});

const server = app.listen(0, '127.0.0.1', () => {
  const port = server.address().port;
  console.log(`서버가 http://localhost:${port} 에서 실행 중입니다`);
  console.log(`포트: ${port}`);
});
