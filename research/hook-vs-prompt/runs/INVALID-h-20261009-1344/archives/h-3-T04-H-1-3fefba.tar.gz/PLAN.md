# 가계부 앱 개발 계획

## 기술 스택
- **백엔드**: Node.js + Express
- **데이터베이스**: SQLite
- **인증**: JWT (jsonwebtoken)
- **프론트엔드**: HTML + CSS + Vanilla JavaScript
- **비밀번호 암호화**: bcryptjs

## 구현 내용

### 1. 백엔드 (server.js)
- Express 서버 (포트 3000)
- JWT 기반 인증
- RESTful API:
  - POST /api/auth/signup - 회원가입
  - POST /api/auth/login - 로그인
  - GET /api/transactions - 거래 내역 조회
  - POST /api/transactions - 거래 추가
  - DELETE /api/transactions/:id - 거래 삭제

### 2. 데이터베이스 (db.js)
- users 테이블: id, username, password, created_at
- transactions 테이블: id, user_id, type, category, amount, description, date, created_at

### 3. 프론트엔드 (public/)
- index.html: 로그인/회원가입 페이지
- dashboard.html: 가계부 메인 페이지
- style.css: 스타일
- app.js: 클라이언트 로직

### 4. package.json
- start 스크립트 추가

## 실행 순서
1. npm install 완료
2. 모든 파일 생성
3. npm start로 서버 실행
4. http://localhost:3000 접속
