#!/usr/bin/env python3
import os
import shutil
from pathlib import Path

def organize_downloads():
    downloads_dir = Path("downloads")
    
    if not downloads_dir.exists():
        print("❌ downloads 폴더가 없습니다.")
        return
    
    files_moved = 0
    
    for item in downloads_dir.iterdir():
        if item.is_file():
            # 확장자 가져오기
            if item.suffix:
                ext = item.suffix.lstrip('.')
            else:
                ext = 'no_extension'
            
            # 확장자 폴더 생성
            ext_folder = downloads_dir / ext
            ext_folder.mkdir(exist_ok=True)
            
            # 파일 이동
            dest = ext_folder / item.name
            shutil.move(str(item), str(dest))
            print(f"✓ {item.name} → {ext}/")
            files_moved += 1
    
    print(f"\n✅ 총 {files_moved}개 파일을 정리했습니다!")

if __name__ == "__main__":
    organize_downloads()
