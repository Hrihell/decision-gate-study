import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'My Blog',
  description: 'A simple blog built with Next.js',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="flex flex-col min-h-screen">
        <header className="bg-white shadow">
          <nav className="max-w-4xl mx-auto px-4 py-4">
            <h1 className="text-3xl font-bold">
              <a href="/" className="hover:text-blue-600">
                My Blog
              </a>
            </h1>
          </nav>
        </header>
        <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-8">
          {children}
        </main>
        <footer className="bg-gray-100 mt-12">
          <div className="max-w-4xl mx-auto px-4 py-6 text-center text-gray-600">
            <p>&copy; 2026 My Blog. All rights reserved.</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
