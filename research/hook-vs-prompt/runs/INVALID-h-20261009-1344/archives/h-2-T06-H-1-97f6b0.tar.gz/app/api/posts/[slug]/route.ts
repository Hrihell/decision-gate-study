import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import { join } from 'path';
import matter from 'gray-matter';
import { marked } from 'marked';

export async function GET(
  request: Request,
  { params }: { params: { slug: string } }
) {
  try {
    const postsDir = join(process.cwd(), 'posts');
    const filePath = join(postsDir, `${params.slug}.md`);
    const fileContent = await readFile(filePath, 'utf-8');

    const { data, content } = matter(fileContent);
    const htmlContent = await marked(content);

    return NextResponse.json({
      title: data.title || 'Untitled',
      date: data.date || new Date().toISOString(),
      content: htmlContent,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Post not found' },
      { status: 404 }
    );
  }
}
