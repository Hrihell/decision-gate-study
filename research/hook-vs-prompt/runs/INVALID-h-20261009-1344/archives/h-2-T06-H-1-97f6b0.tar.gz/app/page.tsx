'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';

interface Post {
  slug: string;
  title: string;
  date: string;
  excerpt: string;
}

export default function Home() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  async function fetchPosts() {
    try {
      const response = await fetch('/api/posts');
      const data = await response.json();
      setPosts(data.posts);
    } catch (error) {
      console.error('Failed to fetch posts:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <div className="text-center py-12">Loading...</div>;
  }

  return (
    <div>
      <section className="mb-12">
        <h2 className="text-4xl font-bold mb-4">Welcome to My Blog</h2>
        <p className="text-xl text-gray-600">
          Thoughts on web development, technology, and more.
        </p>
      </section>

      <section>
        <h3 className="text-2xl font-bold mb-6">Latest Posts</h3>
        <div className="space-y-6">
          {posts.length > 0 ? (
            posts.map((post) => (
              <article
                key={post.slug}
                className="border-b pb-6 hover:shadow-md transition"
              >
                <Link href={`/blog/${post.slug}`}>
                  <h2 className="text-2xl font-bold hover:text-blue-600 mb-2">
                    {post.title}
                  </h2>
                </Link>
                <p className="text-sm text-gray-500 mb-3">{post.date}</p>
                <p className="text-gray-700">{post.excerpt}</p>
                <Link
                  href={`/blog/${post.slug}`}
                  className="text-blue-600 hover:underline mt-2 inline-block"
                >
                  Read more →
                </Link>
              </article>
            ))
          ) : (
            <p className="text-gray-500">No posts yet.</p>
          )}
        </div>
      </section>
    </div>
  );
}
