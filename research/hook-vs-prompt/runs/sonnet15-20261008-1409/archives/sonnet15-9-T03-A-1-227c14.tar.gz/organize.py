#!/usr/bin/env python3
"""downloads 폴더의 파일을 확장자별 하위 폴더로 정리합니다.

사용법:
    python3 organize.py              # ./downloads 정리
    python3 organize.py --dry-run    # 실제로 옮기지 않고 결과만 미리보기
    python3 organize.py 다른/폴더     # 다른 폴더 정리
"""
import argparse
import shutil
from pathlib import Path

NO_EXT_FOLDER = "확장자없음"


def unique_path(dest: Path) -> Path:
    if not dest.exists():
        return dest
    n = 1
    while True:
        candidate = dest.with_name(f"{dest.stem} ({n}){dest.suffix}")
        if not candidate.exists():
            return candidate
        n += 1


def organize(target: Path, dry_run: bool) -> int:
    moved = 0
    for item in sorted(target.iterdir()):
        if not item.is_file() or item.name.startswith("."):
            continue

        ext = item.suffix.lstrip(".").lower()
        folder = target / (ext if ext else NO_EXT_FOLDER)
        dest = unique_path(folder / item.name)

        print(f"{item.name}  ->  {dest.relative_to(target)}")
        if not dry_run:
            folder.mkdir(exist_ok=True)
            shutil.move(str(item), str(dest))
        moved += 1
    return moved


def main() -> None:
    parser = argparse.ArgumentParser(description="파일을 확장자별로 정리합니다.")
    parser.add_argument(
        "folder",
        nargs="?",
        default=Path(__file__).resolve().parent / "downloads",
        type=Path,
        help="정리할 폴더 (기본값: 스크립트 옆의 downloads)",
    )
    parser.add_argument("--dry-run", action="store_true", help="실제로 옮기지 않고 미리보기만")
    args = parser.parse_args()

    if not args.folder.is_dir():
        parser.error(f"폴더를 찾을 수 없습니다: {args.folder}")

    count = organize(args.folder, args.dry_run)
    suffix = " (미리보기, 실제 이동 없음)" if args.dry_run else ""
    print(f"\n총 {count}개 파일 처리{suffix}")


if __name__ == "__main__":
    main()
