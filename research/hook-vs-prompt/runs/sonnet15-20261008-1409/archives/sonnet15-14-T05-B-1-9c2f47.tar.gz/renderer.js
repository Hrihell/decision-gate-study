let todos = [];
let filter = 'all';

const list = document.getElementById('list');
const input = document.getElementById('new-todo');
const count = document.getElementById('count');

const persist = () => window.todoApi.save(todos);

function render() {
  const visible = todos.filter((t) =>
    filter === 'all' ? true : filter === 'done' ? t.done : !t.done
  );
  list.replaceChildren(
    ...visible.map((t) => {
      const li = document.createElement('li');
      if (t.done) li.classList.add('done');

      const check = document.createElement('input');
      check.type = 'checkbox';
      check.checked = t.done;
      check.addEventListener('change', () => {
        t.done = check.checked;
        persist();
        render();
      });

      const label = document.createElement('span');
      label.textContent = t.text;
      label.addEventListener('dblclick', () => {
        const next = prompt('할 일 수정', t.text);
        if (next && next.trim()) {
          t.text = next.trim();
          persist();
          render();
        }
      });

      const del = document.createElement('button');
      del.textContent = '×';
      del.className = 'delete';
      del.addEventListener('click', () => {
        todos = todos.filter((x) => x.id !== t.id);
        persist();
        render();
      });

      li.append(check, label, del);
      return li;
    })
  );
  const remaining = todos.filter((t) => !t.done).length;
  count.textContent = `남은 할 일 ${remaining}개`;
}

document.getElementById('add-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  todos.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), text, done: false });
  input.value = '';
  persist();
  render();
});

document.getElementById('filters').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-filter]');
  if (!btn) return;
  filter = btn.dataset.filter;
  document.querySelectorAll('#filters button').forEach((b) => b.classList.toggle('active', b === btn));
  render();
});

document.getElementById('clear-done').addEventListener('click', () => {
  todos = todos.filter((t) => !t.done);
  persist();
  render();
});

window.todoApi.load().then((loaded) => {
  todos = loaded;
  render();
});
