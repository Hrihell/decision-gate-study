import http from 'node:http';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';

const PORT = Number(process.env.PORT || 3000);
const CLUB_CODE = process.env.CLUB_CODE || 'club1234';
const LOAN_DAYS = 14;
const SESSION_DAYS = 30;

const db = new DatabaseSync(process.env.DB_PATH || 'club-books.db');
db.exec(`
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  salt TEXT NOT NULL,
  hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  condition TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS loans (
  id INTEGER PRIMARY KEY,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  borrower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('requested','approved','returned','declined','cancelled')),
  due_date TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

const q = (sql) => db.prepare(sql);

const h = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(password, salt, 64).toString('hex') };
}
function verifyPassword(password, salt, hash) {
  const a = Buffer.from(hashPassword(password, salt).hash, 'hex');
  const b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function currentUser(req) {
  const token = parseCookies(req).sid;
  if (!token) return null;
  return (
    q(`SELECT u.id, u.username, u.name FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token = ? AND s.created_at > datetime('now', ?)`).get(token, `-${SESSION_DAYS} days`) || null
  );
}

function readForm(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 100_000) {
        reject(Object.assign(new Error('too large'), { status: 413 }));
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => resolve(Object.fromEntries(new URLSearchParams(Buffer.concat(chunks).toString()))));
    req.on('error', reject);
  });
}

const STATUS_LABEL = {
  requested: '요청 대기',
  approved: '대여 중',
  returned: '반납 완료',
  declined: '거절됨',
  cancelled: '취소됨',
};

function layout(user, title, body, msg) {
  return `<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${h(title)} · 동아리 책 나눔</title>
<style>
*{box-sizing:border-box}
body{font-family:-apple-system,"Apple SD Gothic Neo","Malgun Gothic",sans-serif;margin:0;background:#f6f5f1;color:#222;line-height:1.5}
header{background:#2f4a3a;color:#fff;padding:12px 20px;display:flex;gap:16px;align-items:center;flex-wrap:wrap}
header a{color:#fff;text-decoration:none}
header .brand{font-weight:700;font-size:1.15rem;margin-right:auto}
header form{display:inline;margin:0}
main{max-width:860px;margin:24px auto;padding:0 16px}
h1{font-size:1.4rem;margin:0 0 16px}h2{font-size:1.1rem;margin:28px 0 10px}
.card{background:#fff;border:1px solid #e3e0d6;border-radius:10px;padding:14px 16px;margin-bottom:10px}
.card h3{margin:0 0 2px;font-size:1.05rem}
.meta{color:#666;font-size:.9rem}
.badge{display:inline-block;padding:1px 8px;border-radius:999px;font-size:.78rem;background:#e8efe9;color:#2f4a3a;margin-left:6px}
.badge.busy{background:#f6e3df;color:#9a3b2b}
.row{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap}
.actions{display:flex;gap:6px;flex-wrap:wrap}
form.inline{display:inline;margin:0}
button,.btn{font:inherit;font-size:.9rem;padding:6px 12px;border-radius:6px;border:1px solid #2f4a3a;background:#2f4a3a;color:#fff;cursor:pointer;text-decoration:none;display:inline-block}
button.ghost,.btn.ghost{background:#fff;color:#2f4a3a}
button.danger{background:#fff;color:#9a3b2b;border-color:#9a3b2b}
label{display:block;margin:12px 0 4px;font-weight:600;font-size:.92rem}
input,select,textarea{width:100%;font:inherit;padding:8px 10px;border:1px solid #cfcbbd;border-radius:6px;background:#fff}
.form{max-width:420px}.form button{margin-top:16px}
.msg{background:#fff8dc;border:1px solid #e6d98a;padding:10px 14px;border-radius:8px;margin-bottom:16px}
.search{display:flex;gap:8px;margin-bottom:16px}.search input{flex:1}
.empty{color:#888;padding:12px 0}
</style></head><body>
<header>
  <a class="brand" href="/">📚 동아리 책 나눔</a>
  <a href="/">책 목록</a>
  ${
    user
      ? `<a href="/books/new">책 등록</a><a href="/my">내 활동</a>
         <span>${h(user.name)}님</span>
         <form method="post" action="/logout"><button class="ghost">로그아웃</button></form>`
      : `<a href="/login">로그인</a><a href="/signup">회원가입</a>`
  }
</header>
<main>
${msg ? `<div class="msg">${h(msg)}</div>` : ''}
${body}
</main></body></html>`;
}

function postBtn(action, label, cls = '', confirmMsg = '') {
  return `<form class="inline" method="post" action="${action}"${
    confirmMsg ? ` onsubmit="return confirm('${h(confirmMsg)}')"` : ''
  }><button class="${cls}">${label}</button></form>`;
}

function homePage(user, search, msg) {
  const like = `%${search.replace(/[\\%_]/g, '\\$&')}%`;
  const books = q(`
    SELECT b.*, u.name AS owner_name,
      (SELECT COUNT(*) FROM loans l WHERE l.book_id = b.id AND l.status = 'approved') AS on_loan,
      (SELECT COUNT(*) FROM loans l WHERE l.book_id = b.id AND l.borrower_id = ? AND l.status = 'requested') AS my_pending
    FROM books b JOIN users u ON u.id = b.owner_id
    WHERE b.title LIKE ? ESCAPE '\\' OR b.author LIKE ? ESCAPE '\\'
    ORDER BY b.id DESC`).all(user?.id ?? 0, like, like);

  const cards = books
    .map((b) => {
      let action = '';
      if (user && user.id === b.owner_id) action = '<span class="meta">내 책</span>';
      else if (user && b.my_pending) action = '<span class="meta">요청함</span>';
      else if (user && !b.on_loan) action = postBtn(`/books/${b.id}/request`, '빌리고 싶어요');
      else if (!user && !b.on_loan) action = '<a class="btn ghost" href="/login">로그인 후 요청</a>';
      return `<div class="card"><div class="row">
        <div><h3>${h(b.title)}<span class="badge${b.on_loan ? ' busy' : ''}">${b.on_loan ? '대여 중' : '대여 가능'}</span></h3>
        <div class="meta">${h(b.author)} · 상태: ${h(b.condition)} · 주인: ${h(b.owner_name)}</div>
        ${b.note ? `<div class="meta">${h(b.note)}</div>` : ''}</div>
        <div class="actions">${action}</div></div></div>`;
    })
    .join('');

  return layout(
    user,
    '책 목록',
    `<h1>책 목록</h1>
     <form class="search" method="get" action="/"><input name="q" value="${h(search)}" placeholder="제목 또는 저자 검색"><button>검색</button></form>
     ${cards || '<div class="empty">등록된 책이 없습니다.</div>'}`,
    msg,
  );
}

function myPage(user, msg) {
  const incoming = q(`
    SELECT l.*, b.title, u.name AS borrower_name FROM loans l
    JOIN books b ON b.id = l.book_id JOIN users u ON u.id = l.borrower_id
    WHERE b.owner_id = ? AND l.status IN ('requested','approved') ORDER BY l.id DESC`).all(user.id);
  const mine = q(`
    SELECT b.*, (SELECT COUNT(*) FROM loans l WHERE l.book_id = b.id AND l.status = 'approved') AS on_loan
    FROM books b WHERE b.owner_id = ? ORDER BY b.id DESC`).all(user.id);
  const borrowed = q(`
    SELECT l.*, b.title, u.name AS owner_name FROM loans l
    JOIN books b ON b.id = l.book_id JOIN users u ON u.id = b.owner_id
    WHERE l.borrower_id = ? ORDER BY l.id DESC`).all(user.id);

  const incomingHtml = incoming
    .map(
      (l) => `<div class="card"><div class="row">
      <div><h3>${h(l.title)}<span class="badge${l.status === 'approved' ? ' busy' : ''}">${STATUS_LABEL[l.status]}</span></h3>
      <div class="meta">${h(l.borrower_name)}님${l.status === 'approved' ? ` · 반납 예정 ${h(l.due_date)}` : '이 빌리고 싶어해요'}</div></div>
      <div class="actions">${
        l.status === 'requested'
          ? postBtn(`/loans/${l.id}/approve`, `승인 (${LOAN_DAYS}일)`) + postBtn(`/loans/${l.id}/decline`, '거절', 'danger')
          : postBtn(`/loans/${l.id}/return`, '반납 받음')
      }</div></div></div>`,
    )
    .join('');

  const mineHtml = mine
    .map(
      (b) => `<div class="card"><div class="row">
      <div><h3>${h(b.title)}<span class="badge${b.on_loan ? ' busy' : ''}">${b.on_loan ? '대여 중' : '대여 가능'}</span></h3>
      <div class="meta">${h(b.author)} · ${h(b.condition)}</div></div>
      <div class="actions">${
        b.on_loan ? '' : postBtn(`/books/${b.id}/delete`, '삭제', 'danger', '이 책을 삭제할까요?')
      }</div></div></div>`,
    )
    .join('');

  const borrowedHtml = borrowed
    .map(
      (l) => `<div class="card"><div class="row">
      <div><h3>${h(l.title)}<span class="badge${l.status === 'approved' ? ' busy' : ''}">${STATUS_LABEL[l.status]}</span></h3>
      <div class="meta">주인: ${h(l.owner_name)}${l.status === 'approved' ? ` · 반납 예정 ${h(l.due_date)}` : ''}</div></div>
      <div class="actions">${l.status === 'requested' ? postBtn(`/loans/${l.id}/cancel`, '요청 취소', 'ghost') : ''}</div>
      </div></div>`,
    )
    .join('');

  return layout(
    user,
    '내 활동',
    `<h1>내 활동</h1>
     <h2>받은 요청 / 빌려준 책</h2>${incomingHtml || '<div class="empty">없음</div>'}
     <h2>내가 등록한 책</h2>${mineHtml || '<div class="empty">아직 등록한 책이 없습니다. <a href="/books/new">책 등록하기</a></div>'}
     <h2>내가 빌린 책 / 요청</h2>${borrowedHtml || '<div class="empty">없음</div>'}`,
    msg,
  );
}

const authForm = (user, title, fields, action, button, msg) =>
  layout(user, title, `<h1>${title}</h1><form class="form" method="post" action="${action}">${fields}<button>${button}</button></form>`, msg);

function bookForm(user) {
  return authForm(
    user,
    '책 등록',
    `<label>제목</label><input name="title" required maxlength="200">
     <label>저자</label><input name="author" required maxlength="100">
     <label>책 상태</label><select name="condition"><option>상</option><option selected>중</option><option>하</option></select>
     <label>메모 (선택)</label><textarea name="note" rows="3" maxlength="500" placeholder="밑줄 있음, 표지 약간 헤짐 등"></textarea>`,
    '/books',
    '등록',
  );
}

function send(res, status, html, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', ...headers });
  res.end(html);
}
const redirect = (res, to, msg, headers = {}) =>
  res.writeHead(303, { Location: msg ? `${to}?msg=${encodeURIComponent(msg)}` : to, ...headers }) || res.end();

function startSession(res, userId, to) {
  const token = crypto.randomBytes(32).toString('hex');
  q('INSERT INTO sessions (token, user_id) VALUES (?, ?)').run(token, userId);
  redirect(res, to, null, {
    'Set-Cookie': `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}`,
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const path = url.pathname;
    const user = currentUser(req);
    const msg = url.searchParams.get('msg');

    if (req.method === 'GET') {
      if (path === '/') return send(res, 200, homePage(user, (url.searchParams.get('q') || '').trim(), msg));
      if (path === '/login')
        return send(res, 200, authForm(user, '로그인', `<label>아이디</label><input name="username" required autofocus><label>비밀번호</label><input name="password" type="password" required>`, '/login', '로그인', msg));
      if (path === '/signup')
        return send(res, 200, authForm(user, '회원가입', `<label>이름 (표시용)</label><input name="name" required maxlength="30"><label>아이디</label><input name="username" required pattern="[A-Za-z0-9_]{3,20}" title="영문, 숫자, _ 3~20자"><label>비밀번호 (8자 이상)</label><input name="password" type="password" required minlength="8"><label>동아리 가입 코드</label><input name="code" required>`, '/signup', '가입', msg));
      if (path === '/books/new') return user ? send(res, 200, bookForm(user)) : redirect(res, '/login', '로그인이 필요합니다.');
      if (path === '/my') return user ? send(res, 200, myPage(user, msg)) : redirect(res, '/login', '로그인이 필요합니다.');
      return send(res, 404, layout(user, '404', '<h1>페이지를 찾을 수 없습니다.</h1>'));
    }

    if (req.method !== 'POST') return send(res, 405, 'Method Not Allowed');
    const form = await readForm(req);

    if (path === '/signup') {
      const name = (form.name || '').trim();
      const username = (form.username || '').trim();
      const password = form.password || '';
      if (form.code !== CLUB_CODE) return redirect(res, '/signup', '동아리 가입 코드가 올바르지 않습니다.');
      if (!name || name.length > 30 || !/^\w{3,20}$/.test(username) || password.length < 8)
        return redirect(res, '/signup', '입력값을 확인해 주세요. (아이디 영문/숫자/_ 3~20자, 비밀번호 8자 이상)');
      if (q('SELECT 1 FROM users WHERE username = ?').get(username)) return redirect(res, '/signup', '이미 사용 중인 아이디입니다.');
      const { salt, hash } = hashPassword(password);
      const { lastInsertRowid } = q('INSERT INTO users (username, name, salt, hash) VALUES (?, ?, ?, ?)').run(username, name, salt, hash);
      return startSession(res, Number(lastInsertRowid), '/?msg=' + encodeURIComponent('가입을 환영합니다!'));
    }

    if (path === '/login') {
      const row = q('SELECT * FROM users WHERE username = ?').get((form.username || '').trim());
      if (!row || !verifyPassword(form.password || '', row.salt, row.hash))
        return redirect(res, '/login', '아이디 또는 비밀번호가 올바르지 않습니다.');
      return startSession(res, row.id, '/');
    }

    if (path === '/logout') {
      const token = parseCookies(req).sid;
      if (token) q('DELETE FROM sessions WHERE token = ?').run(token);
      return redirect(res, '/', null, { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0' });
    }

    if (!user) return redirect(res, '/login', '로그인이 필요합니다.');

    if (path === '/books') {
      const title = (form.title || '').trim();
      const author = (form.author || '').trim();
      const condition = ['상', '중', '하'].includes(form.condition) ? form.condition : '중';
      const note = (form.note || '').trim().slice(0, 500);
      if (!title || !author || title.length > 200 || author.length > 100) return redirect(res, '/books/new', '제목과 저자를 입력해 주세요.');
      q('INSERT INTO books (owner_id, title, author, condition, note) VALUES (?, ?, ?, ?, ?)').run(user.id, title, author, condition, note);
      return redirect(res, '/my', '책을 등록했습니다.');
    }

    let m;
    if ((m = path.match(/^\/books\/(\d+)\/(request|delete)$/))) {
      const book = q('SELECT * FROM books WHERE id = ?').get(Number(m[1]));
      if (!book) return redirect(res, '/', '책을 찾을 수 없습니다.');
      if (m[2] === 'request') {
        if (book.owner_id === user.id) return redirect(res, '/', '내 책은 요청할 수 없습니다.');
        if (q("SELECT 1 FROM loans WHERE book_id = ? AND status = 'approved'").get(book.id)) return redirect(res, '/', '이미 대여 중인 책입니다.');
        if (q("SELECT 1 FROM loans WHERE book_id = ? AND borrower_id = ? AND status = 'requested'").get(book.id, user.id))
          return redirect(res, '/', '이미 요청한 책입니다.');
        q("INSERT INTO loans (book_id, borrower_id, status) VALUES (?, ?, 'requested')").run(book.id, user.id);
        return redirect(res, '/my', '대여 요청을 보냈습니다. 주인이 승인하면 대여가 시작돼요.');
      }
      if (book.owner_id !== user.id) return redirect(res, '/', '권한이 없습니다.');
      if (q("SELECT 1 FROM loans WHERE book_id = ? AND status = 'approved'").get(book.id)) return redirect(res, '/my', '대여 중인 책은 삭제할 수 없습니다.');
      q('DELETE FROM books WHERE id = ?').run(book.id);
      return redirect(res, '/my', '책을 삭제했습니다.');
    }

    if ((m = path.match(/^\/loans\/(\d+)\/(approve|decline|return|cancel)$/))) {
      const loan = q('SELECT l.*, b.owner_id FROM loans l JOIN books b ON b.id = l.book_id WHERE l.id = ?').get(Number(m[1]));
      if (!loan) return redirect(res, '/my', '요청을 찾을 수 없습니다.');
      const action = m[2];
      const touch = (status, due = null) =>
        q("UPDATE loans SET status = ?, due_date = ?, updated_at = datetime('now') WHERE id = ?").run(status, due, loan.id);

      if (action === 'cancel') {
        if (loan.borrower_id !== user.id || loan.status !== 'requested') return redirect(res, '/my', '취소할 수 없습니다.');
        touch('cancelled');
        return redirect(res, '/my', '요청을 취소했습니다.');
      }
      if (loan.owner_id !== user.id) return redirect(res, '/my', '권한이 없습니다.');
      if (action === 'approve' || action === 'decline') {
        if (loan.status !== 'requested') return redirect(res, '/my', '처리할 수 없는 요청입니다.');
        if (action === 'decline') {
          touch('declined');
          return redirect(res, '/my', '요청을 거절했습니다.');
        }
        if (q("SELECT 1 FROM loans WHERE book_id = ? AND status = 'approved'").get(loan.book_id))
          return redirect(res, '/my', '이미 다른 사람에게 대여 중입니다.');
        touch('approved', new Date(Date.now() + LOAN_DAYS * 864e5).toISOString().slice(0, 10));
        return redirect(res, '/my', '대여를 승인했습니다.');
      }
      if (loan.status !== 'approved') return redirect(res, '/my', '대여 중인 책이 아닙니다.');
      touch('returned', loan.due_date);
      return redirect(res, '/my', '반납 처리했습니다.');
    }

    return send(res, 404, layout(user, '404', '<h1>페이지를 찾을 수 없습니다.</h1>'));
  } catch (err) {
    console.error(err);
    send(res, err.status || 500, '<h1>오류가 발생했습니다.</h1>');
  }
});

server.listen(PORT, () => {
  console.log(`동아리 책 나눔: http://localhost:${PORT}  (가입 코드: ${CLUB_CODE})`);
});
