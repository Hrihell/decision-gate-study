#!/usr/bin/env node
// 아주 작은 메모 프로그램. 메모는 SQLite 파일(memo.db)에 저장되어 껐다 켜도 남는다.
import readline from 'node:readline';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';

const dbPath = process.env.MEMO_DB ?? fileURLToPath(new URL('./memo.db', import.meta.url));
const db = new DatabaseSync(dbPath);
db.exec('CREATE TABLE IF NOT EXISTS memos (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL)');

const insert = db.prepare('INSERT INTO memos (text) VALUES (?)');
const selectAll = db.prepare('SELECT text FROM memos ORDER BY id');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log('메모를 입력하세요. "목록" 은 전체 보기, "끝" 은 종료.');
rl.on('line', (line) => {
  const text = line.trim();
  if (text === '끝') return rl.close();
  if (text === '목록') {
    selectAll.all().forEach((memo, i) => console.log(`${i + 1}. ${memo.text}`));
    return;
  }
  if (text !== '') insert.run(text);
});
rl.on('close', () => db.close());
