import json
import tkinter as tk
from pathlib import Path
from tkinter import simpledialog

DATA_FILE = Path.home() / ".todo_app.json"


class TodoApp:
    def __init__(self, root):
        self.root = root
        root.title("할 일 목록")
        root.geometry("420x560")
        root.minsize(320, 360)

        self.todos = self.load()
        self.filter = tk.StringVar(value="all")
        self.visible = []

        top = tk.Frame(root)
        top.pack(fill="x", padx=12, pady=(12, 6))
        self.entry = tk.Entry(top, font=("", 13))
        self.entry.pack(side="left", fill="x", expand=True, ipady=4)
        self.entry.bind("<Return>", lambda _e: self.add())
        tk.Button(top, text="추가", command=self.add).pack(side="left", padx=(6, 0))

        bar = tk.Frame(root)
        bar.pack(fill="x", padx=12)
        for label, value in (("전체", "all"), ("진행 중", "active"), ("완료", "done")):
            tk.Radiobutton(
                bar, text=label, value=value, variable=self.filter,
                command=self.render, indicatoron=False, padx=8,
            ).pack(side="left", padx=(0, 4))

        mid = tk.Frame(root)
        mid.pack(fill="both", expand=True, padx=12, pady=6)
        self.listbox = tk.Listbox(mid, font=("", 13), activestyle="none", selectmode="browse")
        scroll = tk.Scrollbar(mid, command=self.listbox.yview)
        self.listbox.config(yscrollcommand=scroll.set)
        self.listbox.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.listbox.bind("<Double-Button-1>", lambda _e: self.toggle())
        self.listbox.bind("<space>", lambda _e: self.toggle())
        self.listbox.bind("<Delete>", lambda _e: self.delete())
        self.listbox.bind("<BackSpace>", lambda _e: self.delete())

        actions = tk.Frame(root)
        actions.pack(fill="x", padx=12)
        tk.Button(actions, text="완료/해제", command=self.toggle).pack(side="left")
        tk.Button(actions, text="수정", command=self.edit).pack(side="left", padx=4)
        tk.Button(actions, text="삭제", command=self.delete).pack(side="left")
        tk.Button(actions, text="완료 항목 삭제", command=self.clear_done).pack(side="right")

        self.status = tk.Label(root, anchor="w", fg="gray")
        self.status.pack(fill="x", padx=12, pady=(6, 10))

        self.render()
        self.entry.focus_set()

    def load(self):
        try:
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []

    def save(self):
        DATA_FILE.write_text(json.dumps(self.todos, ensure_ascii=False, indent=2), encoding="utf-8")

    def render(self):
        mode = self.filter.get()
        self.visible = [
            t for t in self.todos
            if mode == "all" or (mode == "active" and not t["done"]) or (mode == "done" and t["done"])
        ]
        self.listbox.delete(0, "end")
        for t in self.visible:
            self.listbox.insert("end", ("☑ " if t["done"] else "☐ ") + t["text"])
            if t["done"]:
                self.listbox.itemconfig("end", fg="gray")
        remaining = sum(1 for t in self.todos if not t["done"])
        self.status.config(text=f"남은 할 일 {remaining}개 · 더블클릭/스페이스: 완료 전환")

    def selected(self):
        sel = self.listbox.curselection()
        return self.visible[sel[0]] if sel else None

    def add(self):
        text = self.entry.get().strip()
        if not text:
            return
        self.todos.append({"text": text, "done": False})
        self.entry.delete(0, "end")
        self.save()
        self.render()

    def toggle(self):
        todo = self.selected()
        if todo:
            todo["done"] = not todo["done"]
            self.save()
            self.render()

    def edit(self):
        todo = self.selected()
        if not todo:
            return
        text = simpledialog.askstring("수정", "내용:", initialvalue=todo["text"], parent=self.root)
        if text and text.strip():
            todo["text"] = text.strip()
            self.save()
            self.render()

    def delete(self):
        todo = self.selected()
        if todo:
            self.todos.remove(todo)
            self.save()
            self.render()

    def clear_done(self):
        self.todos = [t for t in self.todos if not t["done"]]
        self.save()
        self.render()


if __name__ == "__main__":
    root = tk.Tk()
    TodoApp(root)
    root.mainloop()
