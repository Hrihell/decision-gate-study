const form = document.getElementById('add-form');
const input = document.getElementById('new-todo');
const list = document.getElementById('list');
const count = document.getElementById('count');
const filterButtons = document.querySelectorAll('#filters button');

let todos = [];
let filter = 'all';

function persist() {
  window.api.save(todos);
}

function visibleTodos() {
  if (filter === 'active') return todos.filter((t) => !t.done);
  if (filter === 'done') return todos.filter((t) => t.done);
  return todos;
}

function startEdit(todo, li) {
  const textEl = li.querySelector('.text');
  const editor = document.createElement('input');
  editor.className = 'edit';
  editor.value = todo.text;
  textEl.replaceWith(editor);
  editor.focus();

  let finished = false;
  const finish = (save) => {
    if (finished) return;
    finished = true;
    const value = editor.value.trim();
    if (save && value) {
      todo.text = value;
      persist();
    }
    render();
  };
  editor.addEventListener('blur', () => finish(true));
  editor.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') finish(true);
    if (e.key === 'Escape') finish(false);
  });
}

function render() {
  list.innerHTML = '';
  const items = visibleTodos();

  if (items.length === 0) {
    const empty = document.createElement('li');
    empty.className = 'empty';
    empty.textContent = '할 일이 없습니다';
    list.appendChild(empty);
  }

  for (const todo of items) {
    const li = document.createElement('li');
    if (todo.done) li.classList.add('done');

    const check = document.createElement('input');
    check.type = 'checkbox';
    check.checked = todo.done;
    check.addEventListener('change', () => {
      todo.done = check.checked;
      persist();
      render();
    });

    const text = document.createElement('span');
    text.className = 'text';
    text.textContent = todo.text;
    text.addEventListener('dblclick', () => startEdit(todo, li));

    const del = document.createElement('button');
    del.className = 'delete';
    del.type = 'button';
    del.textContent = '×';
    del.title = '삭제';
    del.addEventListener('click', () => {
      todos = todos.filter((t) => t.id !== todo.id);
      persist();
      render();
    });

    li.append(check, text, del);
    list.appendChild(li);
  }

  const remaining = todos.filter((t) => !t.done).length;
  count.textContent = `남은 할 일 ${remaining}개`;
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  todos.push({ id: Date.now() + Math.random(), text, done: false });
  input.value = '';
  persist();
  render();
});

filterButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    filter = btn.dataset.filter;
    filterButtons.forEach((b) => b.classList.toggle('active', b === btn));
    render();
  });
});

document.getElementById('clear-done').addEventListener('click', () => {
  todos = todos.filter((t) => !t.done);
  persist();
  render();
});

window.api.load().then((saved) => {
  todos = saved;
  render();
});
