#!/usr/bin/env python3
"""downloads 폴더의 파일을 확장자별 하위 폴더로 정리한다.

사용법:
    python3 organize_downloads.py              # ./downloads 정리
    python3 organize_downloads.py --dry-run    # 실제 이동 없이 결과만 미리보기
    python3 organize_downloads.py 다른/폴더     # 다른 폴더 정리
"""

import argparse
import shutil
from pathlib import Path

NO_EXT_FOLDER = "확장자없음"


def unique_path(path: Path) -> Path:
    """같은 이름의 파일이 있으면 '이름 (1).확장자' 형태로 피한다."""
    if not path.exists():
        return path
    n = 1
    while True:
        candidate = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not candidate.exists():
            return candidate
        n += 1


def organize(target: Path, dry_run: bool) -> int:
    moved = 0
    for item in sorted(target.iterdir()):
        if not item.is_file() or item.name.startswith("."):
            continue

        folder_name = item.suffix.lstrip(".").lower() or NO_EXT_FOLDER
        dest_dir = target / folder_name
        dest = unique_path(dest_dir / item.name)

        print(f"{item.name}  ->  {dest.relative_to(target)}")
        if not dry_run:
            dest_dir.mkdir(exist_ok=True)
            shutil.move(str(item), str(dest))
        moved += 1
    return moved


def main() -> None:
    parser = argparse.ArgumentParser(description="폴더 내 파일을 확장자별로 정리")
    parser.add_argument(
        "folder",
        nargs="?",
        default=Path(__file__).resolve().parent / "downloads",
        type=Path,
        help="정리할 폴더 (기본값: 스크립트 옆의 downloads)",
    )
    parser.add_argument("--dry-run", action="store_true", help="이동하지 않고 미리보기만")
    args = parser.parse_args()

    if not args.folder.is_dir():
        parser.error(f"폴더를 찾을 수 없습니다: {args.folder}")

    count = organize(args.folder, args.dry_run)
    label = "이동 예정" if args.dry_run else "이동 완료"
    print(f"\n{label}: {count}개 파일")


if __name__ == "__main__":
    main()
