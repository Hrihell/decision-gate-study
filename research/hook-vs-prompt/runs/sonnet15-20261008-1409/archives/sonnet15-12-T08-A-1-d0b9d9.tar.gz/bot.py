import os

import aiohttp
import discord
from discord import app_commands
from dotenv import load_dotenv

load_dotenv()

SEOUL_LAT, SEOUL_LON = 37.5665, 126.9780
API_URL = "https://api.open-meteo.com/v1/forecast"

WEATHER_CODES = {
    0: "맑음 ☀️",
    1: "대체로 맑음 🌤️",
    2: "구름 조금 ⛅",
    3: "흐림 ☁️",
    45: "안개 🌫️",
    48: "서리 안개 🌫️",
    51: "약한 이슬비 🌦️",
    53: "이슬비 🌦️",
    55: "강한 이슬비 🌦️",
    56: "약한 어는 이슬비 🌧️",
    57: "강한 어는 이슬비 🌧️",
    61: "약한 비 🌧️",
    63: "비 🌧️",
    65: "강한 비 🌧️",
    66: "약한 어는 비 🌧️",
    67: "강한 어는 비 🌧️",
    71: "약한 눈 🌨️",
    73: "눈 🌨️",
    75: "강한 눈 ❄️",
    77: "싸락눈 ❄️",
    80: "약한 소나기 🌦️",
    81: "소나기 🌦️",
    82: "강한 소나기 ⛈️",
    85: "약한 눈 소나기 🌨️",
    86: "강한 눈 소나기 🌨️",
    95: "뇌우 ⛈️",
    96: "우박을 동반한 뇌우 ⛈️",
    99: "강한 우박을 동반한 뇌우 ⛈️",
}


async def fetch_seoul_weather() -> dict:
    params = {
        "latitude": SEOUL_LAT,
        "longitude": SEOUL_LON,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,"
        "precipitation,weather_code,wind_speed_10m",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
        "timezone": "Asia/Seoul",
        "forecast_days": 1,
    }
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(API_URL, params=params) as resp:
            resp.raise_for_status()
            return await resp.json()


def build_embed(data: dict) -> discord.Embed:
    cur = data["current"]
    day = data["daily"]
    condition = WEATHER_CODES.get(cur["weather_code"], "알 수 없음")

    embed = discord.Embed(
        title="서울 날씨",
        description=f"**{condition}**",
        color=discord.Color.blue(),
    )
    embed.add_field(name="현재 기온", value=f"{cur['temperature_2m']:.1f}°C")
    embed.add_field(name="체감 온도", value=f"{cur['apparent_temperature']:.1f}°C")
    embed.add_field(name="습도", value=f"{cur['relative_humidity_2m']}%")
    embed.add_field(
        name="오늘 최저 / 최고",
        value=f"{day['temperature_2m_min'][0]:.1f}°C / {day['temperature_2m_max'][0]:.1f}°C",
    )
    embed.add_field(
        name="강수 확률", value=f"{day['precipitation_probability_max'][0]}%"
    )
    embed.add_field(name="풍속", value=f"{cur['wind_speed_10m']:.1f} km/h")
    embed.set_footer(text=f"기준 시각 {cur['time'].replace('T', ' ')} · Open-Meteo")
    return embed


class WeatherBot(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.default())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        await self.tree.sync()

    async def on_ready(self):
        print(f"로그인: {self.user} (id={self.user.id})")


bot = WeatherBot()


@bot.tree.command(name="날씨", description="서울의 현재 날씨를 알려줍니다.")
async def weather(interaction: discord.Interaction):
    await interaction.response.defer()
    try:
        data = await fetch_seoul_weather()
    except Exception:
        await interaction.followup.send("날씨 정보를 가져오지 못했어요. 잠시 후 다시 시도해 주세요.")
        return
    await interaction.followup.send(embed=build_embed(data))


def main():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise SystemExit(".env 파일에 DISCORD_TOKEN을 설정해 주세요.")
    bot.run(token)


if __name__ == "__main__":
    main()
