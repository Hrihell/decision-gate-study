const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const SESSION_MS = 7 * 24 * 3600 * 1000;
const db = new DatabaseSync(path.join(__dirname, 'gagyebu.db'));
db.exec(`
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    salt TEXT NOT NULL,
    hash TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('income','expense')),
    amount INTEGER NOT NULL CHECK (amount > 0),
    category TEXT NOT NULL,
    memo TEXT NOT NULL DEFAULT '',
    date TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
`);

const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const send = (res, code, body, headers = {}) => {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', ...headers });
  res.end(JSON.stringify(body));
};
const readBody = (req) => new Promise((resolve, reject) => {
  let data = '';
  req.on('data', (c) => { data += c; if (data.length > 1e5) { reject(new Error('too large')); req.destroy(); } });
  req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); } });
});
const getCookie = (req, name) => {
  const m = (req.headers.cookie || '').split(';').map((s) => s.trim()).find((s) => s.startsWith(name + '='));
  return m ? decodeURIComponent(m.slice(name.length + 1)) : null;
};
const userFrom = (req) => {
  const token = getCookie(req, 'sid');
  if (!token) return null;
  const s = db.prepare('SELECT user_id, expires FROM sessions WHERE token = ?').get(token);
  if (!s || s.expires < Date.now()) return null;
  return s.user_id;
};
const startSession = (res, userId, extra = {}) => {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions (token, user_id, expires) VALUES (?,?,?)').run(token, userId, Date.now() + SESSION_MS);
  return { 'Set-Cookie': `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_MS / 1000}` };
};
const validTx = (b) => {
  const amount = Number(b.amount);
  if (!['income', 'expense'].includes(b.type)) return '구분이 올바르지 않습니다.';
  if (!Number.isInteger(amount) || amount <= 0) return '금액은 1 이상의 정수여야 합니다.';
  if (!b.category || String(b.category).length > 30) return '카테고리를 입력하세요(30자 이내).';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.date || '')) return '날짜 형식이 올바르지 않습니다.';
  if (String(b.memo || '').length > 200) return '메모는 200자 이내여야 합니다.';
  return null;
};

const routes = {
  'POST /api/register': async (req, res) => {
    const { username, password } = await readBody(req);
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username || '')) return send(res, 400, { error: '아이디는 영문/숫자/_ 3~20자입니다.' });
    if (!password || password.length < 6) return send(res, 400, { error: '비밀번호는 6자 이상이어야 합니다.' });
    if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) return send(res, 409, { error: '이미 사용 중인 아이디입니다.' });
    const salt = crypto.randomBytes(16).toString('hex');
    const r = db.prepare('INSERT INTO users (username, salt, hash) VALUES (?,?,?)').run(username, salt, hashPw(password, salt));
    send(res, 201, { username }, startSession(res, Number(r.lastInsertRowid)));
  },
  'POST /api/login': async (req, res) => {
    const { username, password } = await readBody(req);
    const u = db.prepare('SELECT * FROM users WHERE username = ?').get(username || '');
    const ok = u && crypto.timingSafeEqual(Buffer.from(hashPw(String(password || ''), u.salt)), Buffer.from(u.hash));
    if (!ok) return send(res, 401, { error: '아이디 또는 비밀번호가 올바르지 않습니다.' });
    send(res, 200, { username }, startSession(res, u.id));
  },
  'POST /api/logout': async (req, res) => {
    const token = getCookie(req, 'sid');
    if (token) db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; HttpOnly; Path=/; Max-Age=0' });
  },
  'GET /api/me': async (req, res) => {
    const uid = userFrom(req);
    if (!uid) return send(res, 401, { error: '로그인이 필요합니다.' });
    send(res, 200, db.prepare('SELECT username FROM users WHERE id = ?').get(uid));
  },
  'GET /api/transactions': async (req, res, uid, url) => {
    const month = url.searchParams.get('month') || new Date().toISOString().slice(0, 7);
    if (!/^\d{4}-\d{2}$/.test(month)) return send(res, 400, { error: '월 형식이 올바르지 않습니다.' });
    const items = db.prepare('SELECT id,type,amount,category,memo,date FROM transactions WHERE user_id = ? AND date LIKE ? ORDER BY date DESC, id DESC').all(uid, month + '-%');
    const byCategory = db.prepare("SELECT category, SUM(amount) AS total FROM transactions WHERE user_id = ? AND type='expense' AND date LIKE ? GROUP BY category ORDER BY total DESC").all(uid, month + '-%');
    const sum = (t) => items.filter((i) => i.type === t).reduce((a, i) => a + i.amount, 0);
    send(res, 200, { month, items, income: sum('income'), expense: sum('expense'), byCategory });
  },
  'POST /api/transactions': async (req, res, uid) => {
    const b = await readBody(req);
    const err = validTx(b);
    if (err) return send(res, 400, { error: err });
    const r = db.prepare('INSERT INTO transactions (user_id,type,amount,category,memo,date) VALUES (?,?,?,?,?,?)')
      .run(uid, b.type, Number(b.amount), String(b.category).trim(), String(b.memo || '').trim(), b.date);
    send(res, 201, { id: Number(r.lastInsertRowid) });
  },
};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const key = `${req.method} ${url.pathname}`;
    if (url.pathname.startsWith('/api/')) {
      const open = ['POST /api/register', 'POST /api/login', 'POST /api/logout', 'GET /api/me'];
      if (routes[key]) {
        const uid = open.includes(key) ? null : userFrom(req);
        if (!open.includes(key) && !uid) return send(res, 401, { error: '로그인이 필요합니다.' });
        return await routes[key](req, res, uid, url);
      }
      const m = url.pathname.match(/^\/api\/transactions\/(\d+)$/);
      if (m && ['PUT', 'DELETE'].includes(req.method)) {
        const uid = userFrom(req);
        if (!uid) return send(res, 401, { error: '로그인이 필요합니다.' });
        const id = Number(m[1]);
        if (req.method === 'DELETE') {
          const r = db.prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?').run(id, uid);
          return r.changes ? send(res, 200, { ok: true }) : send(res, 404, { error: '내역을 찾을 수 없습니다.' });
        }
        const b = await readBody(req);
        const err = validTx(b);
        if (err) return send(res, 400, { error: err });
        const r = db.prepare('UPDATE transactions SET type=?,amount=?,category=?,memo=?,date=? WHERE id=? AND user_id=?')
          .run(b.type, Number(b.amount), String(b.category).trim(), String(b.memo || '').trim(), b.date, id, uid);
        return r.changes ? send(res, 200, { ok: true }) : send(res, 404, { error: '내역을 찾을 수 없습니다.' });
      }
      return send(res, 404, { error: 'Not found' });
    }
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) {
    send(res, 400, { error: '잘못된 요청입니다.' });
  }
});
server.listen(PORT, () => console.log(`가계부 실행 중: http://localhost:${PORT}`));
