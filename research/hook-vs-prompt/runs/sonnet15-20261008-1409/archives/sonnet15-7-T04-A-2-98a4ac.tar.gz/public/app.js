const $ = (id) => document.getElementById(id);
const won = (n) => n.toLocaleString('ko-KR') + '원';

let mode = 'login';
let month = new Date().toISOString().slice(0, 7);
let editingId = null;
let items = [];

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' },
    body: method === 'GET' ? undefined : JSON.stringify(body ?? {}),
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && !url.startsWith('/api/login')) showAuth();
  if (!res.ok) throw new Error(data.error || '요청에 실패했습니다.');
  return data;
}

function showAuth() {
  $('app').hidden = true;
  $('auth').hidden = false;
}

function showApp(username) {
  $('auth').hidden = true;
  $('app').hidden = false;
  $('who').textContent = username;
  resetForm();
  load();
}

// ----- 인증 -----
function setMode(m) {
  mode = m;
  $('auth-submit').textContent = m === 'login' ? '로그인' : '회원가입';
  $('auth-toggle').textContent = m === 'login' ? '계정이 없으신가요? 회원가입' : '이미 계정이 있으신가요? 로그인';
  $('auth-form').password.autocomplete = m === 'login' ? 'current-password' : 'new-password';
  $('auth-error').textContent = '';
}

$('auth-toggle').onclick = () => setMode(mode === 'login' ? 'signup' : 'login');

$('auth-form').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.target;
  try {
    const r = await api('POST', mode === 'login' ? '/api/login' : '/api/signup', {
      username: f.username.value,
      password: f.password.value,
    });
    f.reset();
    showApp(r.username);
  } catch (err) {
    $('auth-error').textContent = err.message;
  }
};

$('logout').onclick = async () => {
  await api('POST', '/api/logout').catch(() => {});
  showAuth();
};

// ----- 월 이동 -----
function shiftMonth(delta) {
  const [y, m] = month.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  load();
}
$('prev').onclick = () => shiftMonth(-1);
$('next').onclick = () => shiftMonth(1);

// ----- 목록 -----
async function load() {
  const [y, m] = month.split('-');
  $('month-label').textContent = `${y}년 ${Number(m)}월`;
  try {
    items = await api('GET', `/api/transactions?month=${month}`);
  } catch {
    return;
  }
  render();
}

function render() {
  let income = 0, expense = 0;
  const byCat = new Map();
  for (const t of items) {
    if (t.type === 'income') income += t.amount;
    else {
      expense += t.amount;
      byCat.set(t.category, (byCat.get(t.category) || 0) + t.amount);
    }
  }
  $('sum-income').textContent = won(income);
  $('sum-expense').textContent = won(expense);
  $('sum-balance').textContent = won(income - expense);

  const bd = $('breakdown');
  bd.replaceChildren();
  for (const [cat, amt] of [...byCat].sort((a, b) => b[1] - a[1])) {
    const li = document.createElement('li');
    const line = document.createElement('div');
    line.className = 'line';
    const name = document.createElement('span');
    name.textContent = cat;
    const val = document.createElement('span');
    val.textContent = `${won(amt)} (${Math.round((amt / expense) * 100)}%)`;
    line.append(name, val);
    const bar = document.createElement('div');
    bar.className = 'bar';
    const fill = document.createElement('i');
    fill.style.width = `${(amt / expense) * 100}%`;
    bar.append(fill);
    li.append(line, bar);
    bd.append(li);
  }

  const dl = $('categories');
  dl.replaceChildren();
  for (const c of new Set(items.map((t) => t.category))) {
    const o = document.createElement('option');
    o.value = c;
    dl.append(o);
  }

  const list = $('list');
  list.replaceChildren();
  $('empty').hidden = items.length > 0;
  for (const t of items) {
    const li = document.createElement('li');
    const left = document.createElement('div');
    const title = document.createElement('div');
    title.textContent = t.category;
    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = t.memo ? `${t.date} · ${t.memo}` : t.date;
    left.append(title, meta);

    const right = document.createElement('div');
    const amt = document.createElement('b');
    amt.className = t.type;
    amt.textContent = (t.type === 'income' ? '+' : '-') + won(t.amount);
    const actions = document.createElement('span');
    actions.className = 'actions';
    const edit = document.createElement('button');
    edit.textContent = '수정';
    edit.onclick = () => startEdit(t);
    const del = document.createElement('button');
    del.textContent = '삭제';
    del.className = 'del';
    del.onclick = () => remove(t);
    actions.append(edit, del);
    right.append(amt, actions);

    li.append(left, right);
    list.append(li);
  }
}

// ----- 입력 폼 -----
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function resetForm() {
  editingId = null;
  const f = $('tx-form');
  f.reset();
  f.date.value = today();
  $('form-title').textContent = '내역 추가';
  $('tx-submit').textContent = '추가';
  $('tx-cancel').hidden = true;
  $('tx-error').textContent = '';
}

function startEdit(t) {
  editingId = t.id;
  const f = $('tx-form');
  f.type.value = t.type;
  f.date.value = t.date;
  f.category.value = t.category;
  f.amount.value = t.amount;
  f.memo.value = t.memo;
  $('form-title').textContent = '내역 수정';
  $('tx-submit').textContent = '저장';
  $('tx-cancel').hidden = false;
  f.scrollIntoView({ behavior: 'smooth' });
}

$('tx-cancel').onclick = resetForm;

$('tx-form').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.target;
  const body = {
    type: f.type.value,
    date: f.date.value,
    category: f.category.value,
    amount: Number(f.amount.value),
    memo: f.memo.value,
  };
  try {
    if (editingId) await api('PUT', `/api/transactions/${editingId}`, body);
    else await api('POST', '/api/transactions', body);
    month = body.date.slice(0, 7);
    resetForm();
    load();
  } catch (err) {
    $('tx-error').textContent = err.message;
  }
};

async function remove(t) {
  if (!confirm(`'${t.category} ${won(t.amount)}' 내역을 삭제할까요?`)) return;
  try {
    await api('DELETE', `/api/transactions/${t.id}`);
    if (editingId === t.id) resetForm();
    load();
  } catch (err) {
    $('tx-error').textContent = err.message;
  }
}

// ----- 시작 -----
(async () => {
  try {
    const me = await api('GET', '/api/me');
    showApp(me.username);
  } catch {
    showAuth();
  }
})();
