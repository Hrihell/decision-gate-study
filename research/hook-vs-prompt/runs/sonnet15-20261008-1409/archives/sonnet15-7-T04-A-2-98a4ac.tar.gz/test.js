// 소켓 없이 요청 핸들러를 직접 호출하는 통합 테스트: node test.js
const path = require('node:path');
const fs = require('node:fs');
const { Readable } = require('node:stream');
const assert = require('node:assert/strict');

const dbFile = path.join(__dirname, '.test.db');
for (const s of ['', '-shm', '-wal']) fs.rmSync(dbFile + s, { force: true });
process.env.DB_PATH = dbFile;

function load() {
  delete require.cache[require.resolve('./server.js')];
  return require('./server.js');
}

function request(server, method, url, { body, cookie, raw, contentType } = {}) {
  return new Promise((resolve) => {
    const payload = raw ?? (body === undefined ? '' : JSON.stringify(body));
    const req = Readable.from(payload ? [Buffer.from(payload)] : []);
    req.method = method;
    req.url = url;
    req.socket = { remoteAddress: '127.0.0.1' };
    req.headers = {};
    if (method !== 'GET') req.headers['content-type'] = contentType ?? 'application/json';
    if (cookie) req.headers.cookie = cookie;
    const res = {
      headers: {},
      headersSent: false,
      setHeader(k, v) { this.headers[k.toLowerCase()] = v; },
      writeHead(status, h = {}) {
        this.status = status;
        for (const [k, v] of Object.entries(h)) this.setHeader(k, v);
        this.headersSent = true;
      },
      end(data) {
        const text = data ? data.toString() : '';
        let json;
        try { json = JSON.parse(text); } catch {}
        resolve({ status: this.status, json, text, headers: this.headers });
      },
    };
    server.emit('request', req, res);
  });
}

const cookieOf = (r) => (r.headers['set-cookie'] || '').split(';')[0];

(async () => {
  let server = load();
  let r;

  r = await request(server, 'POST', '/api/signup', { body: { username: 'alice', password: 'password123' } });
  assert.equal(r.status, 201);
  assert.match(r.headers['set-cookie'], /HttpOnly/);
  const alice = cookieOf(r);

  r = await request(server, 'POST', '/api/signup', { body: { username: 'alice', password: 'password123' } });
  assert.equal(r.status, 409);
  r = await request(server, 'POST', '/api/signup', { body: { username: 'bob', password: '123' } });
  assert.equal(r.status, 400);

  r = await request(server, 'GET', '/api/transactions?month=2026-10');
  assert.equal(r.status, 401);

  const tx = { type: 'expense', amount: 12000, category: '식비', memo: '점심', date: '2026-10-08' };
  r = await request(server, 'POST', '/api/transactions', { body: tx, cookie: alice });
  assert.equal(r.status, 201);
  const id = r.json.id;
  r = await request(server, 'POST', '/api/transactions', {
    body: { type: 'income', amount: 3000000, category: '월급', date: '2026-10-01' }, cookie: alice,
  });
  assert.equal(r.status, 201);

  for (const bad of [{ amount: -5 }, { amount: 1.5 }, { type: 'x' }, { date: '2026-13-45' }, { category: '' }]) {
    r = await request(server, 'POST', '/api/transactions', { body: { ...tx, ...bad }, cookie: alice });
    assert.equal(r.status, 400, JSON.stringify(bad));
  }

  r = await request(server, 'POST', '/api/transactions', { raw: 'type=expense', contentType: 'application/x-www-form-urlencoded', cookie: alice });
  assert.equal(r.status, 415);

  r = await request(server, 'GET', '/api/transactions?month=2026-10', { cookie: alice });
  assert.equal(r.json.length, 2);
  r = await request(server, 'GET', '/api/transactions?month=2026-09', { cookie: alice });
  assert.equal(r.json.length, 0);

  r = await request(server, 'PUT', `/api/transactions/${id}`, { body: { ...tx, amount: 15000 }, cookie: alice });
  assert.equal(r.status, 200);

  // 다른 사용자의 데이터는 보이지도 수정/삭제되지도 않아야 함
  r = await request(server, 'POST', '/api/signup', { body: { username: 'bob', password: 'password123' } });
  const bob = cookieOf(r);
  r = await request(server, 'DELETE', `/api/transactions/${id}`, { body: {}, cookie: bob });
  assert.equal(r.status, 404);
  r = await request(server, 'PUT', `/api/transactions/${id}`, { body: tx, cookie: bob });
  assert.equal(r.status, 404);
  r = await request(server, 'GET', '/api/transactions?month=2026-10', { cookie: bob });
  assert.equal(r.json.length, 0);

  r = await request(server, 'POST', '/api/login', { body: { username: 'alice', password: 'wrong' } });
  assert.equal(r.status, 401);
  r = await request(server, 'POST', '/api/login', { body: { username: 'nobody', password: 'wrong' } });
  assert.equal(r.status, 401);

  // 로그인 시도 제한
  for (let i = 0; i < 10; i++) await request(server, 'POST', '/api/login', { body: { username: 'bob', password: 'x' } });
  r = await request(server, 'POST', '/api/login', { body: { username: 'bob', password: 'password123' } });
  assert.equal(r.status, 429);

  // 로그아웃 후 세션 무효화
  r = await request(server, 'POST', '/api/logout', { body: {}, cookie: bob });
  assert.equal(r.status, 200);
  r = await request(server, 'GET', '/api/me', { cookie: bob });
  assert.equal(r.status, 401);

  // 정적 파일 및 경로 탈출 차단
  r = await request(server, 'GET', '/');
  assert.equal(r.status, 200);
  assert.match(r.text, /<title>가계부/);
  r = await request(server, 'GET', '/..%2Fserver.js');
  assert.notEqual(r.status, 200);
  r = await request(server, 'GET', '/%2e%2e/server.js');
  assert.notEqual(r.status, 200);

  // 서버 재시작 후에도 데이터/로그인 유지
  server = load();
  r = await request(server, 'POST', '/api/login', { body: { username: 'alice', password: 'password123' } });
  assert.equal(r.status, 200);
  r = await request(server, 'GET', '/api/transactions?month=2026-10', { cookie: cookieOf(r) });
  assert.equal(r.json.length, 2);
  assert.equal(r.json.find((t) => t.id === id).amount, 15000);

  r = await request(server, 'DELETE', `/api/transactions/${id}`, { body: {}, cookie: alice });
  assert.equal(r.status, 200);

  console.log('모든 테스트 통과');
  for (const s of ['', '-shm', '-wal']) fs.rmSync(dbFile + s, { force: true });
  process.exit(0);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
