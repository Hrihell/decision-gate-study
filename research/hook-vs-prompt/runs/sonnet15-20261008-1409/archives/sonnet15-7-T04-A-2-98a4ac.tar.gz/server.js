const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT) || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data.db');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_DAYS = 14;

const db = new DatabaseSync(DB_PATH);
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('income','expense')),
    amount INTEGER NOT NULL CHECK (amount > 0),
    category TEXT NOT NULL,
    memo TEXT NOT NULL DEFAULT '',
    date TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
`);

const q = {
  findUser: db.prepare('SELECT * FROM users WHERE username = ?'),
  addUser: db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)'),
  addSession: db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)'),
  findSession: db.prepare(
    'SELECT u.id, u.username FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?'
  ),
  delSession: db.prepare('DELETE FROM sessions WHERE token_hash = ?'),
  purgeSessions: db.prepare('DELETE FROM sessions WHERE expires_at <= ?'),
  listTx: db.prepare(
    "SELECT id, type, amount, category, memo, date FROM transactions WHERE user_id = ? AND substr(date, 1, 7) = ? ORDER BY date DESC, id DESC"
  ),
  addTx: db.prepare(
    'INSERT INTO transactions (user_id, type, amount, category, memo, date) VALUES (?, ?, ?, ?, ?, ?)'
  ),
  updTx: db.prepare(
    'UPDATE transactions SET type = ?, amount = ?, category = ?, memo = ?, date = ? WHERE id = ? AND user_id = ?'
  ),
  delTx: db.prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?'),
};

// ---------- helpers ----------
const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, 64);
  return `${salt.toString('hex')}:${key.toString('hex')}`;
}

function verifyPassword(pw, stored) {
  const [saltHex, keyHex] = stored.split(':');
  const expected = Buffer.from(keyHex, 'hex');
  const actual = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), expected.length);
  return crypto.timingSafeEqual(expected, actual);
}

const DUMMY_HASH = hashPassword('dummy-password-for-timing');

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function send(res, status, body, headers = {}) {
  const isJson = typeof body !== 'string' && !Buffer.isBuffer(body);
  const payload = isJson ? JSON.stringify(body) : body;
  res.writeHead(status, {
    'Content-Type': isJson ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...headers,
  });
  res.end(payload);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 50_000) {
        reject(Object.assign(new Error('요청이 너무 큽니다.'), { status: 413 }));
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(Object.assign(new Error('잘못된 JSON 입니다.'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

function setSessionCookie(res, token, maxAgeSec) {
  const secure = process.env.COOKIE_SECURE === '1' ? '; Secure' : '';
  res.setHeader(
    'Set-Cookie',
    `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAgeSec}${secure}`
  );
}

function createSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  q.addSession.run(hashToken(token), userId, Date.now() + SESSION_DAYS * 86400_000);
  setSessionCookie(res, token, SESSION_DAYS * 86400);
}

function currentUser(req) {
  const token = parseCookies(req.headers.cookie).sid;
  if (!token) return null;
  return q.findSession.get(hashToken(token), Date.now()) || null;
}

// 로그인 시도 제한 (IP+아이디 기준, 15분에 10회)
const attempts = new Map();
function tooManyAttempts(key) {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || rec.reset < now) return false;
  return rec.count >= 10;
}
function recordFailure(key) {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || rec.reset < now) attempts.set(key, { count: 1, reset: now + 15 * 60_000 });
  else rec.count++;
}

function fail(status, message) {
  return Object.assign(new Error(message), { status });
}

function validateTx(b) {
  const type = b.type;
  const amount = Number(b.amount);
  const category = String(b.category ?? '').trim();
  const memo = String(b.memo ?? '').trim();
  const date = String(b.date ?? '');
  if (type !== 'income' && type !== 'expense') throw fail(400, '구분(수입/지출)이 올바르지 않습니다.');
  if (!Number.isInteger(amount) || amount <= 0 || amount > 1_000_000_000_000)
    throw fail(400, '금액은 1 이상의 정수여야 합니다.');
  if (!category || category.length > 30) throw fail(400, '카테고리는 1~30자여야 합니다.');
  if (memo.length > 200) throw fail(400, '메모는 200자 이하여야 합니다.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date)))
    throw fail(400, '날짜 형식이 올바르지 않습니다.');
  return { type, amount, category, memo, date };
}

// ---------- API ----------
async function handleApi(req, res, url) {
  const { pathname } = url;
  const method = req.method;

  // 브라우저 폼을 이용한 교차 사이트 요청 차단: 변경 요청은 JSON만 허용
  if (method !== 'GET' && !(req.headers['content-type'] || '').startsWith('application/json'))
    throw fail(415, 'Content-Type 은 application/json 이어야 합니다.');

  if (pathname === '/api/signup' && method === 'POST') {
    const b = await readJson(req);
    const username = String(b.username ?? '').trim().toLowerCase();
    const password = String(b.password ?? '');
    if (!/^[a-z0-9_]{3,20}$/.test(username))
      throw fail(400, '아이디는 영문 소문자/숫자/_ 3~20자여야 합니다.');
    if (password.length < 8 || password.length > 200)
      throw fail(400, '비밀번호는 8자 이상이어야 합니다.');
    if (q.findUser.get(username)) throw fail(409, '이미 사용 중인 아이디입니다.');
    const { lastInsertRowid } = q.addUser.run(username, hashPassword(password));
    createSession(res, Number(lastInsertRowid));
    return send(res, 201, { username });
  }

  if (pathname === '/api/login' && method === 'POST') {
    const b = await readJson(req);
    const username = String(b.username ?? '').trim().toLowerCase();
    const password = String(b.password ?? '');
    const key = `${req.socket.remoteAddress}|${username}`;
    if (tooManyAttempts(key)) throw fail(429, '로그인 시도가 너무 많습니다. 잠시 후 다시 시도하세요.');
    const user = q.findUser.get(username);
    const ok = verifyPassword(password, user ? user.password_hash : DUMMY_HASH) && user;
    if (!ok) {
      recordFailure(key);
      throw fail(401, '아이디 또는 비밀번호가 올바르지 않습니다.');
    }
    attempts.delete(key);
    createSession(res, user.id);
    return send(res, 200, { username: user.username });
  }

  if (pathname === '/api/logout' && method === 'POST') {
    const token = parseCookies(req.headers.cookie).sid;
    if (token) q.delSession.run(hashToken(token));
    setSessionCookie(res, '', 0);
    return send(res, 200, { ok: true });
  }

  const user = currentUser(req);
  if (!user) throw fail(401, '로그인이 필요합니다.');

  if (pathname === '/api/me' && method === 'GET') return send(res, 200, { username: user.username });

  if (pathname === '/api/transactions' && method === 'GET') {
    const month = url.searchParams.get('month') || '';
    if (!/^\d{4}-\d{2}$/.test(month)) throw fail(400, 'month 형식은 YYYY-MM 이어야 합니다.');
    return send(res, 200, q.listTx.all(user.id, month));
  }

  if (pathname === '/api/transactions' && method === 'POST') {
    const t = validateTx(await readJson(req));
    const { lastInsertRowid } = q.addTx.run(user.id, t.type, t.amount, t.category, t.memo, t.date);
    return send(res, 201, { id: Number(lastInsertRowid), ...t });
  }

  const m = pathname.match(/^\/api\/transactions\/(\d+)$/);
  if (m) {
    const id = Number(m[1]);
    if (method === 'PUT') {
      const t = validateTx(await readJson(req));
      const r = q.updTx.run(t.type, t.amount, t.category, t.memo, t.date, id, user.id);
      if (!r.changes) throw fail(404, '내역을 찾을 수 없습니다.');
      return send(res, 200, { id, ...t });
    }
    if (method === 'DELETE') {
      const r = q.delTx.run(id, user.id);
      if (!r.changes) throw fail(404, '내역을 찾을 수 없습니다.');
      return send(res, 200, { ok: true });
    }
  }

  throw fail(404, '존재하지 않는 API 입니다.');
}

// ---------- static ----------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
};

function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method Not Allowed');
  let rel;
  try {
    rel = decodeURIComponent(url.pathname);
  } catch {
    return send(res, 400, 'Bad Request');
  }
  if (rel === '/') rel = '/index.html';
  const file = path.join(PUBLIC_DIR, rel);
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return send(res, 403, 'Forbidden');
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Not Found');
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'",
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-cache',
    });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url);
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    if (!res.headersSent) send(res, status, { error: status === 500 ? '서버 오류가 발생했습니다.' : e.message });
  }
});

setInterval(() => q.purgeSessions.run(Date.now()), 3600_000).unref();

if (require.main === module) {
  server.listen(PORT, () => console.log(`가계부 서버 실행 중: http://localhost:${PORT}`));
}

module.exports = server;
