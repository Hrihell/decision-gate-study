const LEGACY_TODOS_KEY = 'todos';

let currentUser = null;
let todos = [];
let authMode = 'login';

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = res.status === 204 ? null : await res.json().catch(() => null);
  if (!res.ok) {
    const error = new Error((data && data.error) || '요청에 실패했습니다.');
    error.status = res.status;
    throw error;
  }
  return data;
}

async function saveTodos(next) {
  const previous = todos;
  todos = next;
  render();
  try {
    await api('PUT', '/api/todos', next);
  } catch (err) {
    if (err.status === 401) return showAuth();
    todos = previous;
    render();
    alert(err.message);
  }
}

function render() {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      saveTodos(todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t)));
    });
    list.appendChild(item);
  });
}

async function showTodos(username) {
  currentUser = username;
  todos = await api('GET', '/api/todos');
  document.getElementById('auth-view').hidden = true;
  document.getElementById('todo-view').hidden = false;
  document.getElementById('current-user').textContent = username;
  render();
}

function setAuthMode(mode) {
  authMode = mode;
  const isLogin = mode === 'login';
  document.getElementById('auth-title').textContent = isLogin ? '로그인' : '회원가입';
  document.getElementById('auth-submit').textContent = isLogin ? '로그인' : '가입하기';
  document.getElementById('auth-switch-text').textContent = isLogin
    ? '계정이 없으신가요?'
    : '이미 계정이 있으신가요?';
  document.getElementById('auth-switch').textContent = isLogin ? '회원가입' : '로그인';
  document.getElementById('auth-password').autocomplete = isLogin
    ? 'current-password'
    : 'new-password';
  document.getElementById('auth-error').textContent = '';
}

function showAuth() {
  currentUser = null;
  todos = [];
  document.getElementById('todo-view').hidden = true;
  document.getElementById('auth-view').hidden = false;
  document.getElementById('auth-form').reset();
  setAuthMode('login');
}

// 로그인 도입 전에 브라우저에 쌓인 할 일을 방금 가입한 계정으로 옮긴다
async function migrateLegacyTodos() {
  const raw = localStorage.getItem(LEGACY_TODOS_KEY);
  if (!raw) return;
  try {
    await api('PUT', '/api/todos', JSON.parse(raw));
    localStorage.removeItem(LEGACY_TODOS_KEY);
  } catch {
    // 형식이 맞지 않으면 옮기지 않고 그대로 둔다
  }
}

document.getElementById('auth-switch').addEventListener('click', () => {
  setAuthMode(authMode === 'login' ? 'signup' : 'login');
});

document.getElementById('auth-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const username = document.getElementById('auth-username').value.trim();
  const password = document.getElementById('auth-password').value;
  const errorEl = document.getElementById('auth-error');
  const submit = document.getElementById('auth-submit');
  errorEl.textContent = '';
  if (!username) return;

  submit.disabled = true;
  try {
    const isSignup = authMode === 'signup';
    await api('POST', isSignup ? '/api/signup' : '/api/login', { username, password });
    if (isSignup) await migrateLegacyTodos();
    await showTodos(username);
  } catch (err) {
    errorEl.textContent = err.message;
  } finally {
    submit.disabled = false;
  }
});

document.getElementById('logout').addEventListener('click', async () => {
  await api('POST', '/api/logout').catch(() => {});
  showAuth();
});

document.getElementById('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = document.getElementById('new-todo');
  const text = input.value.trim();
  if (text === '') return;
  saveTodos([...todos, { text, done: false }]);
  input.value = '';
});

api('GET', '/api/me')
  .then(({ username }) => showTodos(username))
  .catch(showAuth);
