const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT) || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_BODY_BYTES = 100 * 1024;
const MAX_TODOS = 1000;
const MAX_TODO_LENGTH = 500;
const USERNAME_RE = /^[A-Za-z0-9_.-]{3,32}$/;
const MIN_PASSWORD_LENGTH = 8;

const STATIC_FILES = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/style.css': ['style.css', 'text/css; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
};

let users = [];
try {
  users = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')).users;
} catch (err) {
  if (err.code !== 'ENOENT') throw err;
}

const sessions = new Map();

function persist() {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify({ users }), { mode: 0o600 });
  fs.renameSync(tmp, DATA_FILE);
}

function findUser(username) {
  return users.find((u) => u.username === username);
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64);
}

function send(res, status, body, headers = {}) {
  const isJson = typeof body !== 'string' && !Buffer.isBuffer(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(isJson ? JSON.stringify(body) : body);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    if (!(req.headers['content-type'] || '').startsWith('application/json')) {
      return reject(Object.assign(new Error('JSON 요청만 허용됩니다.'), { status: 415 }));
    }
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('요청이 너무 큽니다.'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(Object.assign(new Error('잘못된 JSON입니다.'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

function getSessionToken(req) {
  const match = /(?:^|;\s*)sid=([0-9a-f]{64})/.exec(req.headers.cookie || '');
  return match ? match[1] : null;
}

function getSessionUser(req) {
  const token = getSessionToken(req);
  const session = token && sessions.get(token);
  if (!session) return null;
  if (session.expires < Date.now()) {
    sessions.delete(token);
    return null;
  }
  return findUser(session.username) || null;
}

function startSession(res, username) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { username, expires: Date.now() + SESSION_TTL_MS });
  return `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_TTL_MS / 1000}`;
}

function validTodos(todos) {
  return (
    Array.isArray(todos) &&
    todos.length <= MAX_TODOS &&
    todos.every(
      (t) =>
        t &&
        typeof t.text === 'string' &&
        t.text.length > 0 &&
        t.text.length <= MAX_TODO_LENGTH &&
        typeof t.done === 'boolean'
    )
  );
}

async function handleApi(req, res, pathname) {
  if (pathname === '/api/signup' && req.method === 'POST') {
    const { username, password } = await readJson(req);
    if (typeof username !== 'string' || !USERNAME_RE.test(username)) {
      return send(res, 400, { error: '아이디는 영문, 숫자, _ . - 로 3~32자여야 합니다.' });
    }
    if (typeof password !== 'string' || password.length < MIN_PASSWORD_LENGTH) {
      return send(res, 400, { error: `비밀번호는 ${MIN_PASSWORD_LENGTH}자 이상이어야 합니다.` });
    }
    if (password.length > 256) return send(res, 400, { error: '비밀번호가 너무 깁니다.' });
    if (findUser(username)) return send(res, 409, { error: '이미 사용 중인 아이디입니다.' });
    const salt = crypto.randomBytes(16);
    users.push({
      username,
      salt: salt.toString('hex'),
      hash: hashPassword(password, salt).toString('hex'),
      todos: [],
    });
    persist();
    return send(res, 201, { username }, { 'Set-Cookie': startSession(res, username) });
  }

  if (pathname === '/api/login' && req.method === 'POST') {
    const { username, password } = await readJson(req);
    const user = typeof username === 'string' ? findUser(username) : null;
    const salt = user ? Buffer.from(user.salt, 'hex') : crypto.randomBytes(16);
    const given = hashPassword(typeof password === 'string' ? password.slice(0, 256) : '', salt);
    const ok = user && crypto.timingSafeEqual(given, Buffer.from(user.hash, 'hex'));
    if (!ok) return send(res, 401, { error: '아이디 또는 비밀번호가 올바르지 않습니다.' });
    return send(res, 200, { username }, { 'Set-Cookie': startSession(res, username) });
  }

  if (pathname === '/api/logout' && req.method === 'POST') {
    sessions.delete(getSessionToken(req));
    return send(res, 204, '', { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
  }

  const user = getSessionUser(req);
  if (!user) return send(res, 401, { error: '로그인이 필요합니다.' });

  if (pathname === '/api/me' && req.method === 'GET') {
    return send(res, 200, { username: user.username });
  }

  if (pathname === '/api/todos' && req.method === 'GET') {
    return send(res, 200, user.todos);
  }

  if (pathname === '/api/todos' && req.method === 'PUT') {
    const todos = await readJson(req);
    if (!validTodos(todos)) return send(res, 400, { error: '할 일 형식이 올바르지 않습니다.' });
    user.todos = todos.map((t) => ({ text: t.text, done: t.done }));
    persist();
    return send(res, 200, user.todos);
  }

  return send(res, 404, { error: '찾을 수 없습니다.' });
}

const server = http.createServer(async (req, res) => {
  try {
    const { pathname } = new URL(req.url, 'http://localhost');
    if (pathname.startsWith('/api/')) return await handleApi(req, res, pathname);

    const entry = req.method === 'GET' && Object.hasOwn(STATIC_FILES, pathname) && STATIC_FILES[pathname];
    if (!entry) return send(res, 404, { error: '찾을 수 없습니다.' });
    const [file, type] = entry;
    send(res, 200, fs.readFileSync(path.join(__dirname, file)), { 'Content-Type': type });
  } catch (err) {
    if (err.status) return send(res, err.status, { error: err.message });
    console.error(err);
    send(res, 500, { error: '서버 오류가 발생했습니다.' });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`http://localhost:${PORT}`);
});
