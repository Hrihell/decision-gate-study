'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14;
const COOKIE = 'sid';

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'ledger.db'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    salt TEXT NOT NULL,
    hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('income','expense')),
    amount INTEGER NOT NULL CHECK (amount > 0),
    category TEXT NOT NULL,
    memo TEXT NOT NULL DEFAULT '',
    date TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
`);

const q = {
  userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
  insertUser: db.prepare('INSERT INTO users (username, salt, hash) VALUES (?, ?, ?)'),
  insertSession: db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)'),
  sessionUser: db.prepare(
    `SELECT u.id, u.username FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ?`
  ),
  deleteSession: db.prepare('DELETE FROM sessions WHERE token_hash = ?'),
  purgeSessions: db.prepare('DELETE FROM sessions WHERE expires_at <= ?'),
  listTx: db.prepare(
    `SELECT id, type, amount, category, memo, date FROM transactions
     WHERE user_id = ? AND date >= ? AND date < ? ORDER BY date DESC, id DESC`
  ),
  insertTx: db.prepare(
    'INSERT INTO transactions (user_id, type, amount, category, memo, date) VALUES (?, ?, ?, ?, ?, ?)'
  ),
  updateTx: db.prepare(
    'UPDATE transactions SET type = ?, amount = ?, category = ?, memo = ?, date = ? WHERE id = ? AND user_id = ?'
  ),
  deleteTx: db.prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?'),
};

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const hashPassword = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');

function verifyPassword(pw, salt, expectedHex) {
  const a = Buffer.from(hashPassword(pw, salt), 'hex');
  const b = Buffer.from(expectedHex, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// Dummy record so unknown usernames cost the same as wrong passwords.
const DUMMY_SALT = crypto.randomBytes(16).toString('hex');
const DUMMY_HASH = hashPassword('dummy', DUMMY_SALT);

const attempts = new Map();
function tooManyAttempts(key) {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || rec.reset < now) return false;
  return rec.count >= 10;
}
function noteFailure(key) {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || rec.reset < now) attempts.set(key, { count: 1, reset: now + 15 * 60 * 1000 });
  else rec.count++;
}

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function createSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  q.insertSession.run(sha256(token), userId, Date.now() + SESSION_TTL_MS);
  res.setHeader(
    'Set-Cookie',
    `${COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_TTL_MS / 1000}`
  );
}

function currentUser(req) {
  const token = parseCookies(req)[COOKIE];
  if (!token) return null;
  return q.sessionUser.get(sha256(token), Date.now()) || null;
}

function send(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(data);
}

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    if (!(req.headers['content-type'] || '').startsWith('application/json')) {
      return reject(new HttpError(415, 'JSON 요청만 허용됩니다.'));
    }
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 16 * 1024) {
        reject(new HttpError(413, '요청이 너무 큽니다.'));
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(new HttpError(400, '잘못된 JSON입니다.'));
      }
    });
    req.on('error', reject);
  });
}

function validDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

function parseTx(b) {
  if (b.type !== 'income' && b.type !== 'expense') throw new HttpError(400, '구분이 올바르지 않습니다.');
  const amount = Number(b.amount);
  if (!Number.isInteger(amount) || amount <= 0 || amount > 1e12) {
    throw new HttpError(400, '금액은 1 이상의 정수여야 합니다.');
  }
  const category = String(b.category || '').trim();
  if (!category || category.length > 30) throw new HttpError(400, '카테고리는 1~30자여야 합니다.');
  const memo = String(b.memo || '').trim();
  if (memo.length > 200) throw new HttpError(400, '메모는 200자 이하여야 합니다.');
  if (!validDate(b.date)) throw new HttpError(400, '날짜가 올바르지 않습니다.');
  return [b.type, amount, category, memo, b.date];
}

function monthRange(month) {
  if (!/^\d{4}-\d{2}$/.test(month || '')) throw new HttpError(400, 'month는 YYYY-MM 형식이어야 합니다.');
  const [y, m] = month.split('-').map(Number);
  if (m < 1 || m > 12) throw new HttpError(400, 'month가 올바르지 않습니다.');
  const next = m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
  return [`${month}-01`, `${next}-01`];
}

function validCredentials(b) {
  const username = String(b.username || '').trim();
  const password = String(b.password || '');
  if (!/^[A-Za-z0-9_.-]{3,20}$/.test(username)) {
    throw new HttpError(400, '아이디는 영문/숫자/_.- 3~20자여야 합니다.');
  }
  if (password.length < 8 || password.length > 100) {
    throw new HttpError(400, '비밀번호는 8~100자여야 합니다.');
  }
  return { username, password };
}

async function handleApi(req, res, url) {
  const route = `${req.method} ${url.pathname}`;

  if (route === 'POST /api/register') {
    const { username, password } = validCredentials(await readJson(req));
    if (q.userByName.get(username)) throw new HttpError(409, '이미 사용 중인 아이디입니다.');
    const salt = crypto.randomBytes(16).toString('hex');
    const { lastInsertRowid } = q.insertUser.run(username, salt, hashPassword(password, salt));
    createSession(res, Number(lastInsertRowid));
    return send(res, 201, { username });
  }

  if (route === 'POST /api/login') {
    const b = await readJson(req);
    const username = String(b.username || '').trim();
    const password = String(b.password || '');
    const key = `${req.socket.remoteAddress}|${username.toLowerCase()}`;
    if (tooManyAttempts(key)) throw new HttpError(429, '로그인 시도가 너무 많습니다. 잠시 후 다시 시도하세요.');
    const user = q.userByName.get(username);
    const ok = user
      ? verifyPassword(password, user.salt, user.hash)
      : (verifyPassword(password, DUMMY_SALT, DUMMY_HASH), false);
    if (!ok) {
      noteFailure(key);
      throw new HttpError(401, '아이디 또는 비밀번호가 올바르지 않습니다.');
    }
    attempts.delete(key);
    createSession(res, user.id);
    return send(res, 200, { username: user.username });
  }

  if (route === 'POST /api/logout') {
    const token = parseCookies(req)[COOKIE];
    if (token) q.deleteSession.run(sha256(token));
    res.setHeader('Set-Cookie', `${COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`);
    return send(res, 200, { ok: true });
  }

  const user = currentUser(req);
  if (!user) throw new HttpError(401, '로그인이 필요합니다.');

  if (route === 'GET /api/me') return send(res, 200, { username: user.username });

  if (route === 'GET /api/transactions') {
    const [from, to] = monthRange(url.searchParams.get('month'));
    return send(res, 200, q.listTx.all(user.id, from, to));
  }

  if (route === 'POST /api/transactions') {
    const vals = parseTx(await readJson(req));
    const { lastInsertRowid } = q.insertTx.run(user.id, ...vals);
    return send(res, 201, { id: Number(lastInsertRowid) });
  }

  const m = url.pathname.match(/^\/api\/transactions\/(\d+)$/);
  if (m && req.method === 'PUT') {
    const vals = parseTx(await readJson(req));
    const r = q.updateTx.run(...vals, Number(m[1]), user.id);
    if (!r.changes) throw new HttpError(404, '내역을 찾을 수 없습니다.');
    return send(res, 200, { ok: true });
  }
  if (m && req.method === 'DELETE') {
    const r = q.deleteTx.run(Number(m[1]), user.id);
    if (!r.changes) throw new HttpError(404, '내역을 찾을 수 없습니다.');
    return send(res, 200, { ok: true });
  }

  throw new HttpError(404, 'Not found');
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
};

function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405);
    return res.end();
  }
  const rel = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname).replace(/^\/+/, '');
  const file = path.resolve(PUBLIC_DIR, rel);
  if (!file.startsWith(PUBLIC_DIR + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Not found');
  }
  res.writeHead(200, {
    'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
    'Content-Security-Policy': "default-src 'self'",
    'X-Content-Type-Options': 'nosniff',
  });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message });
    console.error(e);
    send(res, 500, { error: '서버 오류가 발생했습니다.' });
  }
});

setInterval(() => q.purgeSessions.run(Date.now()), 60 * 60 * 1000).unref();

server.listen(PORT, '127.0.0.1', () => {
  console.log(`가계부 서버 실행 중: http://localhost:${PORT}`);
});
