'use strict';
const $ = (id) => document.getElementById(id);
const won = (n) => n.toLocaleString('ko-KR') + '원';
const pad = (n) => String(n).padStart(2, '0');
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

let month = today().slice(0, 7);
let registering = false;
let editingId = null;
let txs = [];

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || '요청에 실패했습니다.');
    err.status = res.status;
    throw err;
  }
  return data;
}

function showAuth() {
  $('app').classList.add('hidden');
  $('auth').classList.remove('hidden');
}

async function showApp(username) {
  $('auth').classList.add('hidden');
  $('app').classList.remove('hidden');
  $('whoami').textContent = username + ' 님';
  resetForm();
  await load();
}

function setAuthMode(reg) {
  registering = reg;
  $('auth-submit').textContent = reg ? '회원가입' : '로그인';
  $('auth-toggle').textContent = reg ? '이미 계정이 있나요? 로그인' : '계정이 없나요? 회원가입';
  $('auth-error').textContent = '';
  document.querySelector('#auth-form [name=password]').autocomplete = reg ? 'new-password' : 'current-password';
}

$('auth-toggle').onclick = () => setAuthMode(!registering);

$('auth-form').onsubmit = async (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  try {
    const r = await api('POST', registering ? '/api/register' : '/api/login', {
      username: f.get('username'),
      password: f.get('password'),
    });
    e.target.reset();
    await showApp(r.username);
  } catch (err) {
    $('auth-error').textContent = err.message;
  }
};

$('logout').onclick = async () => {
  await api('POST', '/api/logout').catch(() => {});
  setAuthMode(false);
  showAuth();
};

function shiftMonth(delta) {
  const [y, m] = month.split('-').map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  month = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
  load();
}
$('prev').onclick = () => shiftMonth(-1);
$('next').onclick = () => shiftMonth(1);

async function load() {
  $('month-label').textContent = `${month.slice(0, 4)}년 ${Number(month.slice(5))}월`;
  try {
    txs = await api('GET', `/api/transactions?month=${month}`);
  } catch (err) {
    if (err.status === 401) return showAuth();
    alert(err.message);
    return;
  }
  render();
}

function render() {
  let income = 0;
  let expense = 0;
  const byCat = new Map();
  for (const t of txs) {
    if (t.type === 'income') income += t.amount;
    else {
      expense += t.amount;
      byCat.set(t.category, (byCat.get(t.category) || 0) + t.amount);
    }
  }
  $('sum-income').textContent = won(income);
  $('sum-expense').textContent = won(expense);
  const bal = income - expense;
  $('sum-balance').textContent = (bal < 0 ? '-' : '') + won(Math.abs(bal));

  const bd = $('breakdown');
  bd.replaceChildren();
  const sorted = [...byCat].sort((a, b) => b[1] - a[1]);
  if (!sorted.length) {
    const li = document.createElement('li');
    li.className = 'muted';
    li.textContent = '지출 내역이 없습니다.';
    bd.append(li);
  }
  for (const [cat, amt] of sorted) {
    const li = document.createElement('li');
    const line = document.createElement('div');
    line.className = 'line';
    const name = document.createElement('span');
    name.textContent = cat;
    const val = document.createElement('span');
    val.textContent = `${won(amt)} (${Math.round((amt / expense) * 100)}%)`;
    line.append(name, val);
    const bar = document.createElement('div');
    bar.className = 'bar';
    const fill = document.createElement('i');
    fill.style.width = `${(amt / expense) * 100}%`;
    bar.append(fill);
    li.append(line, bar);
    bd.append(li);
  }

  const dl = $('categories');
  dl.replaceChildren();
  for (const c of new Set(txs.map((t) => t.category))) {
    const o = document.createElement('option');
    o.value = c;
    dl.append(o);
  }

  const list = $('list');
  list.replaceChildren();
  $('empty').classList.toggle('hidden', txs.length > 0);
  for (const t of txs) {
    const li = document.createElement('li');
    const left = document.createElement('div');
    const title = document.createElement('div');
    title.textContent = t.category + (t.memo ? ` · ${t.memo}` : '');
    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = t.date;
    left.append(title, meta);

    const right = document.createElement('div');
    right.className = 'actions';
    const amt = document.createElement('span');
    amt.className = `amount ${t.type}`;
    amt.textContent = (t.type === 'income' ? '+' : '-') + won(t.amount);
    const edit = document.createElement('button');
    edit.className = 'secondary';
    edit.textContent = '수정';
    edit.onclick = () => startEdit(t);
    const del = document.createElement('button');
    del.className = 'secondary';
    del.textContent = '삭제';
    del.onclick = () => remove(t);
    right.append(amt, edit, del);

    li.append(left, right);
    list.append(li);
  }
}

function resetForm() {
  editingId = null;
  const f = $('tx-form');
  f.reset();
  f.date.value = month === today().slice(0, 7) ? today() : `${month}-01`;
  $('form-title').textContent = '내역 추가';
  $('tx-submit').textContent = '추가';
  $('tx-cancel').classList.add('hidden');
  $('tx-error').textContent = '';
}

function startEdit(t) {
  editingId = t.id;
  const f = $('tx-form');
  f.type.value = t.type;
  f.date.value = t.date;
  f.category.value = t.category;
  f.amount.value = t.amount;
  f.memo.value = t.memo;
  $('form-title').textContent = '내역 수정';
  $('tx-submit').textContent = '저장';
  $('tx-cancel').classList.remove('hidden');
  f.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

$('tx-cancel').onclick = resetForm;

$('tx-form').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.target;
  const body = {
    type: f.type.value,
    date: f.date.value,
    category: f.category.value,
    amount: Number(f.amount.value),
    memo: f.memo.value,
  };
  try {
    if (editingId) await api('PUT', `/api/transactions/${editingId}`, body);
    else await api('POST', '/api/transactions', body);
    month = body.date.slice(0, 7);
    resetForm();
    await load();
  } catch (err) {
    if (err.status === 401) return showAuth();
    $('tx-error').textContent = err.message;
  }
};

async function remove(t) {
  if (!confirm(`${t.category} ${won(t.amount)} 내역을 삭제할까요?`)) return;
  try {
    await api('DELETE', `/api/transactions/${t.id}`);
    if (editingId === t.id) resetForm();
    await load();
  } catch (err) {
    if (err.status === 401) return showAuth();
    alert(err.message);
  }
}

(async () => {
  try {
    const me = await api('GET', '/api/me');
    await showApp(me.username);
  } catch {
    showAuth();
  }
})();
