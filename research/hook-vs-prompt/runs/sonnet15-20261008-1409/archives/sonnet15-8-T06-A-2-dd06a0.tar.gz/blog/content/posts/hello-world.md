---
title: 첫 번째 글
date: 2026-10-08
summary: Next.js로 만든 블로그의 첫 글입니다.
---

안녕하세요! 이 블로그는 **Next.js**와 마크다운으로 만들어졌습니다.

## 글 추가하는 법

`content/posts/` 폴더에 `.md` 파일을 추가하면 됩니다.

```md
---
title: 제목
date: 2026-10-09
summary: 한 줄 요약
---

본문
```
