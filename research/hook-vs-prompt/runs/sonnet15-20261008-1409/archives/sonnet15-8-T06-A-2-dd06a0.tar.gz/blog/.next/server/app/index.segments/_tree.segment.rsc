:HL["/_next/static/chunks/1luecg63dz8fo.css","style"]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"as42e8ZtnIGA3GStc8KPP","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
