1:"$Sreact.fragment"
2:"/_next/static/chunks/27gjg8e11zukd.js"
3:I[22016,["$2"],""]
4:I[39756,["$2"],"default"]
5:I[37457,["$2"],"default"]
9:I[97367,["$2"],"OutletBoundary"]
a:"$Sreact.suspense"
d:"ViewportBoundary"
e:I[97367,["$2"],"$d"]
f:"MetadataBoundary"
10:I[97367,["$2"],"$f"]
:HL["/_next/static/chunks/1luecg63dz8fo.css","style"]
7:X
8:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","ul",null,{"className":"post-list","children":[["$","li","hello-world",{"children":[["$","$L3",null,{"href":"/posts/hello-world","children":["$","h2",null,{"children":"첫 번째 글"}]}],["$","time",null,{"children":"Thu Oct 08 2026 09:00:00 GMT+0900 (Korean Standard Time)"}],["$","p",null,{"children":"Next.js로 만든 블로그의 첫 글입니다."}]]}],["$","li","second-post",{"children":[["$","$L3",null,{"href":"/posts/second-post","children":["$","h2",null,{"children":"두 번째 글"}]}],["$","time",null,{"children":"Fri Oct 09 2026 09:00:00 GMT+0900 (Korean Standard Time)"}],["$","p",null,{"children":"글 목록이 날짜 역순으로 정렬되는지 확인하기 위한 글입니다."}]]}]]}],null,["$","$L9",null,{"children":["$","$a",null,{"name":"Next.MetadataOutlet","children":"$@b"}]}]]}],"p":"$@c","v":null,"s":"$7"}}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1luecg63dz8fo.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/27gjg8e11zukd.js","async":true}]],["$","html",null,{"lang":"ko","children":["$","body",null,{"children":[["$","header",null,{"className":"site-header","children":["$","$L3",null,{"href":"/","children":"My Blog"}]}],["$","main",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}],["$","footer",null,{"className":"site-footer","children":["© ",2026," My Blog"]}]]}]}]]}],"p":"$@6","v":null,"s":"$7"},"c":"$Q8"},"h":{"r":["$","$1","h",{"children":[null,["$","$Le",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L10",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$a",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"My Blog"}],["$","meta","1",{"name":"description","content":"Next.js로 만든 블로그"}]]}]}],null]}],null]}],"p":"$@11","v":null,"s":"$7"}},"a":"$@12","u":"$@13","b":"as42e8ZtnIGA3GStc8KPP"}
b:null
7:300
13:true
7:C
12:0
6:"$undefined"
11:"$undefined"
c:"$undefined"
