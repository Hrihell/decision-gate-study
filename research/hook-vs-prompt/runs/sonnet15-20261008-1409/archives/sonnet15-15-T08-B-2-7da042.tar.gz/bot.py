import os

import aiohttp
import discord
from discord import app_commands
from dotenv import load_dotenv

load_dotenv()

SEOUL_LAT, SEOUL_LON = 37.5665, 126.9780
API_URL = (
    "https://api.open-meteo.com/v1/forecast"
    f"?latitude={SEOUL_LAT}&longitude={SEOUL_LON}"
    "&current=temperature_2m,apparent_temperature,relative_humidity_2m,"
    "weather_code,wind_speed_10m"
    "&timezone=Asia%2FSeoul"
)

WEATHER_CODES = {
    0: "맑음",
    1: "대체로 맑음",
    2: "구름 조금",
    3: "흐림",
    45: "안개",
    48: "서리 안개",
    51: "약한 이슬비",
    53: "이슬비",
    55: "강한 이슬비",
    61: "약한 비",
    63: "비",
    65: "강한 비",
    71: "약한 눈",
    73: "눈",
    75: "강한 눈",
    80: "약한 소나기",
    81: "소나기",
    82: "강한 소나기",
    95: "뇌우",
    96: "우박을 동반한 뇌우",
    99: "강한 우박을 동반한 뇌우",
}


class WeatherBot(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.default())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        await self.tree.sync()


bot = WeatherBot()


@bot.tree.command(name="서울날씨", description="서울의 현재 날씨를 알려줍니다")
async def seoul_weather(interaction: discord.Interaction):
    await interaction.response.defer()
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(API_URL, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                resp.raise_for_status()
                current = (await resp.json())["current"]
    except Exception:
        await interaction.followup.send("날씨 정보를 가져오지 못했어요. 잠시 후 다시 시도해 주세요.")
        return

    embed = discord.Embed(
        title="서울 현재 날씨",
        description=WEATHER_CODES.get(current["weather_code"], "알 수 없음"),
        color=0x4A90D9,
    )
    embed.add_field(name="기온", value=f"{current['temperature_2m']}°C")
    embed.add_field(name="체감", value=f"{current['apparent_temperature']}°C")
    embed.add_field(name="습도", value=f"{current['relative_humidity_2m']}%")
    embed.add_field(name="풍속", value=f"{current['wind_speed_10m']} km/h")
    embed.set_footer(text=f"기준 시각 {current['time'].replace('T', ' ')} (KST) · Open-Meteo")
    await interaction.followup.send(embed=embed)


@bot.event
async def on_ready():
    print(f"로그인됨: {bot.user}")


if __name__ == "__main__":
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise SystemExit("DISCORD_TOKEN이 설정되지 않았습니다. .env 파일에 토큰을 넣어 주세요.")
    bot.run(token)
