globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/GLNpdKrYvapazQ5WpfddQ/_buildManifest.js",
    "static/GLNpdKrYvapazQ5WpfddQ/_ssgManifest.js",
    "static/GLNpdKrYvapazQ5WpfddQ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/2fzxukf5i8xn4.js",
    "static/chunks/1lha-inyemip4.js",
    "static/chunks/0rm4bmi_uaeqm.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2fzxukf5i8xn4.js",
        "static/chunks/1lha-inyemip4.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2fzxukf5i8xn4.js",
        "static/chunks/1lha-inyemip4.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2fzxukf5i8xn4.js",
        "static/chunks/1lha-inyemip4.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/posts/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/2fzxukf5i8xn4.js",
        "static/chunks/1lha-inyemip4.js",
        "static/chunks/0rm4bmi_uaeqm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
