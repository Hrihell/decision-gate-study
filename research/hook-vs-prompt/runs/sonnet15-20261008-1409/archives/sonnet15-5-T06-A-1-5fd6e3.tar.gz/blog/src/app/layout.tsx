import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "My Blog",
  description: "Next.js로 만든 블로그",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body>
        <header className="site-header">
          <Link href="/">My Blog</Link>
        </header>
        <main>{children}</main>
        <footer className="site-footer">© {new Date().getFullYear()} My Blog</footer>
      </body>
    </html>
  );
}
