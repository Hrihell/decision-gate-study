import Link from "next/link";
import { getAllPosts } from "@/lib/posts";

export default function Home() {
  const posts = getAllPosts();
  return (
    <ul className="post-list">
      {posts.map((p) => (
        <li key={p.slug}>
          <Link href={`/posts/${p.slug}`}>
            <h2>{p.title}</h2>
          </Link>
          <time>{p.date}</time>
          <p>{p.summary}</p>
        </li>
      ))}
    </ul>
  );
}
