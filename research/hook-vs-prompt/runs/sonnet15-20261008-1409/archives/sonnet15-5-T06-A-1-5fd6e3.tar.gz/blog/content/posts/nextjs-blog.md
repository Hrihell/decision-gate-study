---
title: "Next.js로 블로그 만들기"
date: "2026-10-09"
summary: "App Router와 마크다운으로 만든 정적 블로그 구조."
---

이 블로그는 **App Router**와 마크다운 파일만으로 동작합니다.

- 글 목록: `src/app/page.tsx`
- 글 상세: `src/app/posts/[slug]/page.tsx`
- 마크다운 로더: `src/lib/posts.ts`

빌드 시 모든 글이 정적 페이지로 생성됩니다.
