const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { addTodo, getTodos, deleteTodo, updateTodo } = require('./db');

let mainWindow;

app.on('ready', () => {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      enableRemoteModule: false,
      sandbox: true,
    },
  });

  mainWindow.loadFile('src/index.html');
  mainWindow.webContents.openDevTools();
});

ipcMain.handle('add-todo', (event, title) => {
  return addTodo(title);
});

ipcMain.handle('get-todos', (event) => {
  return getTodos();
});

ipcMain.handle('delete-todo', (event, id) => {
  return deleteTodo(id);
});

ipcMain.handle('update-todo', (event, id, title, completed) => {
  return updateTodo(id, title, completed);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    app.emit('ready');
  }
});
