const todoInput = document.getElementById('todoInput');
const todosList = document.getElementById('todosList');

async function loadTodos() {
  const todos = await window.api.getTodos();
  renderTodos(todos);
}

function renderTodos(todos) {
  todosList.innerHTML = '';

  if (todos.length === 0) {
    todosList.innerHTML = '<div class="empty-message">할 일이 없습니다. 새로운 할 일을 추가하세요!</div>';
    return;
  }

  todos.forEach(todo => {
    const li = document.createElement('li');
    li.className = `todo-item ${todo.completed ? 'completed' : ''}`;

    li.innerHTML = `
      <input type="checkbox" ${todo.completed ? 'checked' : ''}
             onchange="toggleTodo(${todo.id}, this.checked)">
      <span class="todo-text">${escapeHtml(todo.title)}</span>
      <button class="delete-btn" onclick="deleteTodo(${todo.id})">삭제</button>
    `;

    todosList.appendChild(li);
  });
}

async function addTodo() {
  const title = todoInput.value.trim();

  if (!title) {
    alert('할 일을 입력하세요.');
    return;
  }

  await window.api.addTodo(title);
  todoInput.value = '';
  loadTodos();
}

async function deleteTodo(id) {
  await window.api.deleteTodo(id);
  loadTodos();
}

async function toggleTodo(id, completed) {
  const todos = await window.api.getTodos();
  const todo = todos.find(t => t.id === id);

  if (todo) {
    await window.api.updateTodo(id, todo.title, completed);
    loadTodos();
  }
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

todoInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addTodo();
  }
});

loadTodos();
