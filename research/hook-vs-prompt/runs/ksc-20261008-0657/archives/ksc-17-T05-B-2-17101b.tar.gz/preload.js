const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  addTodo: (title) => ipcRenderer.invoke('add-todo', title),
  getTodos: () => ipcRenderer.invoke('get-todos'),
  deleteTodo: (id) => ipcRenderer.invoke('delete-todo', id),
  updateTodo: (id, title, completed) => ipcRenderer.invoke('update-todo', id, title, completed),
});
