# 할 일 목록 데스크탑 앱

Electron + React + SQLite로 만든 간단한 할 일 목록 앱입니다.

## 기능

- ✓ 할 일 추가
- ✓ 할 일 삭제
- ✓ 할 일 완료 표시
- ✓ 로컬 SQLite 데이터베이스에 저장

## 설치 및 실행

```bash
# 의존성 설치 (이미 완료됨)
npm install

# 앱 실행
npm start
```

## 프로젝트 구조

- `main.js` - Electron 메인 프로세스
- `preload.js` - IPC 통신 설정
- `db.js` - SQLite 데이터베이스 작업
- `src/index.html` - UI 레이아웃
- `src/app.js` - 프론트엔드 로직

## 사용법

1. "새로운 할 일을 입력하세요..." 입력창에 할 일을 입력
2. "추가" 버튼을 클릭하거나 Enter 키 누르기
3. 체크박스로 완료 표시
4. "삭제" 버튼으로 할 일 제거

데이터는 자동으로 홈디렉토리의 `.todo-app/todos.db` 파일에 저장됩니다.
