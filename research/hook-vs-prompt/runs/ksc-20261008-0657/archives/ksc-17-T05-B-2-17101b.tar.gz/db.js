const Database = require('better-sqlite3');
const path = require('path');
const os = require('os');

const dbPath = path.join(os.homedir(), '.todo-app', 'todos.db');
const db = new Database(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS todos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    completed INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

const addTodo = (title) => {
  const stmt = db.prepare('INSERT INTO todos (title) VALUES (?)');
  const result = stmt.run(title);
  return result.lastInsertRowid;
};

const getTodos = () => {
  const stmt = db.prepare('SELECT * FROM todos ORDER BY created_at DESC');
  return stmt.all();
};

const deleteTodo = (id) => {
  const stmt = db.prepare('DELETE FROM todos WHERE id = ?');
  stmt.run(id);
};

const updateTodo = (id, title, completed) => {
  const stmt = db.prepare('UPDATE todos SET title = ?, completed = ? WHERE id = ?');
  stmt.run(title, completed ? 1 : 0, id);
};

module.exports = { addTodo, getTodos, deleteTodo, updateTodo };
