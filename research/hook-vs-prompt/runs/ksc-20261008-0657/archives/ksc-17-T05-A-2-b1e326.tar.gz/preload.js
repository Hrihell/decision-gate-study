// Preload script - can be empty for this simple app
