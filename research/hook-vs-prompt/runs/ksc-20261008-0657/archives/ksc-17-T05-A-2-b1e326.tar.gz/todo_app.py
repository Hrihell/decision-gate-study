#!/usr/bin/env python3
import tkinter as tk
from tkinter import font
import json
import os
from datetime import datetime

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("할 일 목록")
        self.root.geometry("500x600")
        self.root.configure(bg="#f5f5f5")

        self.storage_file = os.path.expanduser("~/.todo_app.json")
        self.todos = self.load_todos()

        self.setup_ui()
        self.refresh_list()

    def setup_ui(self):
        # Header
        header = tk.Frame(self.root, bg="white", relief=tk.FLAT, height=80)
        header.pack(fill=tk.X, padx=0, pady=0)

        title = tk.Label(
            header,
            text="할 일 목록",
            font=("Arial", 24, "bold"),
            bg="white",
            fg="#333"
        )
        title.pack(pady=15)

        # Input section
        input_frame = tk.Frame(self.root, bg="white", relief=tk.FLAT)
        input_frame.pack(fill=tk.X, padx=15, pady=15)

        self.input_field = tk.Entry(
            input_frame,
            font=("Arial", 14),
            relief=tk.FLAT,
            bg="#f9f9f9",
            fg="#333",
            insertbackground="#667eea"
        )
        self.input_field.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        self.input_field.bind('<Return>', lambda e: self.add_todo())

        add_btn = tk.Button(
            input_frame,
            text="추가",
            font=("Arial", 12, "bold"),
            bg="#667eea",
            fg="white",
            relief=tk.FLAT,
            padx=20,
            command=self.add_todo,
            cursor="hand2"
        )
        add_btn.pack(side=tk.LEFT)

        # Stats
        stats_frame = tk.Frame(self.root, bg="white", relief=tk.FLAT)
        stats_frame.pack(fill=tk.X, padx=15, pady=10)

        self.total_label = tk.Label(
            stats_frame,
            text="전체: 0",
            font=("Arial", 11),
            bg="white",
            fg="#666"
        )
        self.total_label.pack(side=tk.LEFT, padx=10)

        self.completed_label = tk.Label(
            stats_frame,
            text="완료: 0",
            font=("Arial", 11),
            bg="white",
            fg="#666"
        )
        self.completed_label.pack(side=tk.LEFT, padx=10)

        # List frame with scrollbar
        list_frame = tk.Frame(self.root, bg="#f5f5f5")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=0, pady_bottom=15)

        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.listbox = tk.Listbox(
            list_frame,
            yscrollcommand=scrollbar.set,
            font=("Arial", 12),
            bg="white",
            fg="#333",
            relief=tk.FLAT,
            highlightthickness=0,
            selectmode=tk.NONE,
            height=15
        )
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.listbox.yview)

        self.root.pack_propagate(True)

    def add_todo(self):
        text = self.input_field.get().strip()
        if not text:
            return

        todo = {
            "id": datetime.now().timestamp(),
            "text": text,
            "completed": False,
            "created_at": datetime.now().isoformat()
        }

        self.todos.insert(0, todo)
        self.save_todos()
        self.input_field.delete(0, tk.END)
        self.input_field.focus()
        self.refresh_list()

    def toggle_todo(self, todo_id):
        for todo in self.todos:
            if todo["id"] == todo_id:
                todo["completed"] = not todo["completed"]
                break
        self.save_todos()
        self.refresh_list()

    def delete_todo(self, todo_id):
        self.todos = [t for t in self.todos if t["id"] != todo_id]
        self.save_todos()
        self.refresh_list()

    def refresh_list(self):
        self.listbox.delete(0, tk.END)

        if not self.todos:
            self.listbox.insert(tk.END, "할 일이 없습니다.")
            self.total_label.config(text="전체: 0")
            self.completed_label.config(text="완료: 0")
            return

        completed_count = sum(1 for t in self.todos if t["completed"])
        self.total_label.config(text=f"전체: {len(self.todos)}")
        self.completed_label.config(text=f"완료: {completed_count}")

        for idx, todo in enumerate(self.todos):
            text = todo["text"]
            status = "✓" if todo["completed"] else "○"
            display_text = f"  {status}  {text}"

            self.listbox.insert(tk.END, display_text)

            if todo["completed"]:
                self.listbox.itemconfig(idx, fg="#999")
            else:
                self.listbox.itemconfig(idx, fg="#333")

            self.listbox.see(idx)

        # Bind click events
        self.listbox.bind('<Button-1>', self.on_list_click)
        self.listbox.bind('<Button-3>', self.on_right_click)

    def on_list_click(self, event):
        index = self.listbox.nearest(event.y)
        if index < 0 or index >= len(self.todos):
            return

        x = event.x
        if x < 30:
            self.toggle_todo(self.todos[index]["id"])

    def on_right_click(self, event):
        index = self.listbox.nearest(event.y)
        if index < 0 or index >= len(self.todos):
            return

        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(
            label="삭제",
            command=lambda: self.delete_todo(self.todos[index]["id"])
        )
        menu.post(event.x_root, event.y_root)

    def save_todos(self):
        with open(self.storage_file, 'w', encoding='utf-8') as f:
            json.dump(self.todos, f, ensure_ascii=False, indent=2)

    def load_todos(self):
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
