const todoInput = document.getElementById('todoInput');
const addBtn = document.getElementById('addBtn');
const todoList = document.getElementById('todoList');
const totalCount = document.getElementById('totalCount');
const completeCount = document.getElementById('completeCount');

const STORAGE_KEY = 'todos';

class TodoApp {
  constructor() {
    this.todos = this.loadFromStorage();
    this.render();
    this.attachEventListeners();
  }

  loadFromStorage() {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  saveToStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.todos));
  }

  addTodo(text) {
    if (!text.trim()) return;

    const todo = {
      id: Date.now(),
      text: text.trim(),
      completed: false,
      createdAt: new Date().toISOString(),
    };

    this.todos.unshift(todo);
    this.saveToStorage();
    this.render();
    todoInput.value = '';
    todoInput.focus();
  }

  deleteTodo(id) {
    this.todos = this.todos.filter(todo => todo.id !== id);
    this.saveToStorage();
    this.render();
  }

  toggleTodo(id) {
    const todo = this.todos.find(t => t.id === id);
    if (todo) {
      todo.completed = !todo.completed;
      this.saveToStorage();
      this.render();
    }
  }

  render() {
    todoList.innerHTML = '';

    if (this.todos.length === 0) {
      todoList.innerHTML = '<div class="empty-state">할 일이 없습니다. 새로운 할 일을 추가하세요!</div>';
      totalCount.textContent = '0';
      completeCount.textContent = '0';
      return;
    }

    const completed = this.todos.filter(t => t.completed).length;
    totalCount.textContent = this.todos.length;
    completeCount.textContent = completed;

    this.todos.forEach(todo => {
      const li = document.createElement('li');
      li.className = `todo-item ${todo.completed ? 'completed' : ''}`;

      li.innerHTML = `
        <input
          type="checkbox"
          class="checkbox"
          ${todo.completed ? 'checked' : ''}
          data-id="${todo.id}"
        >
        <span class="todo-text">${this.escapeHtml(todo.text)}</span>
        <button class="delete-btn" data-id="${todo.id}">삭제</button>
      `;

      todoList.appendChild(li);
    });
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  attachEventListeners() {
    addBtn.addEventListener('click', () => {
      this.addTodo(todoInput.value);
    });

    todoInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.addTodo(todoInput.value);
      }
    });

    todoList.addEventListener('change', (e) => {
      if (e.target.classList.contains('checkbox')) {
        this.toggleTodo(Number(e.target.dataset.id));
      }
    });

    todoList.addEventListener('click', (e) => {
      if (e.target.classList.contains('delete-btn')) {
        this.deleteTodo(Number(e.target.dataset.id));
      }
    });
  }
}

new TodoApp();
