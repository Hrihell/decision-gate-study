#!/bin/bash
python3 todo_app.py
