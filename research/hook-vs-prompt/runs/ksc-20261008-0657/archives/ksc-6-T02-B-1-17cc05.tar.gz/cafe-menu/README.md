# ☕ 아로마 카페 메뉴판

간단한 HTML + CSS + JavaScript로 만들어진 카페 메뉴판 웹사이트입니다.

## 기능

- ✅ 카테고리별 메뉴 필터링 (에스프레소, 우유 커피, 차, 콜드, 디저트)
- ✅ 반응형 디자인 (모바일/태블릿/데스크톱)
- ✅ 부드러운 애니메이션 및 호버 효과
- ✅ 메뉴 아이템별 태그 표시
- ✅ 명확한 가격 표시

## 파일 구조

```
cafe-menu/
├── index.html       # 메인 HTML 파일
├── css/
│   └── style.css    # 스타일 정의
├── js/
│   └── script.js    # 메뉴 데이터 및 기능
└── README.md        # 이 파일
```

## 사용 방법

1. `index.html` 파일을 웹 브라우저에서 열기
2. 상단 네비게이션 버튼으로 카테고리 필터링

## 커스터마이징

### 메뉴 항목 수정

`js/script.js` 파일의 `menuData` 객체를 수정하여 메뉴를 변경할 수 있습니다.

```javascript
const menuData = {
    espresso: {
        icon: '🫘',
        name: '에스프레소',
        items: [
            {
                name: '메뉴 이름',
                price: '가격',
                description: '설명',
                tags: ['태그1', '태그2']
            },
            // ... 더 많은 항목
        ]
    },
    // ... 다른 카테고리
};
```

### 색상 변경

`css/style.css` 파일의 CSS 변수를 수정하여 색상을 변경할 수 있습니다.

```css
:root {
    --primary-color: #6f4e37;      /* 주 색상 */
    --secondary-color: #a8815e;    /* 보조 색상 */
    --accent-color: #d4a574;       /* 강조 색상 */
    --bg-color: #f5f3ee;           /* 배경 색상 */
}
```

## 기술 스택

- HTML5
- CSS3 (Grid, Flexbox, CSS Variables)
- Vanilla JavaScript (ES6+)

## 라이선스

자유롭게 사용, 수정, 배포할 수 있습니다.
