const menuData = {
    espresso: {
        icon: '🫘',
        name: '에스프레소',
        items: [
            {
                name: '에스프레소',
                price: '3,500원',
                description: '진한 풍미의 클래식 에스프레소',
                tags: ['핫', '진한맛']
            },
            {
                name: '더블 에스프레소',
                price: '4,500원',
                description: '두 배로 진한 맛과 풍미',
                tags: ['핫', '진한맛', '인기']
            },
            {
                name: '롱 블랙',
                price: '4,000원',
                description: '에스프레소에 뜨거운 물을 더한 음료',
                tags: ['핫', '가벼움']
            },
            {
                name: '리스트레토',
                price: '3,500원',
                description: '더 강한 에스프레소',
                tags: ['핫', '진한맛']
            }
        ]
    },
    'milk-coffee': {
        icon: '🥛',
        name: '우유 커피',
        items: [
            {
                name: '카페 라떼',
                price: '5,000원',
                description: '부드러운 우유와 에스프레소의 조화',
                tags: ['핫', '부드러움', '인기']
            },
            {
                name: '카푸치노',
                price: '5,000원',
                description: '진한 크마와 우유 거품이 어우러진 음료',
                tags: ['핫', '거품']
            },
            {
                name: '플랫 화이트',
                price: '5,500원',
                description: '풍부한 크리마와 부드러운 우유',
                tags: ['핫', '부드러움', '호주식']
            },
            {
                name: '마키아또',
                price: '4,500원',
                description: '에스프레소에 우유 거품을 얹은 음료',
                tags: ['핫', '거품']
            }
        ]
    },
    tea: {
        icon: '🍃',
        name: '차',
        items: [
            {
                name: '그린티 라떼',
                price: '5,000원',
                description: '신선한 초록차와 우유의 조화',
                tags: ['핫', '건강']
            },
            {
                name: '캐모마일 티',
                price: '4,500원',
                description: '진정 효과가 있는 따뜻한 허브차',
                tags: ['핫', '허브']
            },
            {
                name: '얼그레이 티',
                price: '4,500원',
                description: '베르가못 향이 나는 우아한 홍차',
                tags: ['핫', '향신료']
            },
            {
                name: '아이스 그린티',
                price: '5,000원',
                description: '상큼한 아이스 초록차',
                tags: ['콜드', '건강']
            }
        ]
    },
    cold: {
        icon: '❄️',
        name: '콜드 음료',
        items: [
            {
                name: '아이스 아메리카노',
                price: '4,500원',
                description: '시원한 아메리카노',
                tags: ['콜드', '인기', '가벼움']
            },
            {
                name: '아이스 라떼',
                price: '5,500원',
                description: '차가운 우유와 에스프레소',
                tags: ['콜드', '부드러움']
            },
            {
                name: '프라페',
                price: '6,000원',
                description: '얼음과 크림이 들어간 시원한 음료',
                tags: ['콜드', '달콤함']
            },
            {
                name: '아이스 카푸치노',
                price: '5,500원',
                description: '시원한 카푸치노',
                tags: ['콜드', '거품']
            }
        ]
    },
    dessert: {
        icon: '🍰',
        name: '디저트',
        items: [
            {
                name: '초콜릿 케이크',
                price: '6,000원',
                description: '진하고 풍부한 초콜릿 맛',
                tags: ['달콤함', '초콜릿']
            },
            {
                name: '치즈케이크',
                price: '6,500원',
                description: '부드러운 치즈 크림',
                tags: ['달콤함', '크리미']
            },
            {
                name: '크로와상',
                price: '4,000원',
                description: '바삭한 프랑스 버터 페이스트리',
                tags: ['바삭함', '인기']
            },
            {
                name: '베이글',
                price: '3,500원',
                description: '쫄깃한 식감의 클래식 베이글',
                tags: ['담백함', '가벼움']
            },
            {
                name: '초콜릿 무스',
                price: '5,500원',
                description: '부드러운 초콜릿 무스',
                tags: ['달콤함', '초콜릿']
            },
            {
                name: '티라미수',
                price: '6,500원',
                description: '이탈리안 전통 디저트',
                tags: ['달콤함', '고급']
            }
        ]
    }
};

let currentFilter = 'all';

function createMenuHTML() {
    const menuGrid = document.getElementById('menuGrid');
    menuGrid.innerHTML = '';

    const categoriesToShow = currentFilter === 'all' ? Object.keys(menuData) : [currentFilter];

    categoriesToShow.forEach(category => {
        const data = menuData[category];

        const categoryCard = document.createElement('div');
        categoryCard.className = 'menu-card category-label show';
        categoryCard.innerHTML = `<h2>${data.icon} ${data.name}</h2>`;
        menuGrid.appendChild(categoryCard);

        data.items.forEach(item => {
            const card = document.createElement('div');
            card.className = 'menu-card show';
            card.innerHTML = `
                <div class="item-header">
                    <span class="item-name">${item.name}</span>
                    <span class="item-price">${item.price}</span>
                </div>
                <p class="item-description">${item.description}</p>
                <div class="item-tags">
                    ${item.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
            `;
            menuGrid.appendChild(card);
        });
    });
}

function setupNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');

    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            navButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            currentFilter = button.getAttribute('data-category');
            createMenuHTML();
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    createMenuHTML();
    setupNavigation();
});
