#!/usr/bin/env python3
"""
downloads 폴더의 파일을 확장자별로 정리하는 프로그램
"""

import os
import shutil
from pathlib import Path
from collections import defaultdict

def organize_downloads():
    downloads_dir = Path('downloads')
    
    if not downloads_dir.exists():
        print(f"❌ {downloads_dir} 폴더를 찾을 수 없습니다.")
        return
    
    # 파일 확장자별 분류
    file_groups = defaultdict(list)
    
    for file_path in downloads_dir.iterdir():
        if file_path.is_file():
            # 확장자 추출 (없으면 'etc')
            ext = file_path.suffix[1:].lower() if file_path.suffix else 'etc'
            file_groups[ext].append(file_path)
    
    # 확장자별 폴더 생성 및 파일 이동
    for ext, files in sorted(file_groups.items()):
        folder_name = downloads_dir / ext
        
        # 폴더 생성
        folder_name.mkdir(exist_ok=True)
        
        # 파일 이동
        for file_path in files:
            dest_path = folder_name / file_path.name
            shutil.move(str(file_path), str(dest_path))
            print(f"✓ {file_path.name:30} → {ext}/ 폴더로 이동")
    
    print(f"\n✅ 정리 완료! {len(file_groups)}개 폴더 생성됨")
    print("\n생성된 폴더:")
    for ext in sorted(file_groups.keys()):
        count = len(file_groups[ext])
        print(f"  📁 {ext:10} ({count}개 파일)")

if __name__ == '__main__':
    organize_downloads()
