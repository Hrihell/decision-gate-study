#!/usr/bin/env python3
import os
import shutil
from pathlib import Path
from collections import defaultdict

def organize_downloads():
    downloads_path = Path("downloads")
    
    if not downloads_path.exists():
        print("❌ downloads 폴더가 없습니다.")
        return
    
    files_by_ext = defaultdict(list)
    
    # 파일들을 확장자별로 분류
    for file_path in downloads_path.iterdir():
        if file_path.is_file():
            ext = file_path.suffix[1:] if file_path.suffix else "no_extension"
            files_by_ext[ext].append(file_path)
    
    if not files_by_ext:
        print("📁 downloads 폴더가 비어있습니다.")
        return
    
    # 확장자별로 폴더 생성 및 파일 이동
    for ext, files in sorted(files_by_ext.items()):
        folder_name = f"[{ext}]" if ext != "no_extension" else "[기타]"
        folder_path = downloads_path / folder_name
        
        # 폴더가 없으면 생성
        if not folder_path.exists():
            folder_path.mkdir(exist_ok=True)
            print(f"✅ 폴더 생성: {folder_name}")
        
        # 파일을 해당 폴더로 이동
        for file_path in files:
            destination = folder_path / file_path.name
            shutil.move(str(file_path), str(destination))
            print(f"   ➜ {file_path.name} 이동")

if __name__ == "__main__":
    organize_downloads()
    print("\n🎉 파일 정렬 완료!")
