import { useState, useEffect } from 'react';
import { transactionApi, statisticsApi } from '../api';

export default function Dashboard({ user, onLogout }) {
  const [transactions, setTransactions] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState(null);

  const [formData, setFormData] = useState({
    type: 'expense',
    category: '식비',
    amount: '',
    description: '',
    date: new Date().toISOString().split('T')[0]
  });

  const categories = {
    expense: ['식비', '교통', '쇼핑', '엔터테인먼트', '의료', '유틸리티', '기타'],
    income: ['급여', '부업', '투자', '기타']
  };

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [txRes, statRes] = await Promise.all([
        transactionApi.getAll(),
        statisticsApi.get()
      ]);
      setTransactions(txRes.data);
      setStats(statRes.data.summary);
      setError('');
    } catch (err) {
      setError('데이터를 불러올 수 없습니다');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
      category: name === 'type' ? categories[value][0] : prev.category
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!formData.amount) {
        setError('금액을 입력하세요');
        return;
      }

      if (editingId) {
        await transactionApi.update(editingId, {
          ...formData,
          amount: parseFloat(formData.amount)
        });
        setEditingId(null);
      } else {
        await transactionApi.create({
          ...formData,
          amount: parseFloat(formData.amount)
        });
      }

      setFormData({
        type: 'expense',
        category: '식비',
        amount: '',
        description: '',
        date: new Date().toISOString().split('T')[0]
      });

      await loadData();
    } catch (err) {
      setError('작업 실패: ' + (err.response?.data?.error || ''));
    }
  };

  const handleEdit = (transaction) => {
    setFormData({
      type: transaction.type,
      category: transaction.category,
      amount: transaction.amount.toString(),
      description: transaction.description,
      date: transaction.date
    });
    setEditingId(transaction.id);
  };

  const handleDelete = async (id) => {
    if (confirm('삭제하시겠습니까?')) {
      try {
        await transactionApi.delete(id);
        await loadData();
      } catch (err) {
        setError('삭제 실패');
      }
    }
  };

  const handleCancel = () => {
    setEditingId(null);
    setFormData({
      type: 'expense',
      category: '식비',
      amount: '',
      description: '',
      date: new Date().toISOString().split('T')[0]
    });
  };

  if (loading) {
    return <div className="container" style={{ textAlign: 'center', padding: '40px', color: 'white' }}>로딩중...</div>;
  }

  const totalExpense = stats?.totalExpense || 0;
  const totalIncome = stats?.totalIncome || 0;
  const balance = totalIncome - totalExpense;

  return (
    <div className="container">
      <div className="header">
        <h1>가계부</h1>
        <div className="user-info">
          <span>{user.name}님</span>
          <button className="logout-btn" onClick={onLogout}>로그아웃</button>
        </div>
      </div>

      {error && <div className="error-message">{error}</div>}

      <div className="stats">
        <div className="stat-card income">
          <h3>총 수입</h3>
          <div className="amount">₩{totalIncome.toLocaleString()}</div>
        </div>
        <div className="stat-card expense">
          <h3>총 지출</h3>
          <div className="amount">₩{totalExpense.toLocaleString()}</div>
        </div>
      </div>

      <div className="main-content">
        <div className="card">
          <h2>{editingId ? '거래 수정' : '거래 추가'}</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>구분</label>
              <select name="type" value={formData.type} onChange={handleInputChange}>
                <option value="expense">지출</option>
                <option value="income">수입</option>
              </select>
            </div>

            <div className="form-group">
              <label>카테고리</label>
              <select name="category" value={formData.category} onChange={handleInputChange}>
                {categories[formData.type].map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>금액</label>
              <input
                type="number"
                name="amount"
                value={formData.amount}
                onChange={handleInputChange}
                placeholder="금액을 입력하세요"
                step="0.01"
                min="0"
                required
              />
            </div>

            <div className="form-group">
              <label>설명</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                placeholder="설명을 입력하세요"
              />
            </div>

            <div className="form-group">
              <label>날짜</label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="btn-group">
              {editingId && (
                <button type="button" className="btn btn-secondary" onClick={handleCancel}>
                  취소
                </button>
              )}
              <button type="submit" className="btn btn-primary">
                {editingId ? '수정' : '추가'}
              </button>
            </div>
          </form>
        </div>

        <div className="card">
          <h2>최근 거래 ({transactions.length})</h2>
          <div className="transactions-list">
            {transactions.length === 0 ? (
              <div className="empty-state">
                <p>거래 기록이 없습니다</p>
              </div>
            ) : (
              transactions.map(tx => (
                <div key={tx.id} className={`transaction-item ${tx.type}`}>
                  <div className="transaction-info">
                    <h4>{tx.category}</h4>
                    <p>{tx.date} {tx.description && `· ${tx.description}`}</p>
                  </div>
                  <div className={`transaction-amount ${tx.type}`}>
                    {tx.type === 'expense' ? '-' : '+'} ₩{tx.amount.toLocaleString()}
                  </div>
                  <div className="transaction-actions">
                    <button
                      className="btn btn-edit"
                      onClick={() => handleEdit(tx)}
                    >
                      수정
                    </button>
                    <button
                      className="btn btn-danger"
                      onClick={() => handleDelete(tx.id)}
                    >
                      삭제
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: '20px' }}>
        <h2>잔액</h2>
        <div style={{
          fontSize: '36px',
          fontWeight: 'bold',
          textAlign: 'center',
          color: balance >= 0 ? '#51cf66' : '#ff6b6b',
          padding: '20px'
        }}>
          ₩{balance.toLocaleString()}
        </div>
      </div>
    </div>
  );
}
