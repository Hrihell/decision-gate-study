# 가계부 앱

로그인 기능과 데이터 저장이 가능한 가계부 애플리케이션입니다.

## 기능

- **회원 인증**: 이메일/비밀번호 기반 회원가입 및 로그인
- **거래 기록**: 수입/지출 기록 추가, 수정, 삭제
- **카테고리 관리**: 지출과 수입에 따른 카테고리 분류
- **통계 및 잔액**: 총 수입, 총 지출, 현재 잔액 표시
- **데이터 영속성**: SQLite 데이터베이스를 통한 데이터 저장

## 프로젝트 구조

```
household-budget/
├── backend/
│   ├── server.js              # Express 메인 서버
│   ├── db.js                  # SQLite 데이터베이스 초기화
│   ├── authMiddleware.js      # JWT 토큰 인증 미들웨어
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── main.jsx           # 진입점
│   │   ├── App.jsx            # 메인 컴포넌트
│   │   ├── App.css            # 전역 스타일
│   │   ├── api.js             # API 클라이언트
│   │   └── pages/
│   │       ├── Login.jsx      # 로그인/회원가입 페이지
│   │       └── Dashboard.jsx  # 가계부 메인 페이지
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
└── README.md
```

## 설치 및 실행

### 1. 백엔드 설정

```bash
cd backend
npm install
npm start
```

서버는 `http://localhost:3001`에서 실행됩니다.

### 2. 프론트엔드 설정

```bash
cd frontend
npm install
npm run dev
```

앱은 `http://localhost:3000`에서 실행됩니다.

## 기술 스택

### 백엔드
- **Node.js/Express**: 웹 서버
- **SQLite**: 데이터베이스
- **JWT**: 토큰 기반 인증
- **bcryptjs**: 비밀번호 암호화

### 프론트엔드
- **React**: UI 프레임워크
- **Vite**: 빌드 도구
- **Axios**: HTTP 클라이언트

## API 엔드포인트

### 인증
- `POST /api/auth/signup` - 회원가입
- `POST /api/auth/login` - 로그인

### 거래
- `GET /api/transactions` - 거래 목록 조회
- `POST /api/transactions` - 거래 추가
- `PUT /api/transactions/:id` - 거래 수정
- `DELETE /api/transactions/:id` - 거래 삭제

### 통계
- `GET /api/statistics` - 통계 데이터 조회

## 사용 방법

1. 앱을 실행하고 회원가입 또는 로그인
2. 거래 추가 폼에서 수입/지출 기록
3. 거래 목록에서 기록 확인, 수정, 삭제
4. 대시보드에서 총 수입, 총 지출, 잔액 확인

## 테스트 계정

앱을 테스트하기 위해 새 계정을 생성하거나 원하는 이메일과 비밀번호로 회원가입할 수 있습니다.
