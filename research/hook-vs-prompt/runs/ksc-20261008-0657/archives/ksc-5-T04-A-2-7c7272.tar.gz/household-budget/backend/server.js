import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { initDb, getDb } from './db.js';
import { authMiddleware, generateToken } from './authMiddleware.js';

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// 회원가입
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    const db = getDb();

    const existingUser = db.get('SELECT * FROM users WHERE email = ?', [email]);
    if (existingUser) {
      return res.status(400).json({ error: '이미 가입된 이메일입니다' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const result = db.run(
      'INSERT INTO users (email, password, name) VALUES (?, ?, ?)',
      [email, hashedPassword, name]
    );

    const token = generateToken(result.lastID);
    res.json({
      token,
      user: { id: result.lastID, email, name }
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 로그인
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const db = getDb();

    const user = db.get(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (!user) {
      return res.status(400).json({ error: '사용자를 찾을 수 없습니다' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(400).json({ error: '비밀번호가 틀렸습니다' });
    }

    const token = generateToken(user.id);
    res.json({
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 거래 추가
app.post('/api/transactions', authMiddleware, (req, res) => {
  try {
    const { type, category, amount, description, date } = req.body;
    const db = getDb();

    const result = db.run(
      'INSERT INTO transactions (user_id, type, category, amount, description, date) VALUES (?, ?, ?, ?, ?, ?)',
      [req.userId, type, category, amount, description, date]
    );

    res.json({ id: result.lastID, ...req.body });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 거래 목록 조회
app.get('/api/transactions', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const transactions = db.all(
      'SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC',
      [req.userId]
    );
    res.json(transactions);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 거래 수정
app.put('/api/transactions/:id', authMiddleware, (req, res) => {
  try {
    const { type, category, amount, description, date } = req.body;
    const db = getDb();

    const transaction = db.get(
      'SELECT * FROM transactions WHERE id = ? AND user_id = ?',
      [req.params.id, req.userId]
    );

    if (!transaction) {
      return res.status(404).json({ error: '거래를 찾을 수 없습니다' });
    }

    db.run(
      'UPDATE transactions SET type = ?, category = ?, amount = ?, description = ?, date = ? WHERE id = ?',
      [type, category, amount, description, date, req.params.id]
    );

    res.json({ id: req.params.id, ...req.body });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 거래 삭제
app.delete('/api/transactions/:id', authMiddleware, (req, res) => {
  try {
    const db = getDb();

    const transaction = db.get(
      'SELECT * FROM transactions WHERE id = ? AND user_id = ?',
      [req.params.id, req.userId]
    );

    if (!transaction) {
      return res.status(404).json({ error: '거래를 찾을 수 없습니다' });
    }

    db.run(
      'DELETE FROM transactions WHERE id = ?',
      [req.params.id]
    );

    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 통계
app.get('/api/statistics', authMiddleware, (req, res) => {
  try {
    const db = getDb();

    const stats = db.all(
      'SELECT type, category, SUM(amount) as total, COUNT(*) as count FROM transactions WHERE user_id = ? GROUP BY type, category',
      [req.userId]
    );

    const txs = db.all(
      'SELECT * FROM transactions WHERE user_id = ?',
      [req.userId]
    );

    let totalExpense = 0;
    let totalIncome = 0;
    txs.forEach(t => {
      if (t.type === 'expense') totalExpense += t.amount;
      else totalIncome += t.amount;
    });

    const summary = { totalExpense, totalIncome };
    res.json({ stats, summary });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

function start() {
  initDb();
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

start();
