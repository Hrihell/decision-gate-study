import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, 'data.json');

let data = {
  users: [],
  transactions: [],
  nextUserId: 1,
  nextTransactionId: 1
};

function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function loadData() {
  if (fs.existsSync(DATA_FILE)) {
    const content = fs.readFileSync(DATA_FILE, 'utf-8');
    data = JSON.parse(content);
  }
}

export async function initDb() {
  loadData();
  return data;
}

export function getDb() {
  return {
    run: (sql, params, callback) => {
      let result = { lastID: null };

      if (sql.includes('INSERT INTO users')) {
        const user = {
          id: data.nextUserId++,
          email: params[0],
          password: params[1],
          name: params[2],
          created_at: new Date().toISOString()
        };
        data.users.push(user);
        result.lastID = user.id;
        saveData();
      }

      if (sql.includes('INSERT INTO transactions')) {
        const tx = {
          id: data.nextTransactionId++,
          user_id: params[0],
          type: params[1],
          category: params[2],
          amount: params[3],
          description: params[4],
          date: params[5],
          created_at: new Date().toISOString()
        };
        data.transactions.push(tx);
        result.lastID = tx.id;
        saveData();
      }

      if (sql.includes('UPDATE transactions')) {
        const txId = params[5];
        const tx = data.transactions.find(t => t.id == txId);
        if (tx) {
          tx.type = params[0];
          tx.category = params[1];
          tx.amount = params[2];
          tx.description = params[3];
          tx.date = params[4];
          saveData();
        }
      }

      if (sql.includes('DELETE FROM transactions')) {
        const txId = params[0];
        data.transactions = data.transactions.filter(t => t.id != txId);
        saveData();
      }

      return result;
    },

    get: (sql, params) => {
      if (sql.includes('SELECT * FROM users WHERE email')) {
        return data.users.find(u => u.email === params[0]);
      }
      if (sql.includes('SELECT * FROM transactions WHERE id')) {
        return data.transactions.find(t => t.id == params[0] && t.user_id == params[1]);
      }
      return null;
    },

    all: (sql, params) => {
      if (sql.includes('SELECT * FROM transactions WHERE user_id')) {
        return data.transactions.filter(t => t.user_id == params[0]).sort((a, b) =>
          new Date(b.date) - new Date(a.date)
        );
      }
      if (sql.includes('SELECT type, category')) {
        return data.transactions
          .filter(t => t.user_id == params[0])
          .reduce((acc, t) => {
            const existing = acc.find(x => x.type === t.type && x.category === t.category);
            if (existing) {
              existing.total += t.amount;
              existing.count++;
            } else {
              acc.push({ type: t.type, category: t.category, total: t.amount, count: 1 });
            }
            return acc;
          }, []);
      }
      return [];
    }
  };
}
