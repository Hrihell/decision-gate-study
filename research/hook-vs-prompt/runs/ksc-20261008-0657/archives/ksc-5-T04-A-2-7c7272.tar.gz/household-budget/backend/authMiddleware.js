import jwt from 'jsonwebtoken';

const SECRET = 'your-secret-key-change-in-production';

export function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: '토큰이 없습니다' });
  }

  try {
    const decoded = jwt.verify(token, SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    res.status(401).json({ error: '유효하지 않은 토큰입니다' });
  }
}

export function generateToken(userId) {
  return jwt.sign({ userId }, SECRET, { expiresIn: '7d' });
}
