# My Blog

A simple, elegant blog built with Next.js, TypeScript, and Tailwind CSS.

## Features

- 🚀 Built with Next.js 15
- ✨ TypeScript support
- 🎨 Styled with Tailwind CSS
- 📝 Markdown-based posts
- ⚡ Static generation for optimal performance
- 🔍 SEO-friendly

## Getting Started

### Prerequisites

- Node.js 18.17 or later
- npm or yarn

### Installation

1. Navigate to the project directory:

```bash
cd blog
```

2. Install dependencies:

```bash
npm install
```

3. Start the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser to see the blog.

## Adding Blog Posts

Blog posts are stored as Markdown files in the `posts` directory. Each post should have front matter with the following structure:

```markdown
---
title: "Post Title"
date: "2026-01-15"
excerpt: "A brief description of the post"
---

# Your Content Here

Your markdown content goes here...
```

### Post Metadata

- `title` (required): The title of your blog post
- `date` (required): The publication date in ISO format (YYYY-MM-DD)
- `excerpt` (optional): A brief summary shown on the homepage

## Project Structure

```
blog/
├── app/
│   ├── layout.tsx       # Root layout component
│   ├── page.tsx         # Homepage
│   ├── posts/
│   │   └── [slug]/
│   │       └── page.tsx # Individual post page
│   └── globals.css      # Global styles
├── lib/
│   └── posts.ts         # Post utility functions
├── posts/               # Blog posts (Markdown files)
├── public/              # Static files
├── package.json
├── next.config.js
├── tailwind.config.js
└── tsconfig.json
```

## Building for Production

To create a production build:

```bash
npm run build
npm run start
```

The blog will be optimized for performance and ready for deployment.

## Deployment

This blog can be easily deployed to:

- [Vercel](https://vercel.com) (recommended for Next.js)
- [Netlify](https://netlify.com)
- Any server that supports Node.js

## Customization

### Change Blog Title

Edit the `title` in `app/layout.tsx` and `next.config.js`.

### Update Styling

Modify Tailwind CSS configuration in `tailwind.config.js` or edit the styles in `app/globals.css`.

### Add More Features

Consider adding:
- Comments system
- Categories/tags
- Search functionality
- Dark mode
- Newsletter subscription

## License

MIT
