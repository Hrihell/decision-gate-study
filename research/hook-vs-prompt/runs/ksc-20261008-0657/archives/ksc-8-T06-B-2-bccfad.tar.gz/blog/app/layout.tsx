import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'My Blog',
  description: 'A simple blog built with Next.js',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-white text-gray-900">
        <header className="bg-gray-50 border-b border-gray-200">
          <nav className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <a href="/" className="text-2xl font-bold text-gray-900">
              My Blog
            </a>
          </nav>
        </header>
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {children}
        </main>
        <footer className="bg-gray-50 border-t border-gray-200 mt-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-gray-500 text-sm">
            <p>&copy; 2026 My Blog. All rights reserved.</p>
          </div>
        </footer>
      </body>
    </html>
  )
}
