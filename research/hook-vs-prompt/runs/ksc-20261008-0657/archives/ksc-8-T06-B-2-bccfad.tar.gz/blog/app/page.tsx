import Link from 'next/link'
import { getAllPosts } from '@/lib/posts'

export default function Home() {
  const posts = getAllPosts()

  return (
    <div>
      <h1 className="text-4xl font-bold mb-8">Welcome to My Blog</h1>

      {posts.length === 0 ? (
        <p className="text-gray-500">No posts yet. Add some posts to the <code>posts</code> directory!</p>
      ) : (
        <div className="space-y-8">
          {posts.map((post) => (
            <article key={post.slug} className="border-b border-gray-200 pb-8">
              <h2 className="text-2xl font-bold mb-2">
                <Link href={`/posts/${post.slug}`} className="text-blue-600 hover:text-blue-800">
                  {post.title}
                </Link>
              </h2>
              <p className="text-gray-500 text-sm mb-3">
                {new Date(post.date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </p>
              {post.excerpt && (
                <p className="text-gray-700 mb-3">{post.excerpt}</p>
              )}
              <Link
                href={`/posts/${post.slug}`}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                Read more →
              </Link>
            </article>
          ))}
        </div>
      )}
    </div>
  )
}
