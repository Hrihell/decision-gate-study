---
title: "My First Blog Post"
date: "2026-01-15"
excerpt: "Welcome to my blog! This is my first post exploring Next.js."
---

# Welcome to My Blog

This is my first blog post! I'm excited to share my thoughts and ideas here.

## What is this blog about?

This blog is built with [Next.js](https://nextjs.org/), a React framework that makes it easy to build web applications.

## Features

- **Fast and performant** - Built on React and Next.js
- **Markdown support** - Write posts in Markdown
- **Static generation** - Posts are pre-rendered for maximum performance
- **Clean design** - Styled with Tailwind CSS

## Getting started

To get started with your own blog, follow these steps:

1. Clone the repository
2. Install dependencies with `npm install`
3. Add your blog posts to the `posts` directory
4. Run `npm run dev` to start the development server

Enjoy blogging!
