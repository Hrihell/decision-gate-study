# 💰 HouseBook - Personal Finance Manager

A full-stack application for tracking household expenses and income.

## Features

- 🔐 User registration and login
- 📊 Expense and income tracking
- 💾 Data persistence with SQLite
- 📈 Financial summary and statistics
- ✏️ Edit and delete transactions
- 📱 Responsive design

## Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm

### Installation & Running

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the backend server (Terminal 1):**
   ```bash
   npm run server
   ```
   The backend will run on `http://localhost:5000`

3. **Start the frontend dev server (Terminal 2):**
   ```bash
   npm run dev
   ```
   The frontend will run on `http://localhost:5173` (or similar port)

4. **Open in browser:**
   Navigate to `http://localhost:5173`

## Usage

1. **Create an account** - Register with your email and password
2. **Login** - Log in with your credentials
3. **Add transactions** - Click "+ Add Transaction" to record expenses or income
4. **View summary** - See your total income, expenses, and balance at the top
5. **Manage transactions** - Edit or delete existing transactions using the buttons next to each entry

## Technology Stack

- **Frontend:** React 19 + Vite
- **Backend:** Express.js
- **Database:** SQLite3
- **Authentication:** JWT + bcrypt
- **Styling:** CSS3

## API Endpoints

- `POST /api/register` - Register new user
- `POST /api/login` - Login user
- `GET /api/transactions` - Get all transactions (requires auth)
- `POST /api/transactions` - Create transaction (requires auth)
- `PUT /api/transactions/:id` - Update transaction (requires auth)
- `DELETE /api/transactions/:id` - Delete transaction (requires auth)

## Database

The app uses SQLite3 which creates a `housebook.db` file in the root directory. No setup needed!

## Notes

- Change the `JWT_SECRET` in `server.js` for production use
- Transactions are stored per user
- Amounts are stored with KRW (₩) currency symbol, but the app can be adapted for any currency
