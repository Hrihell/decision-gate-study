import { useState, useEffect } from 'react';
import './HouseBook.css';

const API_URL = 'http://localhost:5000';

function HouseBook({ user, onLogout }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    category: 'Food',
    amount: '',
    description: '',
    type: 'expense',
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/api/transactions`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const data = await response.json();
      setTransactions(data);
    } catch (err) {
      console.error('Failed to fetch transactions:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.amount) {
      alert('Please enter an amount');
      return;
    }

    try {
      const method = editId ? 'PUT' : 'POST';
      const endpoint = editId ? `/api/transactions/${editId}` : '/api/transactions';

      const response = await fetch(`${API_URL}${endpoint}`, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        fetchTransactions();
        setShowForm(false);
        setEditId(null);
        setFormData({
          date: new Date().toISOString().split('T')[0],
          category: 'Food',
          amount: '',
          description: '',
          type: 'expense',
        });
      } else {
        alert('Failed to save transaction');
      }
    } catch (err) {
      console.error('Error saving transaction:', err);
      alert('Error saving transaction');
    }
  };

  const handleEdit = (transaction) => {
    setFormData(transaction);
    setEditId(transaction.id);
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure?')) return;

    try {
      const response = await fetch(`${API_URL}/api/transactions/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        fetchTransactions();
      }
    } catch (err) {
      console.error('Error deleting transaction:', err);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditId(null);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      category: 'Food',
      amount: '',
      description: '',
      type: 'expense',
    });
  };

  const totalExpense = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = totalIncome - totalExpense;

  return (
    <div className="housebook-container">
      <div className="header">
        <h1>💰 HouseBook</h1>
        <button className="logout-btn" onClick={onLogout}>Logout</button>
      </div>

      <div className="user-info">
        Welcome, {user.email}
      </div>

      <div className="summary">
        <div className="summary-card income">
          <div className="label">Income</div>
          <div className="amount">₩{totalIncome.toLocaleString()}</div>
        </div>
        <div className="summary-card expense">
          <div className="label">Expense</div>
          <div className="amount">₩{totalExpense.toLocaleString()}</div>
        </div>
        <div className="summary-card balance">
          <div className="label">Balance</div>
          <div className={`amount ${balance >= 0 ? 'positive' : 'negative'}`}>
            ₩{balance.toLocaleString()}
          </div>
        </div>
      </div>

      <button
        className="add-btn"
        onClick={() => {
          setEditId(null);
          setShowForm(true);
          setFormData({
            date: new Date().toISOString().split('T')[0],
            category: 'Food',
            amount: '',
            description: '',
            type: 'expense',
          });
        }}
      >
        + Add Transaction
      </button>

      {showForm && (
        <div className="form-container">
          <div className="form-box">
            <h2>{editId ? 'Edit' : 'Add'} Transaction</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                >
                  <option value="expense">Expense</option>
                  <option value="income">Income</option>
                </select>
              </div>

              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                />
              </div>

              <div className="form-group">
                <label>Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                >
                  <option value="Food">Food</option>
                  <option value="Transport">Transport</option>
                  <option value="Entertainment">Entertainment</option>
                  <option value="Shopping">Shopping</option>
                  <option value="Bills">Bills</option>
                  <option value="Healthcare">Healthcare</option>
                  <option value="Salary">Salary</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="form-group">
                <label>Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({...formData, amount: parseFloat(e.target.value)})}
                  placeholder="0"
                />
              </div>

              <div className="form-group">
                <label>Description</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Optional"
                />
              </div>

              <div className="form-actions">
                <button type="submit" className="save-btn">Save</button>
                <button type="button" className="cancel-btn" onClick={handleCancel}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="transactions-section">
        <h2>Transactions</h2>
        {loading ? (
          <p>Loading...</p>
        ) : transactions.length === 0 ? (
          <p className="empty-state">No transactions yet. Add one to get started!</p>
        ) : (
          <div className="transactions-list">
            {transactions.map((transaction) => (
              <div key={transaction.id} className={`transaction-item ${transaction.type}`}>
                <div className="transaction-info">
                  <div className="transaction-header">
                    <span className="category">{transaction.category}</span>
                    <span className="date">{new Date(transaction.date).toLocaleDateString()}</span>
                  </div>
                  {transaction.description && (
                    <p className="description">{transaction.description}</p>
                  )}
                </div>
                <div className="transaction-amount">
                  <span className={`amount ${transaction.type}`}>
                    {transaction.type === 'expense' ? '-' : '+'}₩{transaction.amount.toLocaleString()}
                  </span>
                </div>
                <div className="transaction-actions">
                  <button
                    className="edit-btn"
                    onClick={() => handleEdit(transaction)}
                  >
                    ✏️
                  </button>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(transaction.id)}
                  >
                    🗑️
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default HouseBook;
