const USERS_KEY = 'users';
const SESSION_KEY = 'currentUser';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(SESSION_KEY);
}

function setCurrentUser(username) {
  if (username) {
    localStorage.setItem(SESSION_KEY, username);
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

function loadTodos(username) {
  const users = getUsers();
  return JSON.parse((users[username]?.todos) || '[]');
}

function saveTodos(username, todos) {
  const users = getUsers();
  if (!users[username]) users[username] = {};
  users[username].todos = JSON.stringify(todos);
  saveUsers(users);
}

function renderTodos(todos) {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const username = getCurrentUser();
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(username, next);
      renderTodos(next);
    });
    list.appendChild(item);
  });
}

function showAuthPage() {
  document.getElementById('auth-page').style.display = 'block';
  document.getElementById('todo-page').style.display = 'none';
}

function showTodoPage() {
  document.getElementById('auth-page').style.display = 'none';
  document.getElementById('todo-page').style.display = 'block';
  const username = getCurrentUser();
  renderTodos(loadTodos(username));
}

function showError(message) {
  const errorDiv = document.getElementById('auth-error');
  errorDiv.textContent = message;
  errorDiv.style.display = 'block';
  setTimeout(() => {
    errorDiv.style.display = 'none';
  }, 3000);
}

document.getElementById('switch-signup').addEventListener('click', (e) => {
  e.preventDefault();
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('signup-form').style.display = 'block';
});

document.getElementById('switch-login').addEventListener('click', (e) => {
  e.preventDefault();
  document.getElementById('signup-form').style.display = 'none';
  document.getElementById('login-form').style.display = 'block';
});

document.getElementById('login-submit').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;

  const users = getUsers();
  if (!users[username] || users[username].password !== password) {
    showError('사용자명 또는 비밀번호가 잘못되었습니다');
    return;
  }

  setCurrentUser(username);
  document.getElementById('login-username').value = '';
  document.getElementById('login-password').value = '';
  showTodoPage();
});

document.getElementById('signup-submit').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('signup-username').value.trim();
  const password = document.getElementById('signup-password').value;
  const passwordConfirm = document.getElementById('signup-password-confirm').value;

  if (password !== passwordConfirm) {
    showError('비밀번호가 일치하지 않습니다');
    return;
  }

  if (password.length < 4) {
    showError('비밀번호는 최소 4글자 이상이어야 합니다');
    return;
  }

  const users = getUsers();
  if (users[username]) {
    showError('이미 존재하는 사용자명입니다');
    return;
  }

  users[username] = { password, todos: '[]' };
  saveUsers(users);

  setCurrentUser(username);
  document.getElementById('signup-username').value = '';
  document.getElementById('signup-password').value = '';
  document.getElementById('signup-password-confirm').value = '';
  showTodoPage();
});

document.getElementById('logout-btn').addEventListener('click', () => {
  setCurrentUser(null);
  document.getElementById('signup-form').style.display = 'none';
  document.getElementById('login-form').style.display = 'block';
  showAuthPage();
});

document.getElementById('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = document.getElementById('new-todo');
  if (input.value.trim() === '') return;
  const username = getCurrentUser();
  const todos = loadTodos(username);
  const next = [...todos, { text: input.value.trim(), done: false }];
  saveTodos(username, next);
  renderTodos(next);
  input.value = '';
});

const currentUser = getCurrentUser();
if (currentUser) {
  showTodoPage();
} else {
  showAuthPage();
}
