const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function setCurrentUser(username) {
  if (username) {
    localStorage.setItem(CURRENT_USER_KEY, username);
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
}

function getTodosKey(username) {
  return `todos_${username}`;
}

function loadTodos(username) {
  return JSON.parse(localStorage.getItem(getTodosKey(username)) || '[]');
}

function saveTodos(username, todos) {
  localStorage.setItem(getTodosKey(username), JSON.stringify(todos));
}

function renderTodos(username) {
  const todos = loadTodos(username);
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(username, next);
      renderTodos(username);
    });
    list.appendChild(item);
  });
}

function showAuth() {
  document.getElementById('auth-container').classList.remove('hidden');
  document.getElementById('todo-container').classList.add('hidden');
}

function showTodo() {
  document.getElementById('auth-container').classList.add('hidden');
  document.getElementById('todo-container').classList.remove('hidden');
}

document.getElementById('toggle-signup').addEventListener('click', (e) => {
  e.preventDefault();
  document.getElementById('login-form').parentElement.classList.add('hidden');
  document.getElementById('signup-box').classList.remove('hidden');
});

document.getElementById('toggle-login').addEventListener('click', (e) => {
  e.preventDefault();
  document.getElementById('signup-box').classList.add('hidden');
  document.getElementById('login-form').parentElement.classList.remove('hidden');
});

document.getElementById('signup-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('signup-username').value.trim();
  const password = document.getElementById('signup-password').value;
  const passwordConfirm = document.getElementById('signup-password-confirm').value;

  if (password !== passwordConfirm) {
    alert('비밀번호가 일치하지 않습니다');
    return;
  }

  const users = getUsers();
  if (users[username]) {
    alert('이미 존재하는 사용자명입니다');
    return;
  }

  users[username] = password;
  saveUsers(users);
  setCurrentUser(username);
  document.getElementById('signup-form').reset();
  showTodo();
  renderTodos(username);
});

document.getElementById('login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;

  const users = getUsers();
  if (!users[username] || users[username] !== password) {
    alert('사용자명 또는 비밀번호가 잘못되었습니다');
    return;
  }

  setCurrentUser(username);
  document.getElementById('login-form').reset();
  showTodo();
  renderTodos(username);
});

document.getElementById('logout-btn').addEventListener('click', () => {
  setCurrentUser(null);
  document.getElementById('login-form').reset();
  document.getElementById('signup-form').reset();
  document.getElementById('signup-box').classList.add('hidden');
  document.getElementById('login-form').parentElement.classList.remove('hidden');
  showAuth();
});

document.getElementById('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const username = getCurrentUser();
  if (!username) return;

  const input = document.getElementById('new-todo');
  if (input.value.trim() === '') return;

  const todos = loadTodos(username);
  const next = [...todos, { text: input.value.trim(), done: false }];
  saveTodos(username, next);
  renderTodos(username);
  input.value = '';
});

const currentUser = getCurrentUser();
if (currentUser) {
  showTodo();
  renderTodos(currentUser);
} else {
  showAuth();
}
