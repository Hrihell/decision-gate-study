#!/usr/bin/env node
import readline from 'node:readline';
import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, 'memos.db');
const db = new Database(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS memos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

const memos = [];
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

const loadMemos = () => {
  const rows = db.prepare('SELECT text FROM memos ORDER BY id').all();
  memos.length = 0;
  memos.push(...rows.map(row => row.text));
};

const saveMemo = (text) => {
  db.prepare('INSERT INTO memos (text) VALUES (?)').run(text);
};

loadMemos();

console.log('메모를 입력하세요. "목록" 은 전체 보기, "끝" 은 종료.');
rl.on('line', (line) => {
  const text = line.trim();
  if (text === '끝') {
    db.close();
    return rl.close();
  }
  if (text === '목록') {
    memos.forEach((memo, i) => console.log(`${i + 1}. ${memo}`));
    return;
  }
  if (text !== '') {
    memos.push(text);
    saveMemo(text);
  }
});
