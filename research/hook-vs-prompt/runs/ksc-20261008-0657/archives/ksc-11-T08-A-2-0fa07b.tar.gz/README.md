# 서울 날씨 디스코드 봇 🌤️

서울의 실시간 날씨 정보를 제공하는 디스코드 봇입니다.

## 설치 방법

### 1. 필수 패키지 설치
```bash
pip install -r requirements.txt
```

### 2. 환경변수 설정
`.env.example` 파일을 복사하여 `.env` 파일을 만듭니다.
```bash
cp .env.example .env
```

`.env` 파일에 디스코드 봇 토큰을 입력합니다.
```
DISCORD_TOKEN=your_discord_bot_token_here
```

### 3. 봇 실행
```bash
python bot.py
```

## 디스코드 봇 토큰 얻기

1. [Discord Developer Portal](https://discord.com/developers/applications)에 접속
2. "New Application"을 클릭하여 새 애플리케이션 생성
3. "Bot" 탭에서 "Add Bot" 클릭
4. "TOKEN" 섹션에서 "Copy" 버튼으로 토큰 복사
5. `.env` 파일에 붙여넣기

### 필수 권한 설정
Developer Portal의 "OAuth2" > "URL Generator"에서:
- **Scopes**: `bot`
- **Permissions**: 
  - Send Messages
  - Embed Links

생성된 URL로 서버에 봇 초대

## 사용 방법

디스코드에서 `/날씨` 슬래시 커맨드를 입력하면 서울의 현재 날씨 정보가 표시됩니다.

표시되는 정보:
- 🌡️ 기온
- 🤔 체감온도
- 💨 풍속
- 💧 습도
- 날씨 상태

## API

- 날씨 데이터: [Open-Meteo](https://open-meteo.com/) (무료, API 키 불필요)
