import discord
from discord.ext import commands
from discord import app_commands
import requests
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

def get_seoul_weather():
    """Open-Meteo API를 사용해 서울 날씨를 조회합니다."""
    try:
        # 서울 좌표: 위도 37.5665, 경도 126.9780
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": 37.5665,
            "longitude": 126.9780,
            "current": "temperature_2m,weather_code,wind_speed_10m,humidity,apparent_temperature",
            "timezone": "Asia/Seoul"
        }

        response = requests.get(url, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()

        current = data.get("current", {})

        temp = current.get("temperature_2m", "N/A")
        feels_like = current.get("apparent_temperature", "N/A")
        humidity = current.get("humidity", "N/A")
        wind_speed = current.get("wind_speed_10m", "N/A")
        weather_code = current.get("weather_code", 0)

        weather_desc = get_weather_description(weather_code)

        return {
            "temp": temp,
            "feels_like": feels_like,
            "humidity": humidity,
            "wind_speed": wind_speed,
            "description": weather_desc
        }
    except Exception as e:
        return {"error": f"날씨 정보를 가져오는 중 오류 발생: {str(e)}"}

def get_weather_description(code):
    """WMO 날씨 코드를 한글로 변환합니다."""
    weather_codes = {
        0: "맑음",
        1: "대체로 맑음",
        2: "부분적 흐림",
        3: "흐림",
        45: "안개",
        48: "결빙 안개",
        51: "가벼운 이슬비",
        53: "중간 이슬비",
        55: "심한 이슬비",
        61: "약한 비",
        63: "중간 비",
        65: "심한 비",
        71: "약한 눈",
        73: "중간 눈",
        75: "심한 눈",
        77: "눈입자",
        80: "약한 소나기",
        81: "중간 소나기",
        82: "심한 소나기",
        85: "약한 눈 소나기",
        86: "심한 눈 소나기",
        95: "뇌우",
        96: "약한 우박을 동반한 뇌우",
        99: "심한 우박을 동반한 뇌우",
    }
    return weather_codes.get(code, "알 수 없음")

@bot.event
async def on_ready():
    print(f"봇 로그인: {bot.user}")
    try:
        synced = await bot.tree.sync()
        print(f"슬래시 커맨드 동기화 완료: {len(synced)}개")
    except Exception as e:
        print(f"커맨드 동기화 오류: {e}")

@bot.tree.command(name="날씨", description="서울의 현재 날씨를 알려줍니다.")
async def weather(interaction: discord.Interaction):
    await interaction.response.defer()

    weather_data = get_seoul_weather()

    if "error" in weather_data:
        embed = discord.Embed(
            title="❌ 오류",
            description=weather_data["error"],
            color=discord.Color.red()
        )
    else:
        embed = discord.Embed(
            title="🌤️ 서울 날씨",
            description=f"**{weather_data['description']}**",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        embed.add_field(name="🌡️ 기온", value=f"{weather_data['temp']}°C", inline=True)
        embed.add_field(name="🤔 체감온도", value=f"{weather_data['feels_like']}°C", inline=True)
        embed.add_field(name="💨 풍속", value=f"{weather_data['wind_speed']} km/h", inline=True)
        embed.add_field(name="💧 습도", value=f"{weather_data['humidity']}%", inline=True)
        embed.set_footer(text="Open-Meteo API 기반")

    await interaction.followup.send(embed=embed)

def main():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        print("❌ 오류: DISCORD_TOKEN이 설정되지 않았습니다.")
        print(".env 파일에 DISCORD_TOKEN을 추가하세요.")
        return

    bot.run(token)

if __name__ == "__main__":
    main()
