const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
  secret: 'book-sharing-secret',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 1000 * 60 * 60 * 24 }
}));

const db = new sqlite3.Database('./books.db', (err) => {
  if (err) console.error(err);
  else console.log('SQLite 연결됨');
});

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      owner_id INTEGER NOT NULL,
      status TEXT DEFAULT 'available',
      description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(owner_id) REFERENCES users(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS rentals (
      id INTEGER PRIMARY KEY,
      book_id INTEGER NOT NULL,
      borrower_id INTEGER NOT NULL,
      rented_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      returned_at DATETIME,
      FOREIGN KEY(book_id) REFERENCES books(id),
      FOREIGN KEY(borrower_id) REFERENCES users(id)
    )
  `);
});

const isAuthenticated = (req, res, next) => {
  if (req.session.user) next();
  else res.redirect('/login');
};

app.get('/', (req, res) => {
  if (req.session.user) {
    db.all(`
      SELECT books.*, users.name as owner_name
      FROM books
      JOIN users ON books.owner_id = users.id
      WHERE books.status = 'available'
    `, (err, books) => {
      res.render('index', { user: req.session.user, books });
    });
  } else {
    res.render('login');
  }
});

app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', (req, res) => {
  const { username, email, name, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 8);

  db.run(
    `INSERT INTO users (username, email, name, password) VALUES (?, ?, ?, ?)`,
    [username, email, name, hashedPassword],
    function(err) {
      if (err) {
        return res.render('register', { error: '가입 실패. 이미 존재하는 계정일 수 있습니다.' });
      }
      res.redirect('/login');
    }
  );
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.get(`SELECT * FROM users WHERE username = ?`, [username], (err, user) => {
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.render('login', { error: '사용자명 또는 비밀번호가 올바르지 않습니다.' });
    }
    req.session.user = user;
    res.redirect('/');
  });
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

app.get('/my-books', isAuthenticated, (req, res) => {
  db.all(
    `SELECT * FROM books WHERE owner_id = ?`,
    [req.session.user.id],
    (err, books) => {
      res.render('my-books', { user: req.session.user, books });
    }
  );
});

app.get('/add-book', isAuthenticated, (req, res) => {
  res.render('add-book', { user: req.session.user });
});

app.post('/add-book', isAuthenticated, (req, res) => {
  const { title, author, description } = req.body;

  db.run(
    `INSERT INTO books (title, author, owner_id, description) VALUES (?, ?, ?, ?)`,
    [title, author, req.session.user.id, description],
    function(err) {
      if (err) console.error(err);
      res.redirect('/my-books');
    }
  );
});

app.post('/rent/:bookId', isAuthenticated, (req, res) => {
  const { bookId } = req.params;

  db.run(
    `INSERT INTO rentals (book_id, borrower_id) VALUES (?, ?)`,
    [bookId, req.session.user.id],
    function(err) {
      if (err) return res.status(400).json({ error: '대여 실패' });

      db.run(
        `UPDATE books SET status = 'rented' WHERE id = ?`,
        [bookId],
        () => {
          res.redirect('/');
        }
      );
    }
  );
});

app.post('/return/:bookId', isAuthenticated, (req, res) => {
  db.run(
    `UPDATE rentals SET returned_at = CURRENT_TIMESTAMP WHERE book_id = ? AND returned_at IS NULL`,
    [req.params.bookId],
    () => {
      db.run(
        `UPDATE books SET status = 'available' WHERE id = ?`,
        [req.params.bookId],
        () => {
          res.redirect('/my-books');
        }
      );
    }
  );
});

app.get('/history', isAuthenticated, (req, res) => {
  db.all(
    `SELECT books.title, books.author, users.name, rentals.rented_at, rentals.returned_at
     FROM rentals
     JOIN books ON rentals.book_id = books.id
     JOIN users ON books.owner_id = users.id
     WHERE rentals.borrower_id = ?
     ORDER BY rentals.rented_at DESC`,
    [req.session.user.id],
    (err, history) => {
      res.render('history', { user: req.session.user, history });
    }
  );
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`서버 실행 중: http://localhost:${PORT}`);
});
