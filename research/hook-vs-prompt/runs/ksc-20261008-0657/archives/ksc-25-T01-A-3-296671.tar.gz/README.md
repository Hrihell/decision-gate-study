# 📚 책 나눔 클럽

동아리 회원들이 중고 책을 서로 빌려주는 사이트입니다.

## 설치 및 실행

### 1. 필수 요구사항
- Node.js (v12 이상)
- npm

### 2. 설치
```bash
npm install
```

### 3. 실행
```bash
npm start
```

서버가 `http://localhost:3000` 에서 실행됩니다.

## 기능

### 👤 사용자 관리
- 회원가입 및 로그인
- 비밀번호 암호화

### 📖 책 관리
- 책 등록 (제목, 저자, 설명)
- 내가 등록한 책 목록 조회
- 책 상태 관리 (이용 가능/대여 중)

### 🔄 대여 시스템
- 이용 가능한 책 목록 보기
- 책 대여하기
- 대여한 책 반납하기
- 대여 기록 조회

## 디렉토리 구조
```
book-sharing-site/
├── server.js           # Express 서버 메인 파일
├── package.json        # 프로젝트 설정
├── books.db            # SQLite 데이터베이스
├── views/              # EJS 템플릿
│   ├── login.ejs
│   ├── register.ejs
│   ├── index.ejs
│   ├── add-book.ejs
│   ├── my-books.ejs
│   └── history.ejs
└── public/             # 정적 파일
    └── style.css
```

## 사용 방법

1. **회원가입**: `/register` 에서 계정 생성
2. **로그인**: 계정으로 로그인
3. **책 등록**: "책 등록" 버튼으로 내 책 추가
4. **책 대여**: 메인 페이지에서 다른 사람의 책 대여
5. **반납**: "내 책" 페이지에서 대여 중인 책 반납
6. **기록 조회**: "대여 기록" 페이지에서 대여 이력 확인

## 기술 스택
- **백엔드**: Node.js, Express
- **데이터베이스**: SQLite3
- **템플릿**: EJS
- **보안**: bcryptjs (비밀번호 암호화)
- **세션 관리**: express-session
