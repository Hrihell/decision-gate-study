const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

const todosFile = path.join(app.getPath('userData'), 'todos.json');

let mainWindow;
let todos = [];

function loadTodos() {
  try {
    if (fs.existsSync(todosFile)) {
      const data = fs.readFileSync(todosFile, 'utf8');
      todos = JSON.parse(data);
    }
  } catch (error) {
    console.error('Error loading todos:', error);
    todos = [];
  }
}

function saveTodos() {
  try {
    fs.writeFileSync(todosFile, JSON.stringify(todos, null, 2));
    if (mainWindow) {
      mainWindow.webContents.send('todos-updated', todos);
    }
  } catch (error) {
    console.error('Error saving todos:', error);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 700,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  mainWindow.loadFile('index.html');
}

ipcMain.handle('add-todo', (event, title) => {
  const id = Date.now();
  todos.push({ id, title, completed: false });
  saveTodos();
  return todos;
});

ipcMain.handle('get-todos', () => {
  return todos;
});

ipcMain.handle('delete-todo', (event, id) => {
  todos = todos.filter(t => t.id !== id);
  saveTodos();
  return todos;
});

ipcMain.handle('toggle-todo', (event, id) => {
  const todo = todos.find(t => t.id === id);
  if (todo) {
    todo.completed = !todo.completed;
    saveTodos();
  }
  return todos;
});

app.on('ready', () => {
  loadTodos();
  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  const allWindows = BrowserWindow.getAllWindows();
  if (allWindows.length === 0) {
    createWindow();
  }
});
