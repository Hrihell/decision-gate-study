const todoInput = document.getElementById('todoInput');
const addBtn = document.getElementById('addBtn');
const todoList = document.getElementById('todoList');

let todos = [];

async function loadTodos() {
  todos = await window.electronAPI.getTodos();
  renderTodos();
}

function renderTodos() {
  todoList.innerHTML = '';
  
  if (todos.length === 0) {
    todoList.innerHTML = '<div class="empty-state">할 일이 없습니다. 새로운 할 일을 추가해보세요!</div>';
    return;
  }

  todos.forEach(todo => {
    const todoItem = document.createElement('div');
    todoItem.className = `todo-item ${todo.completed ? 'completed' : ''}`;
    
    todoItem.innerHTML = `
      <input type="checkbox" class="todo-checkbox" ${todo.completed ? 'checked' : ''} data-id="${todo.id}">
      <span class="todo-text">${escapeHtml(todo.title)}</span>
      <button class="delete-btn" data-id="${todo.id}">삭제</button>
    `;
    
    todoList.appendChild(todoItem);
  });

  document.querySelectorAll('.todo-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', async (e) => {
      const id = parseInt(e.target.dataset.id);
      await window.electronAPI.toggleTodo(id);
      await loadTodos();
    });
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = parseInt(e.target.dataset.id);
      await window.electronAPI.deleteTodo(id);
      await loadTodos();
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

addBtn.addEventListener('click', async () => {
  const title = todoInput.value.trim();
  if (title) {
    await window.electronAPI.addTodo(title);
    todoInput.value = '';
    todoInput.focus();
    await loadTodos();
  }
});

todoInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addBtn.click();
  }
});

window.electronAPI.onTodosUpdated((newTodos) => {
  todos = newTodos;
  renderTodos();
});

loadTodos();
