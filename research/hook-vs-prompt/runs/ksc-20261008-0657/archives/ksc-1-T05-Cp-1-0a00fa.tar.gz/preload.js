const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  addTodo: (title) => ipcRenderer.invoke('add-todo', title),
  getTodos: () => ipcRenderer.invoke('get-todos'),
  deleteTodo: (id) => ipcRenderer.invoke('delete-todo', id),
  toggleTodo: (id) => ipcRenderer.invoke('toggle-todo', id),
  onTodosUpdated: (callback) => ipcRenderer.on('todos-updated', (event, todos) => callback(todos)),
});
