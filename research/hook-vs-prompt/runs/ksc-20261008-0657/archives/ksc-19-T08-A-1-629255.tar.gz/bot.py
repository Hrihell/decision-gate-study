import discord
from discord.ext import commands
import aiohttp
import os
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/weather"
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")

SAMPLE_WEATHER = {
    'weather': [{'description': '맑음', 'main': 'Clear'}],
    'main': {
        'temp': 18.5,
        'feels_like': 17.2,
        'humidity': 62,
        'pressure': 1013
    },
    'wind': {'speed': 3.5},
    'visibility': 10000
}

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    print(f'Logged in as {bot.user.id}')

async def get_weather_data():
    """날씨 데이터 조회 (API 또는 샘플 데이터)"""
    if not WEATHER_API_KEY:
        return SAMPLE_WEATHER, True

    params = {
        'q': 'Seoul,KR',
        'appid': WEATHER_API_KEY,
        'units': 'metric',
        'lang': 'ko'
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(WEATHER_API_URL, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return data, False
                else:
                    return SAMPLE_WEATHER, True
    except Exception:
        return SAMPLE_WEATHER, True

@bot.command(name='날씨', help='서울의 현재 날씨를 알려줍니다')
async def get_seoul_weather(ctx):
    """서울 날씨 조회"""
    data, is_sample = await get_weather_data()

    embed = discord.Embed(
        title="🌍 서울 날씨",
        description=data['weather'][0]['description'].capitalize(),
        color=discord.Color.blue()
    )
    embed.add_field(name="🌡️ 기온", value=f"{data['main']['temp']}°C", inline=True)
    embed.add_field(name="🤔 체감온도", value=f"{data['main']['feels_like']}°C", inline=True)
    embed.add_field(name="💧 습도", value=f"{data['main']['humidity']}%", inline=True)
    embed.add_field(name="💨 풍속", value=f"{data['wind']['speed']} m/s", inline=True)
    embed.add_field(name="🔽 기압", value=f"{data['main']['pressure']} hPa", inline=True)
    embed.add_field(name="👁️ 가시거리", value=f"{data['visibility'] / 1000:.1f} km", inline=True)

    footer_text = f"업데이트: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    if is_sample:
        footer_text += " (샘플 데이터)"
    embed.set_footer(text=footer_text)

    await ctx.send(embed=embed)

@bot.command(name='핑', help='봇의 응답 속도를 확인합니다')
async def ping(ctx):
    """봇 핑 확인"""
    latency = bot.latency * 1000
    await ctx.send(f"🏓 Pong! ({latency:.2f}ms)")

def main():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        print("❌ DISCORD_TOKEN 환경변수가 설정되지 않았습니다.")
        print("사용 방법: DISCORD_TOKEN='your_token' python bot.py")
        return

    bot.run(token)

if __name__ == "__main__":
    main()
