# 서울 날씨 디스코드 봇 🌤️

서울의 현재 날씨를 디스코드에서 바로 확인할 수 있는 봇입니다.

## 기능
- `!날씨` - 서울의 현재 날씨 조회 (기온, 습도, 풍속, 기압 등)
- `!핑` - 봇의 응답 속도 확인

## 설치 방법

### 1. 필요한 라이브러리 설치
```bash
pip install -r requirements.txt
```

### 2. API 키 설정

#### 2-1. Discord 봇 토큰 발급
1. [Discord Developer Portal](https://discord.com/developers/applications)에 접속
2. "New Application" 클릭하여 새 앱 생성
3. "Bot" 탭에서 "Add Bot" 클릭
4. TOKEN 복사

#### 2-2. OpenWeatherMap API 키 발급
1. [OpenWeatherMap](https://openweathermap.org/api) 접속
2. 계정 생성 및 로그인
3. API Keys 메뉴에서 API 키 복사 (Current weather data 사용)

### 3. 환경변수 설정
`.env` 파일을 생성하고 다음과 같이 설정합니다:
```
DISCORD_TOKEN=your_discord_bot_token
WEATHER_API_KEY=your_openweathermap_api_key
```

또는 `.env.example`을 `.env`로 복사하여 토큰을 입력합니다:
```bash
cp .env.example .env
# .env 파일을 열어서 토큰 입력
```

## 실행 방법

### 환경변수 파일 사용
```bash
python bot.py
```

### 직접 환경변수 지정
```bash
DISCORD_TOKEN='your_token' WEATHER_API_KEY='your_key' python bot.py
```

## 봇 명령어

| 명령어 | 설명 |
|--------|------|
| `!날씨` | 서울의 현재 날씨 정보 조회 |
| `!핑` | 봇의 응답 속도 확인 |

## 예시 출력
```
🌍 서울 날씨
맑음

🌡️ 기온: 15°C
🤔 체감온도: 13°C
💧 습도: 65%
💨 풍속: 3.2 m/s
🔽 기압: 1013 hPa
👁️ 가시거리: 10.0 km
```

## 라이선스
MIT
