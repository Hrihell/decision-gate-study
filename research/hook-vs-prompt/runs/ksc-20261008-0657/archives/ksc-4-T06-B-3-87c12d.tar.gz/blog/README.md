# My Blog

A simple blog built with Next.js.

## Getting Started

First, install dependencies:

```bash
npm install
```

Then, run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Features

- Simple and clean design
- File-based routing with Next.js
- Read blog posts from markdown files
- Responsive layout

## Adding Blog Posts

To add a new blog post, create a new markdown file in the `posts` directory:

```
posts/my-new-post.md
```

The file name will be used as the URL slug, so `my-new-post.md` will be accessible at `/blog/my-new-post`.

## Project Structure

```
blog/
├── app/
│   ├── layout.jsx          # Root layout
│   ├── page.jsx            # Home page
│   ├── globals.css         # Global styles
│   └── blog/
│       ├── page.jsx        # Blog list page
│       └── [slug]/
│           └── page.jsx    # Individual blog post page
├── posts/                  # Blog post markdown files
├── public/                 # Static files
├── package.json
└── next.config.js
```

## Built With

- [Next.js](https://nextjs.org/)
- [React](https://react.dev/)
