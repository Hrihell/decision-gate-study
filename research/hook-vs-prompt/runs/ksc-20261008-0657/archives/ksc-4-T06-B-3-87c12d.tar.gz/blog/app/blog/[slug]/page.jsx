import Link from 'next/link'
import { readFile } from 'fs/promises'
import { notFound } from 'next/navigation'

async function getPost(slug) {
  try {
    const content = await readFile(`./posts/${slug}.md`, 'utf-8')
    return content
  } catch {
    return null
  }
}

export default async function BlogPost({ params }) {
  const content = await getPost(params.slug)

  if (!content) {
    notFound()
  }

  const title = params.slug.replace(/-/g, ' ').charAt(0).toUpperCase() + params.slug.replace(/-/g, ' ').slice(1)

  return (
    <article className="blog-post">
      <Link href="/blog" className="back-link">← Back to Blog</Link>
      <h1>{title}</h1>
      <div className="content">
        {content.split('\n').map((line, i) => (
          <p key={i}>{line}</p>
        ))}
      </div>
    </article>
  )
}
