export default function Home() {
  return (
    <div className="hero">
      <h1>Welcome to My Blog</h1>
      <p>A simple and elegant blog built with Next.js</p>
      <a href="/blog" className="cta-button">Read Blog Posts</a>
    </div>
  )
}
