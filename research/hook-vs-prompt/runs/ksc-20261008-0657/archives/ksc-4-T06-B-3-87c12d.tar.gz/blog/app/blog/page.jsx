import Link from 'next/link'
import { readdir } from 'fs/promises'
import { parse } from 'path'

async function getBlogPosts() {
  try {
    const files = await readdir('./posts')
    return files
      .filter(file => file.endsWith('.md') || file.endsWith('.txt'))
      .map(file => ({
        slug: parse(file).name,
        title: parse(file).name.replace(/-/g, ' ').charAt(0).toUpperCase() + parse(file).name.replace(/-/g, ' ').slice(1),
      }))
  } catch {
    return []
  }
}

export default async function BlogPage() {
  const posts = await getBlogPosts()

  return (
    <div className="blog-list">
      <h1>Blog Posts</h1>
      {posts.length > 0 ? (
        <ul className="posts">
          {posts.map(post => (
            <li key={post.slug}>
              <Link href={`/blog/${post.slug}`}>
                <h2>{post.title}</h2>
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <p>No blog posts yet. Check back soon!</p>
      )}
    </div>
  )
}
