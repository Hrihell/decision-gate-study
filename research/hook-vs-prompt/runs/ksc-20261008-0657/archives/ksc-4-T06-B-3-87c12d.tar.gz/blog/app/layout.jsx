import './globals.css'

export const metadata = {
  title: 'My Blog',
  description: 'A simple blog built with Next.js',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <nav className="navbar">
          <div className="container">
            <h1><a href="/">My Blog</a></h1>
            <ul>
              <li><a href="/">Home</a></li>
              <li><a href="/blog">Blog</a></li>
            </ul>
          </div>
        </nav>
        <main className="container">
          {children}
        </main>
        <footer>
          <p>&copy; 2026 My Blog. All rights reserved.</p>
        </footer>
      </body>
    </html>
  )
}
