Welcome to my blog! This is the first post.

I'm excited to share my thoughts and experiences with you through this blog. I'll be writing about web development, Next.js, and other topics that interest me.

Stay tuned for more posts coming soon!