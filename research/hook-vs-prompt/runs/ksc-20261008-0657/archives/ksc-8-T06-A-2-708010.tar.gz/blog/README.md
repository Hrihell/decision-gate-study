# Next.js 블로그

Next.js, TypeScript, Tailwind CSS로 만든 간단하고 효율적인 블로그입니다.

## 기능

- 📝 Markdown 포맷 지원
- ⚡ Next.js App Router 사용
- 🎨 Tailwind CSS로 스타일링
- 📱 반응형 레이아웃
- 🔍 SEO 최적화
- 🌙 깔끔한 디자인

## 설치

```bash
npm install
```

## 개발 서버 실행

```bash
npm run dev
```

`http://localhost:3000`에서 블로그를 확인할 수 있습니다.

## 블로그 글 작성

### 1. 새 파일 생성

`posts/` 디렉토리에 `.md` 확장자로 새 파일을 생성합니다.

```bash
posts/my-first-post.md
```

### 2. Front Matter 작성

파일의 맨 앞에 YAML 형식의 메타데이터를 작성합니다.

```markdown
---
title: "글의 제목"
date: "2026-10-08"
excerpt: "글의 요약 설명"
---
```

### 3. Markdown 내용 작성

메타데이터 아래에 Markdown 형식으로 내용을 작성합니다.

```markdown
---
title: "My First Post"
date: "2026-10-08"
excerpt: "This is my first blog post"
---

# 제목

본문 내용입니다.

- 리스트 항목 1
- 리스트 항목 2

**굵은 글씨**와 *기울인 글씨*도 사용할 수 있습니다.
```

## 파일 구조

```
blog/
├── app/                    # Next.js App Router
│   ├── layout.tsx         # 루트 레이아웃
│   ├── page.tsx           # 홈페이지
│   ├── globals.css        # 전역 스타일
│   ├── blog/
│   │   ├── page.tsx       # 블로그 목록 페이지
│   │   └── [slug]/
│   │       └── page.tsx   # 개별 글 페이지
│   └── not-found.tsx      # 404 페이지
├── components/             # React 컴포넌트
│   ├── PostCard.tsx       # 글 카드
│   └── PostContent.tsx    # 글 내용
├── lib/                    # 유틸리티
│   └── posts.ts           # 글 데이터 처리
├── posts/                  # 블로그 글 (Markdown)
│   ├── hello-world.md
│   ├── next-js-guide.md
│   └── markdown-syntax.md
└── package.json            # 프로젝트 설정
```

## 빌드

```bash
npm run build
```

## 배포

Vercel에 배포하는 것이 가장 쉽습니다:

```bash
vercel
```

또는 다른 호스팅 서비스에 배포할 수 있습니다:

```bash
npm run build
npm run start
```

## 커스터마이징

### 블로그 제목 및 설명 변경

`app/layout.tsx`에서 메타데이터를 수정합니다.

### 스타일 변경

`app/globals.css`와 `tailwind.config.js`에서 커스터마이징할 수 있습니다.

### 헤더 및 네비게이션

`app/layout.tsx`의 `<header>` 섹션을 수정합니다.

## 라이선스

MIT
