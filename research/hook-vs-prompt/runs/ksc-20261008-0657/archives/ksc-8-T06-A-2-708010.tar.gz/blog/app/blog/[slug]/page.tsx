import Link from 'next/link'
import { getPostBySlug, getSlugs } from '@/lib/posts'
import PostContent from '@/components/PostContent'
import { notFound } from 'next/navigation'

interface Params {
  slug: string
}

export async function generateStaticParams() {
  const slugs = getSlugs()
  return slugs.map(slug => ({ slug }))
}

export function generateMetadata({ params }: { params: Params }) {
  const post = getPostBySlug(params.slug)
  if (!post) {
    return { title: '글을 찾을 수 없습니다' }
  }
  return {
    title: `${post.title} | 나의 블로그`,
    description: post.excerpt,
  }
}

export default function PostPage({ params }: { params: Params }) {
  const post = getPostBySlug(params.slug)

  if (!post) {
    notFound()
  }

  return (
    <article>
      <div className="mb-8">
        <Link href="/blog" className="text-blue-600 hover:text-blue-800 mb-4 inline-block">
          ← 돌아가기
        </Link>
        <h1 className="text-4xl font-bold mb-2 text-gray-900">{post.title}</h1>
        <p className="text-gray-500">{post.date}</p>
      </div>

      <div className="prose prose-sm md:prose-base max-w-none mb-12">
        <PostContent content={post.content} />
      </div>
    </article>
  )
}
