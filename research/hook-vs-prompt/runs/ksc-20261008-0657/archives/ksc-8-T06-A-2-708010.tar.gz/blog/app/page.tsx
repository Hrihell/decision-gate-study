import Link from 'next/link'
import { getAllPosts } from '@/lib/posts'
import PostCard from '@/components/PostCard'

export default function Home() {
  const posts = getAllPosts().slice(0, 3)

  return (
    <div>
      <section className="mb-12">
        <h1 className="text-4xl font-bold mb-4 text-gray-900">환영합니다!</h1>
        <p className="text-xl text-gray-600 mb-8">
          이곳은 Next.js로 만든 블로그입니다. 최신 글들을 아래에서 확인하세요.
        </p>
      </section>

      <section className="mb-12">
        <h2 className="text-3xl font-bold mb-8 text-gray-900">최신 글</h2>
        <div className="grid gap-6">
          {posts.map(post => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      </section>

      <section className="text-center">
        <Link
          href="/blog"
          className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition-colors"
        >
          모든 글 보기
        </Link>
      </section>
    </div>
  )
}
