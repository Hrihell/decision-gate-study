import { getAllPosts } from '@/lib/posts'
import PostCard from '@/components/PostCard'

export const metadata = {
  title: '모든 글 | 나의 블로그',
  description: '블로그의 모든 글 목록',
}

export default function BlogPage() {
  const posts = getAllPosts()

  return (
    <div>
      <h1 className="text-4xl font-bold mb-2 text-gray-900">모든 글</h1>
      <p className="text-gray-600 mb-8">총 {posts.length}개의 글</p>

      {posts.length === 0 ? (
        <p className="text-gray-500 text-center py-12">아직 글이 없습니다.</p>
      ) : (
        <div className="grid gap-6">
          {posts.map(post => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      )}
    </div>
  )
}
