import Link from 'next/link'
import { PostMeta } from '@/lib/posts'

interface PostCardProps {
  post: PostMeta
}

export default function PostCard({ post }: PostCardProps) {
  return (
    <article className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
      <Link href={`/blog/${post.slug}`}>
        <h2 className="text-2xl font-bold mb-2 text-blue-600 hover:text-blue-800">
          {post.title}
        </h2>
      </Link>
      <p className="text-gray-500 text-sm mb-4">{post.date}</p>
      <p className="text-gray-700">{post.excerpt}</p>
      <Link href={`/blog/${post.slug}`} className="text-blue-600 hover:text-blue-800 mt-4 inline-block">
        더보기 →
      </Link>
    </article>
  )
}
