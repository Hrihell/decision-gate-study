'use client'

import { useEffect, useState } from 'react'
import { marked } from 'marked'

interface PostContentProps {
  content: string
}

export default function PostContent({ content }: PostContentProps) {
  const [html, setHtml] = useState('')

  useEffect(() => {
    const parseMarkdown = async () => {
      const result = await marked(content)
      setHtml(result as string)
    }
    parseMarkdown()
  }, [content])

  return (
    <div
      className="prose prose-sm max-w-none md:prose-base"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  )
}
