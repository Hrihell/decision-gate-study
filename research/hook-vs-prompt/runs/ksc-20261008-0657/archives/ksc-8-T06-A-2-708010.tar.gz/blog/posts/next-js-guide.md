---
title: "Next.js 13+ App Router 완벽 가이드"
date: "2026-10-07"
excerpt: "Next.js의 최신 App Router를 활용한 프로젝트 구성 방법을 알아봅시다."
---

# Next.js 13+ App Router 완벽 가이드

Next.js 13부터 도입된 **App Router**는 기존의 Pages Router를 대체하면서 더욱 강력한 기능을 제공합니다.

## App Router의 장점

### 1. 파일 기반 라우팅
```
app/
├── page.tsx           # /
├── blog/
│   ├── page.tsx       # /blog
│   └── [slug]/
│       └── page.tsx   # /blog/[slug]
```

### 2. 레이아웃 시스템
레이아웃은 여러 페이지에서 공유되는 UI를 정의합니다:

```typescript
export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  )
}
```

### 3. Server Components
기본적으로 Server Component를 사용하여 성능을 최적화합니다.

### 4. Client Components
`'use client'` directive를 사용하여 Client Component로 변경할 수 있습니다.

## 실전 팁

- 데이터 페칭은 Server Component에서 수행
- 상태 관리가 필요하면 Client Component 사용
- `generateStaticParams`로 동적 라우트 사전 생성
- `generateMetadata`로 동적 메타데이터 생성

이제 Next.js로 더욱 강력한 웹 애플리케이션을 만들 수 있습니다! 🚀
