---
title: "Next.js 블로그에 오신 것을 환영합니다"
date: "2026-10-08"
excerpt: "Next.js와 Markdown으로 만든 간단하고 효율적인 블로그입니다."
---

안녕하세요! 👋

이곳은 **Next.js**와 **Markdown**으로 만든 블로그입니다.

## 주요 기능

- 📝 Markdown으로 글 작성
- ⚡ 빠른 로딩 속도 (Next.js)
- 🎨 깔끔한 디자인 (Tailwind CSS)
- 📱 반응형 레이아웃
- 🔍 SEO 최적화

## 시작하기

새로운 글을 추가하려면:

1. `posts/` 디렉토리에 `.md` 파일 추가
2. Front matter로 메타데이터 작성
3. Markdown 형식으로 내용 작성

```markdown
---
title: "글 제목"
date: "2026-10-08"
excerpt: "글 설명"
---

글 내용...
```

이제 블로그를 즐겨보세요! 🚀
