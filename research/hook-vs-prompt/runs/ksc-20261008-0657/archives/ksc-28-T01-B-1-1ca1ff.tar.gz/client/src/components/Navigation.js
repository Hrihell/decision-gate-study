import React from 'react';
import { Link } from 'react-router-dom';
import './Navigation.css';

function Navigation({ user, onLogout }) {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-brand">📚 동아리 책 공유</Link>
        <ul className="nav-links">
          <li><Link to="/">전체 책</Link></li>
          {user ? (
            <>
              <li><Link to="/register-book">책 등록</Link></li>
              <li><Link to="/profile">프로필</Link></li>
              <li><button onClick={onLogout} className="logout-btn">로그아웃</button></li>
            </>
          ) : (
            <li><button className="login-btn">로그인</button></li>
          )}
        </ul>
      </div>
    </nav>
  );
}

export default Navigation;
