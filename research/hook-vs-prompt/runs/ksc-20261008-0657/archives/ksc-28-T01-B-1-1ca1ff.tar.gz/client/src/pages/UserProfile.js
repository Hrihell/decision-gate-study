import React, { useState, useEffect } from 'react';
import './UserProfile.css';

function UserProfile({ user }) {
  const [myBooks, setMyBooks] = useState([]);
  const [rentedBooks, setRentedBooks] = useState([]);

  useEffect(() => {
    // TODO: API에서 사용자의 책과 대여한 책 불러오기
    setMyBooks([
      { id: 1, title: '책 제목 1', author: '저자 1', available: true },
      { id: 2, title: '책 제목 2', author: '저자 2', available: false }
    ]);

    setRentedBooks([
      { id: 3, title: '대여한 책 1', author: '저자 3', owner: '홍길동', returnDate: '2024-01-20' }
    ]);
  }, [user]);

  return (
    <div className="profile">
      <h1>👤 프로필</h1>

      <div className="profile-info">
        <h2>사용자 정보</h2>
        <p><strong>이름:</strong> {user?.name}</p>
        <p><strong>이메일:</strong> {user?.email}</p>
      </div>

      <div className="my-books">
        <h2>📚 내 책 ({myBooks.length})</h2>
        <div className="books-list">
          {myBooks.map(book => (
            <div key={book.id} className="book-item">
              <h3>{book.title}</h3>
              <p><strong>저자:</strong> {book.author}</p>
              <span className={`status ${book.available ? 'available' : 'rented'}`}>
                {book.available ? '대여 가능' : '대여 중'}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="rented-books">
        <h2>🔄 대여한 책 ({rentedBooks.length})</h2>
        <div className="books-list">
          {rentedBooks.map(book => (
            <div key={book.id} className="book-item">
              <h3>{book.title}</h3>
              <p><strong>저자:</strong> {book.author}</p>
              <p><strong>소유자:</strong> {book.owner}</p>
              <p><strong>반납 예정일:</strong> {book.returnDate}</p>
              <button>반납하기</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default UserProfile;
