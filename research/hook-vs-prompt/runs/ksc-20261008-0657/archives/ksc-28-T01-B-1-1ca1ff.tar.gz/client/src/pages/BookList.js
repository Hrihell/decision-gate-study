import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './BookList.css';

function BookList() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get('/api/books');
      setBooks(response.data);
      setLoading(false);
    } catch (err) {
      setError('책 목록을 불러올 수 없습니다.');
      setLoading(false);
    }
  };

  const handleRent = async (bookId) => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
      alert('로그인이 필요합니다.');
      return;
    }

    try {
      await axios.post('/api/rentals', {
        book_id: bookId,
        borrower_id: user.id
      });
      alert('대여 신청이 완료되었습니다!');
    } catch (err) {
      alert('대여 신청에 실패했습니다.');
    }
  };

  if (loading) return <div>로딩 중...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="book-list">
      <h1>📚 책 목록</h1>
      <div className="books-grid">
        {books.map(book => (
          <div key={book.id} className="book-card">
            <h3>{book.title}</h3>
            <p><strong>저자:</strong> {book.author}</p>
            <p><strong>소유자:</strong> {book.owner_name}</p>
            <p><strong>상태:</strong> {book.condition}</p>
            <button onClick={() => handleRent(book.id)}>대여 신청</button>
          </div>
        ))}
      </div>
      {books.length === 0 && <p>등록된 책이 없습니다.</p>}
    </div>
  );
}

export default BookList;
