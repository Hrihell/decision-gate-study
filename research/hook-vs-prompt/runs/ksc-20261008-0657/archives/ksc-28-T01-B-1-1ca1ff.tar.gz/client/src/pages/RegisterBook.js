import React, { useState } from 'react';
import axios from 'axios';
import './RegisterBook.css';

function RegisterBook({ userId }) {
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    condition: 'good'
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      await axios.post('/api/books', {
        ...formData,
        owner_id: userId
      });
      setMessage('책이 등록되었습니다!');
      setFormData({ title: '', author: '', condition: 'good' });
    } catch (err) {
      setMessage('책 등록에 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register-book">
      <h1>📖 새 책 등록</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">책 제목 *</label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="author">저자</label>
          <input
            type="text"
            id="author"
            name="author"
            value={formData.author}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="condition">책 상태</label>
          <select
            id="condition"
            name="condition"
            value={formData.condition}
            onChange={handleChange}
          >
            <option value="excellent">매우 좋음</option>
            <option value="good">좋음</option>
            <option value="fair">보통</option>
            <option value="poor">나쁨</option>
          </select>
        </div>

        <button type="submit" disabled={loading}>
          {loading ? '등록 중...' : '책 등록하기'}
        </button>
      </form>
      {message && <p className="message">{message}</p>}
    </div>
  );
}

export default RegisterBook;
