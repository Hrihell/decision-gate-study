import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import axios from 'axios';
import BookList from './pages/BookList';
import RegisterBook from './pages/RegisterBook';
import UserProfile from './pages/UserProfile';
import Navigation from './components/Navigation';
import './App.css';

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <Router>
      <div className="App">
        <Navigation user={user} onLogout={handleLogout} />
        <main className="container">
          <Routes>
            <Route path="/" element={<BookList />} />
            <Route path="/register-book" element={user ? <RegisterBook userId={user.id} /> : <div>로그인이 필요합니다</div>} />
            <Route path="/profile" element={user ? <UserProfile user={user} /> : <div>로그인이 필요합니다</div>} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
