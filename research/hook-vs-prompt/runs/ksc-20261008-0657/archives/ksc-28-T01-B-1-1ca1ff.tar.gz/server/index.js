const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://localhost/book_sharing'
});

// 책 목록 조회
app.get('/api/books', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT b.*, u.name as owner_name FROM books b JOIN users u ON b.owner_id = u.id'
    );
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 책 등록
app.post('/api/books', async (req, res) => {
  const { title, author, owner_id, condition } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO books (title, author, owner_id, condition) VALUES ($1, $2, $3, $4) RETURNING *',
      [title, author, owner_id, condition]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 대여 신청
app.post('/api/rentals', async (req, res) => {
  const { book_id, borrower_id } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO rentals (book_id, borrower_id, rental_date) VALUES ($1, $2, NOW()) RETURNING *',
      [book_id, borrower_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 반납
app.patch('/api/rentals/:id/return', async (req, res) => {
  try {
    const result = await pool.query(
      'UPDATE rentals SET return_date = NOW() WHERE id = $1 RETURNING *',
      [req.params.id]
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 사용자 가입
app.post('/api/users', async (req, res) => {
  const { name, email } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO users (name, email) VALUES ($1, $2) RETURNING *',
      [name, email]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
