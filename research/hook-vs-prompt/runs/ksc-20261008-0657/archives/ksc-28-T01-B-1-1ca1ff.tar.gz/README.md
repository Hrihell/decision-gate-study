# 동아리 책 공유 사이트

동아리 회원들이 중고 책을 서로 빌려주는 웹사이트입니다.

## 기술 스택

- **Frontend**: React + TypeScript
- **Backend**: Node.js + Express
- **Database**: PostgreSQL

## 프로젝트 구조

```
.
├── server/          # 백엔드 서버
│   ├── index.js     # Express 앱
│   ├── schema.sql   # 데이터베이스 스키마
│   └── package.json
├── client/          # React 프론트엔드
│   ├── public/
│   ├── src/
│   │   ├── components/  # React 컴포넌트
│   │   ├── pages/      # 페이지 컴포넌트
│   │   ├── App.js
│   │   └── index.js
│   └── package.json
└── README.md
```

## 설치 및 실행

### 1. 의존성 설치

```bash
npm install
cd server && npm install && cd ..
cd client && npm install && cd ..
```

### 2. 데이터베이스 설정

PostgreSQL이 설치되어 있어야 합니다.

```bash
# 데이터베이스 생성
createdb book_sharing

# 스키마 초기화
psql book_sharing < server/schema.sql
```

### 3. 환경 변수 설정

```bash
cd server
cp .env.example .env
# .env 파일에서 DATABASE_URL 설정
```

### 4. 개발 서버 실행

```bash
npm run dev
```

- 프론트엔드: http://localhost:3000
- 백엔드: http://localhost:5000

## 주요 기능

- 📚 책 등록 및 조회
- 🔄 책 대여/반납 신청
- 👤 사용자 프로필 관리
- 📖 보유 책 목록 관리

## API 엔드포인트

- `GET /api/books` - 모든 책 조회
- `POST /api/books` - 책 등록
- `POST /api/rentals` - 대여 신청
- `PATCH /api/rentals/:id/return` - 반납
- `POST /api/users` - 사용자 가입

## 개발 상태

- ✅ 프로젝트 구조 초기 설정
- ⚠️ 인증 기능 구현 필요
- ⚠️ API 완성도 높이기
- ⚠️ 프론트엔드 UI 개선
