const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';

function getTodosKey(username) {
  return `todos_${username}`;
}

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function setCurrentUser(username) {
  localStorage.setItem(CURRENT_USER_KEY, username || '');
}

function loadTodos(username) {
  return JSON.parse(localStorage.getItem(getTodosKey(username)) || '[]');
}

function saveTodos(username, todos) {
  localStorage.setItem(getTodosKey(username), JSON.stringify(todos));
}

function showAuthScreen() {
  document.getElementById('auth-screen').style.display = 'block';
  document.getElementById('app-screen').style.display = 'none';
  document.getElementById('login-form').style.display = 'block';
  document.getElementById('signup-form').style.display = 'none';
}

function showAppScreen(username) {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('app-screen').style.display = 'block';
  document.getElementById('username-display').textContent = username;
  render(loadTodos(username));
}

function render(todos) {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const username = getCurrentUser();
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(username, next);
      render(next);
    });
    list.appendChild(item);
  });
}

function clearError(elementId) {
  document.getElementById(elementId).textContent = '';
}

function setError(elementId, message) {
  document.getElementById(elementId).textContent = message;
}

// 회원가입
document.getElementById('signup-btn').addEventListener('click', () => {
  const username = document.getElementById('signup-username').value.trim();
  const password = document.getElementById('signup-password').value;
  const passwordConfirm = document.getElementById('signup-password-confirm').value;

  clearError('signup-error');

  if (!username) {
    setError('signup-error', '사용자명을 입력해 주세요');
    return;
  }

  if (username.length < 2) {
    setError('signup-error', '사용자명은 2글자 이상이어야 합니다');
    return;
  }

  if (!password) {
    setError('signup-error', '비밀번호를 입력해 주세요');
    return;
  }

  if (password.length < 4) {
    setError('signup-error', '비밀번호는 4글자 이상이어야 합니다');
    return;
  }

  if (password !== passwordConfirm) {
    setError('signup-error', '비밀번호가 일치하지 않습니다');
    return;
  }

  const users = getUsers();
  if (users[username]) {
    setError('signup-error', '이미 존재하는 사용자명입니다');
    return;
  }

  users[username] = { password, createdAt: new Date().toISOString() };
  saveUsers(users);

  document.getElementById('signup-username').value = '';
  document.getElementById('signup-password').value = '';
  document.getElementById('signup-password-confirm').value = '';

  setCurrentUser(username);
  showAppScreen(username);
});

// 로그인
document.getElementById('login-btn').addEventListener('click', () => {
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;

  clearError('login-error');

  if (!username || !password) {
    setError('login-error', '사용자명과 비밀번호를 입력해 주세요');
    return;
  }

  const users = getUsers();
  const user = users[username];

  if (!user || user.password !== password) {
    setError('login-error', '사용자명 또는 비밀번호가 올바르지 않습니다');
    return;
  }

  document.getElementById('login-username').value = '';
  document.getElementById('login-password').value = '';

  setCurrentUser(username);
  showAppScreen(username);
});

// 회원가입 화면으로
document.getElementById('to-signup').addEventListener('click', (e) => {
  e.preventDefault();
  clearError('signup-error');
  clearError('login-error');
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('signup-form').style.display = 'block';
});

// 로그인 화면으로
document.getElementById('to-login').addEventListener('click', (e) => {
  e.preventDefault();
  clearError('signup-error');
  clearError('login-error');
  document.getElementById('login-form').style.display = 'block';
  document.getElementById('signup-form').style.display = 'none';
});

// 로그아웃
document.getElementById('logout-btn').addEventListener('click', () => {
  setCurrentUser(null);
  showAuthScreen();
});

// 할 일 추가
document.getElementById('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = document.getElementById('new-todo');
  if (input.value.trim() === '') return;
  const username = getCurrentUser();
  const todos = loadTodos(username);
  const next = [...todos, { text: input.value.trim(), done: false }];
  saveTodos(username, next);
  render(next);
  input.value = '';
});

// 초기화
if (getCurrentUser()) {
  showAppScreen(getCurrentUser());
} else {
  showAuthScreen();
}
