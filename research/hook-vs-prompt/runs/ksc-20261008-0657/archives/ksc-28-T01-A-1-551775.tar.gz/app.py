from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///books.db'
app.config['SECRET_KEY'] = 'dev-secret-key'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    books = db.relationship('Book', backref='owner', lazy=True)
    borrowed_books = db.relationship('Borrow', backref='user', lazy=True)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(20), default='available')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    borrows = db.relationship('Borrow', backref='book', lazy=True)

class Borrow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    borrowed_at = db.Column(db.DateTime, default=datetime.utcnow)
    returned_at = db.Column(db.DateTime, nullable=True)
    due_at = db.Column(db.DateTime, default=lambda: datetime.utcnow() + timedelta(days=14))

@app.route('/')
def index():
    books = Book.query.filter_by(status='available').all()
    users = User.query.all()
    return render_template('index.html', books=books, users=users)

@app.route('/add-book', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form.get('email')).first()
        if not user:
            user = User(name=request.form.get('name'), email=request.form.get('email'))
            db.session.add(user)
            db.session.commit()

        book = Book(
            title=request.form.get('title'),
            author=request.form.get('author'),
            owner_id=user.id
        )
        db.session.add(book)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_book.html')

@app.route('/borrow/<int:book_id>', methods=['POST'])
def borrow_book(book_id):
    book = Book.query.get_or_404(book_id)
    email = request.form.get('email')

    user = User.query.filter_by(email=email).first()
    if not user:
        user = User(name=email.split('@')[0], email=email)
        db.session.add(user)
        db.session.commit()

    borrow = Borrow(book_id=book_id, user_id=user.id)
    book.status = 'borrowed'
    db.session.add(borrow)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/return/<int:borrow_id>', methods=['POST'])
def return_book(borrow_id):
    borrow = Borrow.query.get_or_404(borrow_id)
    borrow.returned_at = datetime.utcnow()
    borrow.book.status = 'available'
    db.session.commit()
    return redirect(url_for('my_books'))

@app.route('/my-books')
def my_books():
    email = request.args.get('email')
    user = User.query.filter_by(email=email).first() if email else None
    if not user:
        return render_template('my_books.html', user=None, owned_books=[], borrowed_books=[])

    owned_books = Book.query.filter_by(owner_id=user.id).all()
    borrowed_books = Borrow.query.filter_by(user_id=user.id, returned_at=None).all()
    return render_template('my_books.html', user=user, owned_books=owned_books, borrowed_books=borrowed_books)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
