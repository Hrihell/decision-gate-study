# 책 빌려주는 사이트

## 기술 스택
- Backend: Python Flask
- Database: SQLite
- Frontend: HTML/CSS/Jinja2

## 기능
1. 회원가입/로그인
2. 책 등록 (제목, 저자)
3. 책 목록 조회 (빌릴 수 있는 책)
4. 책 빌리기/반납
5. 내 책 관리
6. 빌린 책 조회

## 구조
- app.py: Flask 메인 앱
- templates/: HTML 템플릿
- books.db: SQLite 데이터베이스
