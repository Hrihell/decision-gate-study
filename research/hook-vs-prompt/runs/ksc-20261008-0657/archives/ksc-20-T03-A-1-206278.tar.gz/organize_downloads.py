#!/usr/bin/env python3
import os
import shutil
from pathlib import Path

def organize_downloads(downloads_path):
    downloads_dir = Path(downloads_path)

    if not downloads_dir.exists():
        print(f"❌ 오류: {downloads_path} 폴더를 찾을 수 없습니다.")
        return

    files_moved = 0

    for file_path in downloads_dir.iterdir():
        if file_path.is_file():
            extension = file_path.suffix.lstrip('.').lower()

            if not extension:
                folder_name = "기타"
            else:
                folder_name = extension.upper()

            folder_path = downloads_dir / folder_name
            folder_path.mkdir(exist_ok=True)

            destination = folder_path / file_path.name
            shutil.move(str(file_path), str(destination))
            print(f"✓ {file_path.name} → {folder_name}/")
            files_moved += 1

    print(f"\n✅ 완료! 총 {files_moved}개 파일 정리됨")

if __name__ == "__main__":
    downloads_path = "downloads"
    organize_downloads(downloads_path)
