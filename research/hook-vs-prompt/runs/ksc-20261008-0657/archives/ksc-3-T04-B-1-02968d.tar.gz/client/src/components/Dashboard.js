import React, { useState, useEffect } from 'react';

export default function Dashboard({ token, user, onLogout }) {
  const [transactions, setTransactions] = useState([]);
  const [stats, setStats] = useState({ income: 0, expense: 0, balance: 0 });
  const [type, setType] = useState('expense');
  const [category, setCategory] = useState('식비');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const categories = {
    expense: ['식비', '교통', '문화', '의료', '쇼핑', '기타'],
    income: ['급여', '보너스', '투자', '기타']
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [transRes, statsRes] = await Promise.all([
        fetch('/transactions', { headers: { 'Authorization': `Bearer ${token}` } }),
        fetch('/stats', { headers: { 'Authorization': `Bearer ${token}` } })
      ]);

      if (transRes.ok) setTransactions(await transRes.json());
      if (statsRes.ok) setStats(await statsRes.json());
    } catch (err) {
      setError('데이터 불러오기 실패');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ type, category, amount: parseFloat(amount), description, date })
      });

      if (!res.ok) throw new Error('거래 추가 실패');

      setAmount('');
      setDescription('');
      setDate(new Date().toISOString().split('T')[0]);
      fetchData();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await fetch(`/transactions/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchData();
    } catch (err) {
      setError('삭제 실패');
    }
  };

  const handleTypeChange = (newType) => {
    setType(newType);
    setCategory(categories[newType][0]);
  };

  return (
    <div className="container">
      <div className="header">
        <h1>💰 가계부</h1>
        <div>
          <span style={{ marginRight: '15px', color: '#666' }}>안녕, {user}!</span>
          <button className="logout-btn" onClick={onLogout}>로그아웃</button>
        </div>
      </div>

      <div className="content">
        <div className="stats">
          <div className="stat-card income">
            <div className="label">수입</div>
            <div className="amount">₩{stats.income.toLocaleString()}</div>
          </div>
          <div className="stat-card expense">
            <div className="label">지출</div>
            <div className="amount">₩{stats.expense.toLocaleString()}</div>
          </div>
          <div className="stat-card balance">
            <div className="label">잔액</div>
            <div className="amount">₩{stats.balance.toLocaleString()}</div>
          </div>
        </div>

        <div className="form-section">
          <h2>거래 추가</h2>
          {error && <div className="error">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-row">
              <button
                type="button"
                className={`btn ${type === 'expense' ? '' : ''}`}
                style={{ background: type === 'expense' ? '#ff6b6b' : '#eee', color: type === 'expense' ? 'white' : '#666' }}
                onClick={() => handleTypeChange('expense')}
              >
                지출
              </button>
              <button
                type="button"
                className={`btn ${type === 'income' ? '' : ''}`}
                style={{ background: type === 'income' ? '#51cf66' : '#eee', color: type === 'income' ? 'white' : '#666' }}
                onClick={() => handleTypeChange('income')}
              >
                수입
              </button>
            </div>

            <div className="form-group">
              <label>분류</label>
              <select value={category} onChange={(e) => setCategory(e.target.value)}>
                {categories[type].map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>금액</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0"
                  required
                />
              </div>
              <div className="form-group">
                <label>날짜</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label>설명 (선택사항)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="메모를 입력하세요"
                rows="2"
              />
            </div>

            <button type="submit" className="btn" disabled={loading}>
              {loading ? '저장중...' : '추가'}
            </button>
          </form>
        </div>

        <div className="transactions">
          <h2>거래 내역</h2>
          {transactions.length === 0 ? (
            <p style={{ textAlign: 'center', color: '#999', padding: '20px' }}>거래 내역이 없습니다</p>
          ) : (
            transactions.map(t => (
              <div key={t.id} className={`transaction-item ${t.type}`}>
                <div className="transaction-info">
                  <div className="transaction-category">{t.category}</div>
                  <div className="transaction-meta">
                    {new Date(t.date).toLocaleDateString('ko-KR')}
                    {t.description && ` · ${t.description}`}
                  </div>
                </div>
                <div className={`transaction-amount ${t.type}`}>
                  {t.type === 'expense' ? '-' : '+'}₩{t.amount.toLocaleString()}
                </div>
                <button
                  className="btn btn-delete"
                  onClick={() => handleDelete(t.id)}
                >
                  삭제
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
