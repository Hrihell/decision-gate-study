import React, { useState, useEffect } from 'react';
import './App.css';
import AuthForm from './components/AuthForm';
import Dashboard from './components/Dashboard';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(localStorage.getItem('username'));

  useEffect(() => {
    if (token) localStorage.setItem('token', token);
    if (user) localStorage.setItem('username', user);
  }, [token, user]);

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('username');
  };

  return (
    <div className="app">
      {token ? (
        <Dashboard token={token} user={user} onLogout={handleLogout} />
      ) : (
        <AuthForm onAuth={(token, username) => {
          setToken(token);
          setUser(username);
        }} />
      )}
    </div>
  );
}
