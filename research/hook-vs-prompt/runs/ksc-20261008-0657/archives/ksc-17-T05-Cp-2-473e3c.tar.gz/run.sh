#!/bin/bash
echo "할 일 목록 앱을 시작합니다..."
echo "브라우저에서 http://localhost:8000 을 열어주세요"
python3 -m http.server 8000
