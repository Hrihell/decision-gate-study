import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    loadTodos();
  }, []);

  useEffect(() => {
    saveTodos(todos);
  }, [todos]);

  const loadTodos = async () => {
    try {
      const data = await window.electron.getTodos();
      setTodos(data || []);
    } catch (err) {
      console.error('할 일 로드 실패:', err);
    }
  };

  const saveTodos = async (data) => {
    try {
      await window.electron.saveTodos(data);
    } catch (err) {
      console.error('할 일 저장 실패:', err);
    }
  };

  const addTodo = () => {
    if (input.trim()) {
      const newTodo = {
        id: Date.now(),
        text: input.trim(),
        completed: false,
        createdAt: new Date().toLocaleString('ko-KR')
      };
      setTodos([newTodo, ...todos]);
      setInput('');
    }
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const toggleTodo = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      addTodo();
    }
  };

  const completedCount = todos.filter(t => t.completed).length;

  return (
    <div className="app">
      <div className="container">
        <div className="header">
          <h1>📝 할 일 목록</h1>
          <div className="stats">
            {todos.length > 0 && (
              <span className="stat-text">
                {completedCount}/{todos.length} 완료
              </span>
            )}
          </div>
        </div>

        <div className="input-group">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="새로운 할 일을 입력하세요..."
            className="input"
          />
          <button onClick={addTodo} className="btn-add">
            추가
          </button>
        </div>

        <div className="todo-list">
          {todos.length === 0 ? (
            <div className="empty-state">
              <p>할 일이 없습니다</p>
              <p className="empty-hint">위에서 새로운 할 일을 추가해보세요!</p>
            </div>
          ) : (
            todos.map(todo => (
              <div
                key={todo.id}
                className={`todo-item ${todo.completed ? 'completed' : ''}`}
              >
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => toggleTodo(todo.id)}
                  className="checkbox"
                />
                <div className="todo-content">
                  <span className="todo-text">{todo.text}</span>
                  <span className="todo-date">{todo.createdAt}</span>
                </div>
                <button
                  onClick={() => deleteTodo(todo.id)}
                  className="btn-delete"
                >
                  ✕
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
