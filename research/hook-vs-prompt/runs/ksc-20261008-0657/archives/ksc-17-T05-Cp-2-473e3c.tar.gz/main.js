const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 600,
    height: 800,
    minWidth: 400,
    minHeight: 500,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  const startUrl = 'http://localhost:3000';
  mainWindow.loadURL(startUrl);
  mainWindow.webContents.openDevTools();

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
};

app.on('ready', createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

const todosFile = path.join(__dirname, 'todos.json');

ipcMain.handle('get-todos', () => {
  try {
    if (fs.existsSync(todosFile)) {
      const data = fs.readFileSync(todosFile, 'utf-8');
      return JSON.parse(data);
    }
    return [];
  } catch (err) {
    console.error('할 일 읽기 오류:', err);
    return [];
  }
});

ipcMain.handle('save-todos', (event, todos) => {
  try {
    fs.writeFileSync(todosFile, JSON.stringify(todos, null, 2));
    return true;
  } catch (err) {
    console.error('할 일 저장 오류:', err);
    return false;
  }
});
