import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api'
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const register = (username, password) =>
  API.post('/auth/register', { username, password });

export const login = (username, password) =>
  API.post('/auth/login', { username, password });

export const getExpenses = () =>
  API.get('/expenses');

export const createExpense = (type, category, amount, description, date) =>
  API.post('/expenses', { type, category, amount, description, date });

export const deleteExpense = (id) =>
  API.delete(`/expenses/${id}`);
