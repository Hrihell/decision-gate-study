import { useState } from 'react'
import { login, register } from './api'
import './Login.css'

export default function Login({ onLogin }) {
  const [isLogin, setIsLogin] = useState(true)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      if (isLogin) {
        const response = await login(username, password)
        localStorage.setItem('token', response.data.token)
        localStorage.setItem('username', response.data.user.username)
        onLogin(response.data.user.username)
      } else {
        await register(username, password)
        const loginResponse = await login(username, password)
        localStorage.setItem('token', loginResponse.data.token)
        localStorage.setItem('username', loginResponse.data.user.username)
        onLogin(loginResponse.data.user.username)
      }
    } catch (err) {
      setError(err.response?.data?.message || '오류가 발생했습니다')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>{isLogin ? '로그인' : '회원가입'}</h2>
        
        {error && <div className="error-message">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>사용자명</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="사용자명을 입력하세요"
              required
            />
          </div>

          <div className="form-group">
            <label>비밀번호</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="비밀번호를 입력하세요"
              required
            />
          </div>

          <button 
            type="submit" 
            className="submit-btn"
            disabled={loading}
          >
            {loading ? '진행 중...' : isLogin ? '로그인' : '회원가입'}
          </button>
        </form>

        <div className="toggle-mode">
          <span>
            {isLogin ? '계정이 없으신가요? ' : '이미 계정이 있으신가요? '}
            <button 
              type="button" 
              onClick={() => {
                setIsLogin(!isLogin)
                setError('')
              }}
              className="toggle-btn"
            >
              {isLogin ? '회원가입하기' : '로그인하기'}
            </button>
          </span>
        </div>
      </div>
    </div>
  )
}
