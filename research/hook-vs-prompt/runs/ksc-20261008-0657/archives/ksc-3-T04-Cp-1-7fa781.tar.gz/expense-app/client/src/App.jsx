import { useState, useEffect } from 'react'
import Login from './components/Login'
import Expenses from './components/Expenses'
import './App.css'

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    const username = localStorage.getItem('username')
    if (token && username) {
      setUser({ username })
    }
    setLoading(false)
  }, [])

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('username')
    setUser(null)
  }

  if (loading) return <div className="loading">로딩 중...</div>

  return (
    <div className="app">
      {!user ? (
        <Login onLogin={(username) => {
          setUser({ username })
        }} />
      ) : (
        <>
          <div className="header">
            <h1>💰 가계부</h1>
            <div className="user-info">
              <span>{user.username}님</span>
              <button onClick={handleLogout} className="logout-btn">로그아웃</button>
            </div>
          </div>
          <Expenses />
        </>
      )}
    </div>
  )
}

export default App
