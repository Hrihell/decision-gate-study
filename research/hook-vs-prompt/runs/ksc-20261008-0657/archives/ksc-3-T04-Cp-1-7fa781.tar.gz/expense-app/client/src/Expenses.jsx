import { useState, useEffect } from 'react'
import { getExpenses, createExpense, deleteExpense } from './api'
import './Expenses.css'

export default function Expenses() {
  const [expenses, setExpenses] = useState([])
  const [type, setType] = useState('지출')
  const [category, setCategory] = useState('식비')
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    loadExpenses()
  }, [])

  const loadExpenses = async () => {
    try {
      const response = await getExpenses()
      setExpenses(response.data)
    } catch (err) {
      console.error('Failed to load expenses:', err)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!amount) {
      setError('금액을 입력하세요')
      return
    }

    setLoading(true)
    try {
      await createExpense(type, category, parseFloat(amount), description, date)
      await loadExpenses()
      setAmount('')
      setDescription('')
      setDate(new Date().toISOString().split('T')[0])
      setError('')
    } catch (err) {
      setError('저장 실패: ' + (err.response?.data?.message || ''))
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id) => {
    if (confirm('정말 삭제하시겠습니까?')) {
      try {
        await deleteExpense(id)
        await loadExpenses()
      } catch (err) {
        alert('삭제 실패: ' + (err.response?.data?.message || ''))
      }
    }
  }

  const totalIncome = expenses
    .filter(e => e.type === '수입')
    .reduce((sum, e) => sum + e.amount, 0)

  const totalExpense = expenses
    .filter(e => e.type === '지출')
    .reduce((sum, e) => sum + e.amount, 0)

  const balance = totalIncome - totalExpense

  return (
    <div className="expenses-container">
      <div className="summary">
        <div className="summary-item income">
          <div className="summary-label">수입</div>
          <div className="summary-value">{totalIncome.toLocaleString()}원</div>
        </div>
        <div className="summary-item expense">
          <div className="summary-label">지출</div>
          <div className="summary-value">{totalExpense.toLocaleString()}원</div>
        </div>
        <div className="summary-item balance">
          <div className="summary-label">잔액</div>
          <div className="summary-value">{balance.toLocaleString()}원</div>
        </div>
      </div>

      <form className="add-expense-form" onSubmit={handleSubmit}>
        <h3>항목 추가</h3>
        {error && <div className="error-message">{error}</div>}
        
        <div className="form-row">
          <div className="form-group">
            <label>유형</label>
            <select value={type} onChange={(e) => setType(e.target.value)}>
              <option>수입</option>
              <option>지출</option>
            </select>
          </div>
          
          <div className="form-group">
            <label>카테고리</label>
            <select value={category} onChange={(e) => setCategory(e.target.value)}>
              <option>식비</option>
              <option>교통</option>
              <option>쇼핑</option>
              <option>엔터</option>
              <option>기타</option>
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>금액</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              min="0"
              step="100"
            />
          </div>
          
          <div className="form-group">
            <label>날짜</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>
        </div>

        <div className="form-group full-width">
          <label>설명</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="선택사항"
          />
        </div>

        <button type="submit" disabled={loading} className="add-btn">
          {loading ? '저장 중...' : '추가'}
        </button>
      </form>

      <div className="expenses-list">
        <h3>거래내역</h3>
        {expenses.length === 0 ? (
          <p className="empty">거래내역이 없습니다</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>날짜</th>
                <th>유형</th>
                <th>카테고리</th>
                <th>설명</th>
                <th>금액</th>
                <th>작업</th>
              </tr>
            </thead>
            <tbody>
              {expenses.map((expense) => (
                <tr key={expense.id} className={expense.type === '수입' ? 'income-row' : 'expense-row'}>
                  <td>{expense.date}</td>
                  <td>{expense.type}</td>
                  <td>{expense.category}</td>
                  <td>{expense.description || '-'}</td>
                  <td className="amount">
                    {expense.type === '수입' ? '+' : '-'}{expense.amount.toLocaleString()}원
                  </td>
                  <td>
                    <button 
                      className="delete-btn" 
                      onClick={() => handleDelete(expense.id)}
                    >
                      삭제
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
