import express from 'express';
import cors from 'cors';
import { initDB, getDB } from './db.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const app = express();
const PORT = 5000;
const JWT_SECRET = 'your-secret-key-change-in-production';

app.use(cors());
app.use(express.json());

const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token' });
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    res.status(403).json({ message: 'Invalid token' });
  }
};

app.post('/api/auth/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ message: 'Missing fields' });
  
  const hashedPassword = bcrypt.hashSync(password, 10);
  const db = getDB();
  
  db.run(
    'INSERT INTO users (username, password) VALUES (?, ?)',
    [username, hashedPassword],
    function(err) {
      if (err) return res.status(400).json({ message: 'Username already exists' });
      res.json({ id: this.lastID, username });
    }
  );
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ message: 'Missing fields' });
  
  const db = getDB();
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (err || !user) return res.status(401).json({ message: 'Invalid credentials' });
    
    if (!bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user.id, username: user.username } });
  });
});

app.post('/api/expenses', verifyToken, (req, res) => {
  const { type, category, amount, description, date } = req.body;
  const db = getDB();
  
  db.run(
    'INSERT INTO expenses (userId, type, category, amount, description, date) VALUES (?, ?, ?, ?, ?, ?)',
    [req.userId, type, category, amount, description, date],
    function(err) {
      if (err) return res.status(500).json({ message: 'Error creating expense' });
      res.json({ id: this.lastID, userId: req.userId, type, category, amount, description, date });
    }
  );
});

app.get('/api/expenses', verifyToken, (req, res) => {
  const db = getDB();
  db.all(
    'SELECT * FROM expenses WHERE userId = ? ORDER BY date DESC',
    [req.userId],
    (err, expenses) => {
      if (err) return res.status(500).json({ message: 'Error fetching expenses' });
      res.json(expenses);
    }
  );
});

app.delete('/api/expenses/:id', verifyToken, (req, res) => {
  const db = getDB();
  db.run(
    'DELETE FROM expenses WHERE id = ? AND userId = ?',
    [req.params.id, req.userId],
    function(err) {
      if (err) return res.status(500).json({ message: 'Error deleting expense' });
      res.json({ message: 'Expense deleted' });
    }
  );
});

async function startServer() {
  try {
    await initDB();
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

startServer();
