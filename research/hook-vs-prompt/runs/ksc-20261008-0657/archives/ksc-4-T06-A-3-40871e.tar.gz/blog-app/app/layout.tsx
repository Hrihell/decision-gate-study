import type { Metadata } from 'next'
import Link from 'next/link'
import './globals.css'

export const metadata: Metadata = {
  title: 'My Blog',
  description: 'A simple blog built with Next.js',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <header className="header">
          <nav className="navbar">
            <div className="container">
              <h1 className="logo"><Link href="/">My Blog</Link></h1>
              <ul className="nav-links">
                <li><Link href="/">Home</Link></li>
                <li><Link href="/blog">Blog</Link></li>
              </ul>
            </div>
          </nav>
        </header>
        <main className="container">
          {children}
        </main>
        <footer className="footer">
          <div className="container">
            <p>&copy; 2024 My Blog. All rights reserved.</p>
          </div>
        </footer>
      </body>
    </html>
  )
}
