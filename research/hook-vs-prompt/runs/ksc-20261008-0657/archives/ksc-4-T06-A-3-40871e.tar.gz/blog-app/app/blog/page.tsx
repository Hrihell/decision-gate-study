import Link from 'next/link'
import { getBlogPosts } from '@/lib/posts'

export const metadata = {
  title: 'Blog',
  description: 'Read my latest blog posts',
}

export default function BlogPage() {
  const posts = getBlogPosts()

  return (
    <div>
      <h1 style={{ marginBottom: '2rem', fontSize: '2rem', color: '#0070f3' }}>Blog Posts</h1>
      {posts.length === 0 ? (
        <p style={{ textAlign: 'center', color: '#999', padding: '2rem' }}>
          No blog posts yet. Check back soon!
        </p>
      ) : (
        <div className="blog-grid">
          {posts.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="blog-card"
            >
              <h2>{post.title}</h2>
              <p className="date">{post.date}</p>
              <p>{post.excerpt}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
