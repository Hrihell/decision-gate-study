import Link from 'next/link'
import { getBlogPosts } from '@/lib/posts'

export default function Home() {
  const posts = getBlogPosts()
  const recentPosts = posts.slice(0, 3)

  return (
    <div>
      <section className="hero">
        <h1>Welcome to My Blog</h1>
        <p>Thoughts, stories, and ideas about web development and technology</p>
        <Link href="/blog" style={{ fontSize: '1.1rem', color: '#0070f3', textDecoration: 'none' }}>
          View all posts →
        </Link>
      </section>

      <section>
        <h2 style={{ marginBottom: '2rem', fontSize: '1.8rem' }}>Recent Posts</h2>
        <div className="blog-grid">
          {recentPosts.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="blog-card"
            >
              <h2>{post.title}</h2>
              <p className="date">{post.date}</p>
              <p>{post.excerpt}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
