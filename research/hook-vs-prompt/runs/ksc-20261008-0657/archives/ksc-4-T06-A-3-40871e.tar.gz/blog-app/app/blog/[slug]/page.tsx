import Link from 'next/link'
import { getBlogPosts, getBlogPost } from '@/lib/posts'

export async function generateStaticParams() {
  const posts = getBlogPosts()
  return posts.map((post) => ({
    slug: post.slug,
  }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const post = getBlogPost(slug)

  if (!post) {
    return {
      title: 'Post not found',
    }
  }

  return {
    title: post.title,
    description: post.excerpt,
  }
}

export default async function BlogPost({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const post = getBlogPost(slug)

  if (!post) {
    return (
      <div>
        <Link href="/blog" className="back-link">← Back to Blog</Link>
        <div style={{ marginTop: '2rem', textAlign: 'center' }}>
          <h1>Post not found</h1>
          <p>The blog post you&rsquo;re looking for doesn&rsquo;t exist.</p>
        </div>
      </div>
    )
  }

  return (
    <div>
      <Link href="/blog" className="back-link">← Back to Blog</Link>
      <article className="blog-post">
        <h1>{post.title}</h1>
        <div className="meta">
          <time>{post.date}</time> • {post.author}
        </div>
        <div className="content" dangerouslySetInnerHTML={{ __html: post.content }} />
      </article>
    </div>
  )
}
