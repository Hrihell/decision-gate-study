1:"$Sreact.fragment"
2:I[2619,["619","static/chunks/619-ba102abea3e3d0e4.js","953","static/chunks/app/blog/%5Bslug%5D/page-616737adbedcfaf1.js"],""]
3:I[9766,[],""]
4:I[8924,[],""]
6:I[4431,[],"OutletBoundary"]
8:I[5278,[],"AsyncMetadataOutlet"]
a:I[4431,[],"ViewportBoundary"]
c:I[4431,[],"MetadataBoundary"]
d:"$Sreact.suspense"
f:I[7150,[],""]
:HL["/_next/static/css/2ee9d31541992b76.css","style"]
0:{"P":null,"b":"4QGJhLduN_cXcLK3bmNcC","p":"","c":["","blog","getting-started-with-nextjs"],"i":false,"f":[[["",{"children":["blog",{"children":[["slug","getting-started-with-nextjs","d"],{"children":["__PAGE__",{}]}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/2ee9d31541992b76.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":[["$","header",null,{"className":"header","children":["$","nav",null,{"className":"navbar","children":["$","div",null,{"className":"container","children":[["$","h1",null,{"className":"logo","children":["$","$L2",null,{"href":"/","children":"My Blog"}]}],["$","ul",null,{"className":"nav-links","children":[["$","li",null,{"children":["$","$L2",null,{"href":"/","children":"Home"}]}],["$","li",null,{"children":["$","$L2",null,{"href":"/blog","children":"Blog"}]}]]}]]}]}]}],["$","main",null,{"className":"container","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","footer",null,{"className":"footer","children":["$","div",null,{"className":"container","children":["$","p",null,{"children":"© 2024 My Blog. All rights reserved."}]}]}]]}]}]]}],{"children":["blog",["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["slug","getting-started-with-nextjs","d"],["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":["$L5",null,["$","$L6",null,{"children":["$L7",["$","$L8",null,{"promise":"$@9"}]]}]]}],{},null,false]},null,false]},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$La",null,{"children":"$Lb"}],null],["$","$Lc",null,{"children":["$","div",null,{"hidden":true,"children":["$","$d",null,{"fallback":null,"children":"$Le"}]}]}]]}],false]],"m":"$undefined","G":["$f",[]],"s":false,"S":true}
10:T4ec,<h2>What is Next.js?</h2>
<p>Next.js is a React framework that enables you to build full-stack web applications. It provides the best developer experience with all the features needed for production-ready applications.</p>
<h2>Key Features</h2>
<ul>
<li><strong>Server-Side Rendering (SSR):</strong> Render pages on the server and send pre-rendered HTML to the client.</li>
<li><strong>Static Generation:</strong> Generate static pages at build time for better performance.</li>
<li><strong>API Routes:</strong> Build API endpoints inside your Next.js application.</li>
<li><strong>Built-in CSS Support:</strong> Write CSS modules or use global styles.</li>
</ul>
<h2>Getting Started</h2>
<p>To create a new Next.js project, run:</p>
<pre><code class="language-bash">npx create-next-app@latest my-app
</code></pre>
<h2>Why Choose Next.js?</h2>
<p>Next.js makes it easy to build fast, scalable web applications with React. Whether you&#39;re building a blog, e-commerce site, or full-stack application, Next.js provides the tools and features you need.</p>
<h2>Conclusion</h2>
<p>Next.js is a powerful tool for building modern web applications. With its extensive features and great developer experience, it&#39;s an excellent choice for your next project.</p>
5:["$","div",null,{"children":[["$","$L2",null,{"href":"/blog","className":"back-link","children":"← Back to Blog"}],["$","article",null,{"className":"blog-post","children":[["$","h1",null,{"children":"Getting Started with Next.js"}],["$","div",null,{"className":"meta","children":[["$","time",null,{"children":"October 8, 2024"}]," • ","John Doe"]}],["$","div",null,{"className":"content","dangerouslySetInnerHTML":{"__html":"$10"}}]]}]]}]
b:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
7:null
9:{"metadata":[["$","title","0",{"children":"Getting Started with Next.js"}],["$","meta","1",{"name":"description","content":"Learn how to build modern web applications with Next.js"}]],"error":null,"digest":"$undefined"}
e:"$9:metadata"
