# My Blog - Next.js Blog Application

A modern, fast, and beautiful blog built with Next.js, React, and TypeScript.

## Features

- **Modern Design**: Clean and responsive UI that works on all devices
- **Markdown Support**: Write blog posts in Markdown with front matter metadata
- **Fast Performance**: Built with Next.js for optimal performance
- **TypeScript**: Fully typed for better developer experience
- **SEO Friendly**: Metadata optimization for better search engine rankings
- **Easy to Customize**: Simple structure makes it easy to add your own posts

## Getting Started

### Prerequisites

- Node.js 18+ and npm/yarn/pnpm

### Installation

1. Install dependencies:
```bash
npm install
# or
yarn install
# or
pnpm install
```

2. Run the development server:
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser to see the result.

## Project Structure

```
blog-app/
├── app/
│   ├── blog/
│   │   ├── page.tsx          # Blog listing page
│   │   └── [slug]/
│   │       └── page.tsx      # Individual blog post page
│   ├── layout.tsx            # Root layout
│   ├── page.tsx              # Home page
│   └── globals.css           # Global styles
├── posts/                    # Markdown blog posts
│   ├── getting-started-with-nextjs.md
│   ├── understanding-react-hooks.md
│   └── web-performance-optimization.md
├── lib/
│   └── posts.ts              # Markdown file parsing and utilities
├── public/                   # Static assets
├── package.json
├── tsconfig.json
└── next.config.js
```

## Adding New Blog Posts

Create a new Markdown file in the `posts` directory with the following format:

**File: `posts/my-awesome-post.md`**
```markdown
---
title: My Awesome Post
date: October 8, 2024
author: Your Name
excerpt: A brief description of your post
---

## Your Heading

Your content here. You can use **bold**, *italic*, and `code`.

### Subheading

- List item 1
- List item 2

\`\`\`javascript
// Code blocks are supported
const greeting = "Hello, World!";
\`\`\`
```

The post will automatically appear on the blog listing and home page with the slug `my-awesome-post`.

## Customization

### Colors and Styling
Edit `app/globals.css` to customize colors, fonts, and layout.

### Header and Footer
Modify `app/layout.tsx` to change the header and footer content.

### Blog Metadata
Update the site title and description in:
- `app/layout.tsx` (root metadata)
- `app/blog/page.tsx` (blog page metadata)

## Building for Production

```bash
npm run build
npm start
```

## Deployment

This blog can be easily deployed to various platforms:

- **Vercel** (recommended): Push to GitHub and connect to Vercel
- **Netlify**: Connect your repository to Netlify
- **Docker**: Create a Dockerfile and deploy to any container platform
- **Traditional Hosting**: Build and upload the `.next` folder

## Learn More

- [Next.js Documentation](https://nextjs.org/docs)
- [React Documentation](https://react.dev)
- [TypeScript Documentation](https://www.typescriptlang.org)

## License

MIT
