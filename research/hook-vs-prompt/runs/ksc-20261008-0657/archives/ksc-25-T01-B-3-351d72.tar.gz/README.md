# 동아리 책 공유 플랫폼

동아리 회원들이 중고 책을 서로 빌려주고 받을 수 있는 웹 플랫폼입니다.

## 기능

- **회원 관리**: 동아리 회원 등록
- **책 등록**: 소유한 책을 플랫폼에 등록
- **책 검색 및 대여**: 다른 회원의 책을 찾아서 빌리기
- **반환 관리**: 빌려간 책 반환 기록

## 설치 및 실행

### 1. 의존성 설치
```bash
npm install
```

### 2. 서버 실행
```bash
npm run dev
```

서버가 `http://localhost:3001`에서 실행됩니다.

### 3. 브라우저 접속
```
http://localhost:3001
```

## 사용 방법

### 1. 회원가입
- "회원가입" 탭에서 이름과 이메일 입력
- 회원가입 버튼 클릭

### 2. 책 등록
- "책 등록" 탭에서 자신의 이름 선택
- 책 제목, 저자, 설명 입력
- 책 등록 버튼 클릭

### 3. 책 빌리기
- "책 빌리기" 탭에서 자신의 이름 선택
- 원하는 책 찾기
- "빌리기" 버튼 클릭

### 4. 빌린 책 관리
- "내 빌림" 탭에서 자신의 이름 선택
- 빌린 책 목록 확인
- 책 반환 시 "반환하기" 버튼 클릭

## API 엔드포인트

### 사용자 관련
- `POST /api/users` - 사용자 생성
- `GET /api/users` - 모든 사용자 조회

### 책 관련
- `POST /api/books` - 책 등록
- `GET /api/books` - 모든 책 조회
- `GET /api/books/available` - 대여 가능한 책 조회

### 대여 관련
- `POST /api/borrowings` - 책 빌리기
- `PUT /api/borrowings/:id/return` - 책 반환
- `GET /api/users/:user_id/borrowings` - 사용자의 빌림 기록

## 기술 스택

- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Backend**: Node.js, Express.js
- **Database**: SQLite3
- **Port**: 3001
