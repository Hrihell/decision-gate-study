import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import sqlite3 from 'sqlite3';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = 3001;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

const db = new sqlite3.Database(':memory:');

db.serialize(() => {
  db.run(`
    CREATE TABLE users (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      email TEXT UNIQUE
    )
  `);

  db.run(`
    CREATE TABLE books (
      id INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      author TEXT,
      owner_id INTEGER NOT NULL,
      available INTEGER DEFAULT 1,
      description TEXT,
      FOREIGN KEY(owner_id) REFERENCES users(id)
    )
  `);

  db.run(`
    CREATE TABLE borrowings (
      id INTEGER PRIMARY KEY,
      book_id INTEGER NOT NULL,
      borrower_id INTEGER NOT NULL,
      borrowed_date DATETIME DEFAULT CURRENT_TIMESTAMP,
      returned_date DATETIME,
      status TEXT DEFAULT 'borrowed',
      FOREIGN KEY(book_id) REFERENCES books(id),
      FOREIGN KEY(borrower_id) REFERENCES users(id)
    )
  `);
});

// 사용자 생성
app.post('/api/users', (req, res) => {
  const { name, email } = req.body;
  db.run('INSERT INTO users (name, email) VALUES (?, ?)', [name, email], function(err) {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ id: this.lastID, name, email });
  });
});

// 모든 사용자 조회
app.get('/api/users', (req, res) => {
  db.all('SELECT * FROM users', (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(rows);
  });
});

// 책 등록
app.post('/api/books', (req, res) => {
  const { title, author, owner_id, description } = req.body;
  db.run(
    'INSERT INTO books (title, author, owner_id, description) VALUES (?, ?, ?, ?)',
    [title, author, owner_id, description],
    function(err) {
      if (err) return res.status(400).json({ error: err.message });
      res.json({ id: this.lastID, title, author, owner_id, available: 1, description });
    }
  );
});

// 모든 책 조회
app.get('/api/books', (req, res) => {
  db.all(`
    SELECT b.*, u.name as owner_name
    FROM books b
    JOIN users u ON b.owner_id = u.id
  `, (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(rows);
  });
});

// 사용 가능한 책만 조회
app.get('/api/books/available', (req, res) => {
  db.all(`
    SELECT b.*, u.name as owner_name
    FROM books b
    JOIN users u ON b.owner_id = u.id
    WHERE b.available = 1
  `, (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(rows);
  });
});

// 책 빌리기
app.post('/api/borrowings', (req, res) => {
  const { book_id, borrower_id } = req.body;

  db.run('UPDATE books SET available = 0 WHERE id = ?', [book_id], (err) => {
    if (err) return res.status(400).json({ error: err.message });

    db.run(
      'INSERT INTO borrowings (book_id, borrower_id, status) VALUES (?, ?, ?)',
      [book_id, borrower_id, 'borrowed'],
      function(err) {
        if (err) return res.status(400).json({ error: err.message });
        res.json({ id: this.lastID, book_id, borrower_id, status: 'borrowed' });
      }
    );
  });
});

// 빌려간 책 반환
app.put('/api/borrowings/:id/return', (req, res) => {
  const { id } = req.params;

  db.get('SELECT book_id FROM borrowings WHERE id = ?', [id], (err, row) => {
    if (err || !row) return res.status(400).json({ error: 'Borrowing not found' });

    db.run(
      'UPDATE borrowings SET status = ?, returned_date = CURRENT_TIMESTAMP WHERE id = ?',
      ['returned', id],
      (err) => {
        if (err) return res.status(400).json({ error: err.message });

        db.run('UPDATE books SET available = 1 WHERE id = ?', [row.book_id], (err) => {
          if (err) return res.status(400).json({ error: err.message });
          res.json({ status: 'returned' });
        });
      }
    );
  });
});

// 사용자의 빌려간 책 조회
app.get('/api/users/:user_id/borrowings', (req, res) => {
  const { user_id } = req.params;
  db.all(`
    SELECT br.*, b.title, b.author, u.name as owner_name
    FROM borrowings br
    JOIN books b ON br.book_id = b.id
    JOIN users u ON b.owner_id = u.id
    WHERE br.borrower_id = ?
  `, [user_id], (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json(rows);
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
