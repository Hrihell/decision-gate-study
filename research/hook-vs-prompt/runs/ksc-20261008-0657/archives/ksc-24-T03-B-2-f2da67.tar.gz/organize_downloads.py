#!/usr/bin/env python3
import os
import shutil
from pathlib import Path

def organize_downloads():
    downloads_dir = Path("downloads")

    if not downloads_dir.exists():
        print(f"❌ {downloads_dir} 폴더가 없습니다.")
        return

    files_moved = 0

    for file_path in downloads_dir.iterdir():
        if file_path.is_file():
            # 확장자 추출 (없으면 "기타")
            if file_path.suffix:
                ext = file_path.suffix[1:].lower()  # 점(.) 제거
            else:
                ext = "기타"

            # 확장자별 폴더 생성
            ext_dir = downloads_dir / ext
            ext_dir.mkdir(exist_ok=True)

            # 파일 이동
            dest_path = ext_dir / file_path.name
            shutil.move(str(file_path), str(dest_path))
            print(f"✓ {file_path.name} → {ext}/ 폴더로 이동")
            files_moved += 1

    print(f"\n✅ 총 {files_moved}개 파일이 정리되었습니다.")

if __name__ == "__main__":
    organize_downloads()
