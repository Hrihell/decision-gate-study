const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';
const TODOS_KEY = 'todos';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
}

function setCurrentUser(user) {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
}

function loadTodos(userId) {
  const key = `${TODOS_KEY}_${userId}`;
  return JSON.parse(localStorage.getItem(key) || '[]');
}

function saveTodos(userId, todos) {
  const key = `${TODOS_KEY}_${userId}`;
  localStorage.setItem(key, JSON.stringify(todos));
}

function renderTodos(todos) {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const user = getCurrentUser();
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(user.id, next);
      renderTodos(next);
    });
    list.appendChild(item);
  });
}

function showApp() {
  const user = getCurrentUser();
  document.getElementById('auth-container').classList.add('hidden');
  document.getElementById('app-container').classList.remove('hidden');
  document.getElementById('user-name').textContent = `${user.name} 님`;
  renderTodos(loadTodos(user.id));
}

function showAuth() {
  document.getElementById('app-container').classList.add('hidden');
  document.getElementById('auth-container').classList.remove('hidden');
  document.getElementById('login-form').classList.remove('hidden');
  document.getElementById('signup-form').classList.add('hidden');
  document.getElementById('auth-error').textContent = '';
  document.getElementById('login-email').value = '';
  document.getElementById('login-password').value = '';
}

function toggleAuth() {
  const loginForm = document.getElementById('login-form');
  const signupForm = document.getElementById('signup-form');
  loginForm.classList.toggle('hidden');
  signupForm.classList.toggle('hidden');
  document.getElementById('auth-error').textContent = '';
}

function showError(message) {
  document.getElementById('auth-error').textContent = message;
}

// 로그인 처리
document.getElementById('login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  const users = getUsers();
  const user = Object.values(users).find(u => u.email === email && u.password === password);

  if (user) {
    setCurrentUser(user);
    showApp();
  } else {
    showError('이메일 또는 비밀번호가 일치하지 않습니다');
  }
});

// 회원가입 처리
document.getElementById('signup-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('signup-name').value.trim();
  const email = document.getElementById('signup-email').value.trim();
  const password = document.getElementById('signup-password').value;
  const passwordConfirm = document.getElementById('signup-password-confirm').value;

  if (password !== passwordConfirm) {
    showError('비밀번호가 일치하지 않습니다');
    return;
  }

  const users = getUsers();
  if (Object.values(users).some(u => u.email === email)) {
    showError('이미 가입된 이메일입니다');
    return;
  }

  const userId = Date.now().toString();
  const newUser = { id: userId, name, email, password };
  users[userId] = newUser;
  saveUsers(users);
  setCurrentUser(newUser);

  document.getElementById('signup-name').value = '';
  document.getElementById('signup-email').value = '';
  document.getElementById('signup-password').value = '';
  document.getElementById('signup-password-confirm').value = '';

  showApp();
});

// 로그아웃 처리
document.getElementById('logout-btn').addEventListener('click', () => {
  setCurrentUser(null);
  showAuth();
});

// 할 일 추가
document.getElementById('add-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const user = getCurrentUser();
  const input = document.getElementById('new-todo');
  if (input.value.trim() === '') return;

  const todos = loadTodos(user.id);
  todos.push({ text: input.value.trim(), done: false });
  saveTodos(user.id, todos);
  renderTodos(todos);
  input.value = '';
});

// 초기 로드
if (getCurrentUser()) {
  showApp();
} else {
  showAuth();
}
