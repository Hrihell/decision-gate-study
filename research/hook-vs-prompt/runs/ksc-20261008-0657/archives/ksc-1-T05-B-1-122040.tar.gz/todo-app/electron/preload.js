import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('electron', {
  getTodos: () => ipcRenderer.invoke('todos:get'),
  addTodo: (todo) => ipcRenderer.invoke('todos:add', todo),
  updateTodo: (todo) => ipcRenderer.invoke('todos:update', todo),
  deleteTodo: (id) => ipcRenderer.invoke('todos:delete', id),
  toggleTodo: (id) => ipcRenderer.invoke('todos:toggle', id)
});
