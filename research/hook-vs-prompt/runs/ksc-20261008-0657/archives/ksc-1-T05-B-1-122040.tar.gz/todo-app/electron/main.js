import { app, BrowserWindow, ipcMain } from 'electron';
import path from 'path';
import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isDev = !!process.env.VITE_DEV_SERVER_URL;

let mainWindow;
let db;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 700,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  if (isDev) {
    mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function initDB() {
  const dbPath = path.join(app.getPath('userData'), 'todos.db');
  db = new Database(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS todos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      priority INTEGER DEFAULT 0,
      dueDate TEXT,
      completed INTEGER DEFAULT 0,
      createdAt TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);
}

ipcMain.handle('todos:get', () => {
  const stmt = db.prepare('SELECT * FROM todos ORDER BY priority DESC, createdAt DESC');
  return stmt.all();
});

ipcMain.handle('todos:add', (event, todo) => {
  const stmt = db.prepare(
    'INSERT INTO todos (title, description, priority, dueDate) VALUES (?, ?, ?, ?)'
  );
  const result = stmt.run(todo.title, todo.description, todo.priority, todo.dueDate);
  return { id: result.lastInsertRowid, ...todo };
});

ipcMain.handle('todos:update', (event, todo) => {
  const stmt = db.prepare(
    'UPDATE todos SET title = ?, description = ?, priority = ?, dueDate = ?, completed = ? WHERE id = ?'
  );
  stmt.run(todo.title, todo.description, todo.priority, todo.dueDate, todo.completed, todo.id);
  return todo;
});

ipcMain.handle('todos:delete', (event, id) => {
  const stmt = db.prepare('DELETE FROM todos WHERE id = ?');
  stmt.run(id);
  return id;
});

ipcMain.handle('todos:toggle', (event, id) => {
  const stmt = db.prepare('UPDATE todos SET completed = NOT completed WHERE id = ?');
  stmt.run(id);
  const getTodo = db.prepare('SELECT * FROM todos WHERE id = ?');
  return getTodo.get(id);
});

app.on('ready', () => {
  initDB();
  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});
