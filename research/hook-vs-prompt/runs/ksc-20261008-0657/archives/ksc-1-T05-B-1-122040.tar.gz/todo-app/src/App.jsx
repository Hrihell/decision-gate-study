import { useState, useEffect } from 'react'
import './App.css'

function App() {
  const [todos, setTodos] = useState([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [priority, setPriority] = useState(0)
  const [dueDate, setDueDate] = useState('')
  const [editingId, setEditingId] = useState(null)

  useEffect(() => {
    loadTodos()
  }, [])

  const loadTodos = async () => {
    const data = await window.electron.getTodos()
    setTodos(data)
  }

  const handleAddTodo = async (e) => {
    e.preventDefault()
    if (!title.trim()) return

    if (editingId) {
      const todo = todos.find(t => t.id === editingId)
      const updated = await window.electron.updateTodo({
        id: editingId,
        title,
        description,
        priority: parseInt(priority),
        dueDate,
        completed: todo.completed
      })
      setTodos(todos.map(t => t.id === editingId ? updated : t))
      setEditingId(null)
    } else {
      const newTodo = await window.electron.addTodo({
        title,
        description,
        priority: parseInt(priority),
        dueDate
      })
      setTodos([newTodo, ...todos])
    }

    setTitle('')
    setDescription('')
    setPriority(0)
    setDueDate('')
  }

  const handleToggleTodo = async (id) => {
    const updated = await window.electron.toggleTodo(id)
    setTodos(todos.map(t => t.id === id ? updated : t))
  }

  const handleDeleteTodo = async (id) => {
    await window.electron.deleteTodo(id)
    setTodos(todos.filter(t => t.id !== id))
  }

  const handleEditTodo = (todo) => {
    setEditingId(todo.id)
    setTitle(todo.title)
    setDescription(todo.description)
    setPriority(todo.priority)
    setDueDate(todo.dueDate)
  }

  const handleCancel = () => {
    setEditingId(null)
    setTitle('')
    setDescription('')
    setPriority(0)
    setDueDate('')
  }

  const priorityLabels = { 0: '낮음', 1: '중간', 2: '높음' }
  const priorityColors = { 0: '#90EE90', 1: '#FFD700', 2: '#FF6B6B' }

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>할 일 관리</h1>
      </header>

      <main className="app-main">
        <form className="add-form" onSubmit={handleAddTodo}>
          <div className="form-group">
            <input
              type="text"
              placeholder="할 일을 입력하세요..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={100}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <textarea
                placeholder="설명 (선택사항)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows="2"
                maxLength={500}
              ></textarea>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <select value={priority} onChange={(e) => setPriority(e.target.value)}>
                <option value="0">우선순위: 낮음</option>
                <option value="1">우선순위: 중간</option>
                <option value="2">우선순위: 높음</option>
              </select>
            </div>

            <div className="form-group">
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
          </div>

          <div className="form-actions">
            <button type="submit" className="btn btn-primary">
              {editingId ? '수정' : '추가'}
            </button>
            {editingId && (
              <button type="button" className="btn btn-secondary" onClick={handleCancel}>
                취소
              </button>
            )}
          </div>
        </form>

        <div className="todos-container">
          {todos.length === 0 ? (
            <p className="empty-message">할 일이 없습니다. 새로운 할 일을 추가해보세요!</p>
          ) : (
            <ul className="todos-list">
              {todos.map((todo) => (
                <li
                  key={todo.id}
                  className={`todo-item ${todo.completed ? 'completed' : ''}`}
                  style={{ borderLeft: `4px solid ${priorityColors[todo.priority]}` }}
                >
                  <div className="todo-content">
                    <input
                      type="checkbox"
                      checked={todo.completed}
                      onChange={() => handleToggleTodo(todo.id)}
                      className="todo-checkbox"
                    />
                    <div className="todo-text">
                      <h3>{todo.title}</h3>
                      {todo.description && <p>{todo.description}</p>}
                      <div className="todo-meta">
                        <span className="priority-badge" style={{ backgroundColor: priorityColors[todo.priority] }}>
                          {priorityLabels[todo.priority]}
                        </span>
                        {todo.dueDate && <span className="due-date">📅 {todo.dueDate}</span>}
                      </div>
                    </div>
                  </div>
                  <div className="todo-actions">
                    {!todo.completed && (
                      <button
                        className="btn btn-edit"
                        onClick={() => handleEditTodo(todo)}
                        title="수정"
                      >
                        ✏️
                      </button>
                    )}
                    <button
                      className="btn btn-delete"
                      onClick={() => handleDeleteTodo(todo.id)}
                      title="삭제"
                    >
                      🗑️
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </main>
    </div>
  )
}

export default App
