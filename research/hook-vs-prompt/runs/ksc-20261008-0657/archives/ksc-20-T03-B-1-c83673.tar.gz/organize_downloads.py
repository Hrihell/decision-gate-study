#!/usr/bin/env python3
import os
import shutil
from pathlib import Path

def organize_downloads():
    downloads_dir = Path("downloads")

    if not downloads_dir.exists():
        print("❌ downloads 폴더가 없습니다.")
        return

    # 파일들을 확장자별로 분류
    file_groups = {}

    for file_path in downloads_dir.glob("*"):
        if file_path.is_file():
            # 확장자 추출 (없으면 "기타")
            extension = file_path.suffix[1:].lower() if file_path.suffix else "기타"

            if extension not in file_groups:
                file_groups[extension] = []
            file_groups[extension].append(file_path)

    if not file_groups:
        print("📁 downloads 폴더가 비어있습니다.")
        return

    # 확장자별 폴더 생성 및 파일 이동
    print(f"📂 {len(file_groups)}개의 확장자를 발견했습니다.\n")

    for extension, files in sorted(file_groups.items()):
        folder_name = downloads_dir / extension.upper()

        # 폴더 생성
        folder_name.mkdir(exist_ok=True)

        # 파일 이동
        for file_path in files:
            target_path = folder_name / file_path.name
            shutil.move(str(file_path), str(target_path))
            print(f"✓ {file_path.name} → {extension.upper()}/")

        print(f"  └─ {len(files)}개 파일 정렬 완료\n")

    print(f"✅ 모든 파일이 확장자별로 정렬되었습니다!")
    print(f"\n📊 정렬 결과:")
    for extension in sorted(file_groups.keys()):
        print(f"   - {extension.upper()}: {len(file_groups[extension])}개 파일")

if __name__ == "__main__":
    organize_downloads()
