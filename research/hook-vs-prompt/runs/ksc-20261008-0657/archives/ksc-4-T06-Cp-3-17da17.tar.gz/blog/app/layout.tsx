import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "My Blog",
  description: "A Next.js powered blog",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-white">
        <Header />
        <main className="max-w-4xl mx-auto px-4 pb-16">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
