import { getAllPosts, getPostBySlug } from "@/lib/blog/get-posts";
import { marked } from "marked";
import Link from "next/link";

interface Params {
  slug: string;
}

export async function generateStaticParams() {
  const posts = getAllPosts();
  return posts.map((post) => ({
    slug: post.slug,
  }));
}

export default async function BlogPost({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  const htmlContent = await marked(post.content);

  return (
    <article className="max-w-2xl mx-auto">
      <Link
        href="/"
        className="text-blue-600 hover:text-blue-800 mb-6 inline-block"
      >
        ← Back to all posts
      </Link>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">{post.title}</h1>
        <div className="flex items-center justify-between">
          <time className="text-gray-600">
            {new Date(post.date).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </time>
          {post.category && (
            <span className="text-xs bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
              {post.category}
            </span>
          )}
        </div>
      </header>

      <div
        className="prose max-w-none text-gray-700 leading-relaxed"
        dangerouslySetInnerHTML={{ __html: htmlContent }}
      />
    </article>
  );
}
