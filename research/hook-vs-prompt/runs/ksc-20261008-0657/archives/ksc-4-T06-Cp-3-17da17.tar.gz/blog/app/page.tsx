import { getAllPosts } from "@/lib/blog/get-posts";
import PostCard from "@/components/PostCard";

export default function Home() {
  const posts = getAllPosts();

  return (
    <div>
      <div className="grid gap-6">
        {posts.length > 0 ? (
          posts.map((post) => <PostCard key={post.slug} post={post} />)
        ) : (
          <p className="text-gray-600 text-center py-12">
            No posts yet. Check back soon!
          </p>
        )}
      </div>
    </div>
  );
}
