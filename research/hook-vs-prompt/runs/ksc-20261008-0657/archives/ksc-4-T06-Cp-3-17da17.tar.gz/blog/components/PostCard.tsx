import Link from "next/link";
import { Post } from "@/lib/blog/get-posts";

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  return (
    <article className="border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <h2 className="text-2xl font-bold text-gray-900">
          <Link href={`/blog/${post.slug}`} className="hover:text-blue-600">
            {post.title}
          </Link>
        </h2>
        {post.category && (
          <span className="text-xs bg-blue-100 text-blue-800 px-3 py-1 rounded-full whitespace-nowrap ml-4">
            {post.category}
          </span>
        )}
      </div>
      <time className="text-sm text-gray-500 block mb-3">
        {new Date(post.date).toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
        })}
      </time>
      <p className="text-gray-600 mb-4">{post.excerpt}</p>
      <Link
        href={`/blog/${post.slug}`}
        className="text-blue-600 hover:text-blue-800 font-medium"
      >
        Read more →
      </Link>
    </article>
  );
}
