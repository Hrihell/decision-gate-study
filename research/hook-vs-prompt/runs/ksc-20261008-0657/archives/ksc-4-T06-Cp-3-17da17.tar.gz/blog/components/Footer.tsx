export default function Footer() {
  return (
    <footer className="border-t border-gray-200 mt-16 py-8">
      <div className="max-w-4xl mx-auto px-4 text-center text-gray-600">
        <p>&copy; 2024 My Blog. All rights reserved.</p>
      </div>
    </footer>
  );
}
