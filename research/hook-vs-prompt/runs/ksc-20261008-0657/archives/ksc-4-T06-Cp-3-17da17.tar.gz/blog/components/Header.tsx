export default function Header() {
  return (
    <header className="border-b border-gray-200 py-8 mb-8">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">My Blog</h1>
        <p className="text-gray-600">Thoughts, stories, and ideas</p>
      </div>
    </header>
  );
}
