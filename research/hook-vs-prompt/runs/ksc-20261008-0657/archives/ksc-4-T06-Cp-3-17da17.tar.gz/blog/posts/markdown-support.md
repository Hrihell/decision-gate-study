---
title: Markdown Support in This Blog
date: 2024-10-06
excerpt: This blog supports full Markdown syntax for beautiful formatted posts.
category: Features
---

# Markdown Support

This blog is built with full Markdown support, allowing you to write rich, formatted posts easily.

## Headings

You can use different heading levels:

### Heading 3
#### Heading 4
##### Heading 5

## Text Formatting

You can make text **bold**, *italic*, or ***bold italic***.

## Lists

### Unordered List
- Item 1
- Item 2
- Item 3

### Ordered List
1. First item
2. Second item
3. Third item

## Code Blocks

Here's some code:

```javascript
const greeting = "Hello, World!";
console.log(greeting);
```

## Blockquotes

> "The best way to predict the future is to invent it." - Alan Kay

## Links

[Visit OpenAI](https://openai.com)

Enjoy writing with Markdown!
