---
title: Getting Started with Next.js
date: 2024-10-07
excerpt: Learn the basics of Next.js and how to build amazing web applications.
category: Tutorial
---

# Getting Started with Next.js

Next.js is a powerful framework built on top of React that makes it easy to build fast, scalable web applications.

## Key Features

- **File-based Routing**: Automatic routing based on your file structure
- **API Routes**: Build serverless APIs
- **Image Optimization**: Automatic image optimization
- **Code Splitting**: Automatic code splitting for better performance

## Getting Started

```
npx create-next-app@latest my-app
cd my-app
npm run dev
```

Visit `http://localhost:3000` to see your app running!

## Next Steps

Now that you have Next.js installed, you can:
1. Create new pages in the `app` directory
2. Add components in the `components` directory
3. Build an API with route handlers

Happy coding!
