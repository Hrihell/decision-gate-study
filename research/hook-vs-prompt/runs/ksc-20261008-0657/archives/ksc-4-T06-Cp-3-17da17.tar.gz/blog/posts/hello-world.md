---
title: Hello World
date: 2024-10-08
excerpt: Welcome to my new blog! This is the first post.
category: Welcome
---

# Hello World

Welcome to my new blog! I'm excited to share my thoughts and ideas with you.

## What to expect

This blog will cover topics related to:
- Web development
- Next.js
- React
- TypeScript

## Let's get started

I hope you enjoy reading my posts. Feel free to come back often for new content!
