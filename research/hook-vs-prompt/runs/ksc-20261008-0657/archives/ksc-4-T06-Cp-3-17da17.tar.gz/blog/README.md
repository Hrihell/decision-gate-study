# Next.js Blog

A beautiful, fast, and simple blog built with Next.js, React, TypeScript, and Tailwind CSS.

## Features

- ✨ Markdown support for blog posts
- 📄 Static site generation with dynamic routing
- 🎨 Clean and responsive design with Tailwind CSS
- 🏷️ Category support for organizing posts
- ⚡ Fast loading with automatic optimization
- 📱 Fully responsive design

## Getting Started

### Prerequisites

- Node.js 18+ and npm

### Installation

```bash
npm install
```

### Development

Run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

### Building for Production

```bash
npm run build
npm run start
```

## Project Structure

```
.
├── app/                    # Next.js App Router directory
│   ├── layout.tsx         # Root layout
│   ├── page.tsx           # Home page (blog listing)
│   ├── globals.css        # Global styles
│   └── blog/
│       ├── layout.tsx     # Blog layout
│       └── [slug]/
│           └── page.tsx   # Dynamic blog post page
├── components/            # Reusable React components
│   ├── Header.tsx
│   ├── Footer.tsx
│   └── PostCard.tsx
├── lib/
│   └── blog/
│       └── get-posts.ts   # Utility functions for fetching posts
├── posts/                 # Markdown blog posts
│   ├── hello-world.md
│   ├── getting-started-with-nextjs.md
│   └── markdown-support.md
├── public/                # Static assets
├── package.json
├── tailwind.config.ts     # Tailwind CSS configuration
├── tsconfig.json          # TypeScript configuration
└── next.config.ts         # Next.js configuration
```

## Adding New Posts

1. Create a new `.md` file in the `posts/` directory
2. Add frontmatter with metadata at the top of the file:

```markdown
---
title: Your Post Title
date: 2024-10-08
excerpt: A brief description of your post
category: Tutorial
---

# Your Post Title

Your content here...
```

3. The blog will automatically pick up the new post and display it on the home page

## Customization

### Styling

Edit `tailwind.config.ts` to customize colors, fonts, and other design elements.

### Components

Modify components in the `components/` directory to change the look and feel of the blog.

### Metadata

Update the blog title and description in `app/layout.tsx`:

```tsx
export const metadata: Metadata = {
  title: "Your Blog Title",
  description: "Your blog description",
};
```

## Technologies Used

- [Next.js](https://nextjs.org/) - React framework for production
- [React](https://react.dev/) - JavaScript library for building user interfaces
- [TypeScript](https://www.typescriptlang.org/) - Typed superset of JavaScript
- [Tailwind CSS](https://tailwindcss.com/) - Utility-first CSS framework
- [Marked](https://marked.js.org/) - Markdown parser
- [Gray Matter](https://github.com/jonschlinkert/gray-matter) - Front-matter parser

## License

ISC
