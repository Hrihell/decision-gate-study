import discord
from discord import app_commands
from discord.ext import commands
import aiohttp
import os

# 설정
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "YOUR_TOKEN_HERE")
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "YOUR_OPENWEATHER_KEY")

# 인텐트 설정
intents = discord.Intents.default()
intents.message_content = True

# 봇 생성
bot = commands.Bot(command_prefix="!", intents=intents)

# OpenWeather API URL
WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/weather"

@bot.event
async def on_ready():
    print(f"✅ {bot.user}로 로그인했습니다!")
    try:
        synced = await bot.tree.sync()
        print(f"✅ {len(synced)}개의 슬래시 명령어를 동기화했습니다.")
    except Exception as e:
        print(f"❌ 명령어 동기화 실패: {e}")

@bot.tree.command(name="weather", description="서울의 현재 날씨를 조회합니다")
async def weather(interaction: discord.Interaction):
    """서울의 날씨 정보를 OpenWeather API에서 조회합니다"""
    await interaction.response.defer()

    try:
        # API 호출
        async with aiohttp.ClientSession() as session:
            params = {
                "q": "Seoul,KR",
                "appid": OPENWEATHER_API_KEY,
                "units": "metric",
                "lang": "ko"
            }
            async with session.get(WEATHER_API_URL, params=params) as resp:
                if resp.status != 200:
                    await interaction.followup.send(
                        f"❌ 날씨 정보를 불러올 수 없습니다. (오류 코드: {resp.status})",
                        ephemeral=True
                    )
                    return

                data = await resp.json()

        # 응답 파싱
        weather_desc = data["weather"][0]["main"]
        weather_desc_ko = data["weather"][0]["description"]
        temp = data["main"]["temp"]
        feels_like = data["main"]["feels_like"]
        humidity = data["main"]["humidity"]
        wind_speed = data["wind"]["speed"]
        cloud_percent = data["clouds"]["all"]

        # 임베드 메시지 생성
        embed = discord.Embed(
            title="🌤️ 서울 날씨",
            color=discord.Color.blue(),
            description=f"**{weather_desc_ko.capitalize()}**"
        )
        embed.add_field(name="🌡️ 현재 기온", value=f"{temp}°C", inline=True)
        embed.add_field(name="🤔 체감 기온", value=f"{feels_like}°C", inline=True)
        embed.add_field(name="💧 습도", value=f"{humidity}%", inline=True)
        embed.add_field(name="💨 풍속", value=f"{wind_speed} m/s", inline=True)
        embed.add_field(name="☁️ 구름", value=f"{cloud_percent}%", inline=True)

        await interaction.followup.send(embed=embed)

    except KeyError:
        await interaction.followup.send(
            "❌ API 키가 유효하지 않거나 설정되지 않았습니다.",
            ephemeral=True
        )
    except Exception as e:
        await interaction.followup.send(
            f"❌ 오류가 발생했습니다: {str(e)}",
            ephemeral=True
        )

@bot.tree.command(name="ping", description="봇의 응답 시간을 확인합니다")
async def ping(interaction: discord.Interaction):
    """핑/퐁 테스트"""
    await interaction.response.send_message(
        f"🏓 퐁! 응답 시간: {round(bot.latency * 1000)}ms"
    )

# 봇 실행
if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)
