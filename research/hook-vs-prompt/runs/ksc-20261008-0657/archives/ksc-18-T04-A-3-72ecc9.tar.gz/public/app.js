class App {
  constructor() {
    this.token = localStorage.getItem('token');
    this.user = localStorage.getItem('user');
    this.currentTab = 'dashboard';
    this.showForm = false;
    this.render();
  }

  async register(username, password) {
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      alert('회원가입 완료! 로그인해주세요.');
      this.authMode = 'login';
      this.render();
    } catch (err) {
      alert('오류: ' + err.message);
    }
  }

  async login(username, password) {
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', username);
      this.token = data.token;
      this.user = username;
      this.render();
    } catch (err) {
      alert('오류: ' + err.message);
    }
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.token = null;
    this.user = null;
    this.authMode = 'login';
    this.render();
  }

  async addTransaction(category, amount, description, type) {
    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.token}`
        },
        body: JSON.stringify({ category, amount, description, type })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      this.showForm = false;
      this.loadTransactions();
      alert('거래 기록이 저장되었습니다.');
    } catch (err) {
      alert('오류: ' + err.message);
    }
  }

  async deleteTransaction(id) {
    if (!confirm('삭제하시겠습니까?')) return;
    try {
      const res = await fetch(`/api/transactions/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });
      if (!res.ok) throw new Error('삭제 실패');
      this.loadTransactions();
    } catch (err) {
      alert('오류: ' + err.message);
    }
  }

  async loadTransactions() {
    try {
      const res = await fetch('/api/transactions', {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });
      const data = await res.json();
      if (!res.ok) throw new Error('데이터 로드 실패');
      this.transactions = data;
      this.render();
    } catch (err) {
      alert('오류: ' + err.message);
    }
  }

  renderAuthPage() {
    const authMode = this.authMode || 'login';
    const title = authMode === 'login' ? '로그인' : '회원가입';

    return `
      <div class="container">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #667eea; font-size: 36px;">💰 가계부</h1>
          <p style="color: #999; margin-top: 10px;">가계를 체계적으로 관리하세요</p>
        </div>

        <div class="auth-form">
          <h2 style="text-align: center; margin-bottom: 20px; color: #333;">${title}</h2>
          <form onsubmit="app.handleAuthSubmit(event)">
            <div class="form-group">
              <label>사용자명</label>
              <input type="text" id="username" required>
            </div>
            <div class="form-group">
              <label>비밀번호</label>
              <input type="password" id="password" required>
            </div>
            <button type="submit" class="button">${title}</button>
          </form>

          <div style="text-align: center; margin-top: 20px;">
            <button
              type="button"
              onclick="app.toggleAuthMode()"
              style="background: none; border: none; color: #667eea; cursor: pointer; text-decoration: underline;"
            >
              ${authMode === 'login' ? '회원가입하기' : '로그인하기'}
            </button>
          </div>
        </div>
      </div>
    `;
  }

  renderDashboard() {
    if (!this.transactions) {
      this.loadTransactions();
      return '<div class="container"><p style="text-align: center;">로딩 중...</p></div>';
    }

    const income = this.transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const expense = this.transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    const balance = income - expense;

    const sortedTransactions = [...this.transactions].sort((a, b) => new Date(b.date) - new Date(a.date));

    return `
      <div class="container">
        <div class="header">
          <h1>가계부</h1>
          <div style="display: flex; align-items: center; gap: 15px;">
            <span class="username">${this.user}님</span>
            <button class="logout-btn" onclick="app.logout()">로그아웃</button>
          </div>
        </div>

        <div class="tab-buttons">
          <button class="tab-btn ${this.currentTab === 'dashboard' ? 'active' : ''}" onclick="app.switchTab('dashboard')">대시보드</button>
          <button class="tab-btn ${this.currentTab === 'transactions' ? 'active' : ''}" onclick="app.switchTab('transactions')">거래 기록</button>
        </div>

        ${this.currentTab === 'dashboard' ? this.renderSummary(income, expense, balance) : this.renderTransactions(sortedTransactions)}
      </div>
    `;
  }

  renderSummary(income, expense, balance) {
    return `
      <div class="summary">
        <div class="summary-card income">
          <h3>총 수입</h3>
          <div class="amount">₩${income.toLocaleString()}</div>
        </div>
        <div class="summary-card expense">
          <h3>총 지출</h3>
          <div class="amount">₩${expense.toLocaleString()}</div>
        </div>
        <div class="summary-card balance">
          <h3>잔액</h3>
          <div class="amount">₩${balance.toLocaleString()}</div>
        </div>
      </div>

      <button class="toggle-form-btn" onclick="app.toggleForm()">
        ${this.showForm ? '❌ 폼 닫기' : '➕ 새 거래 추가'}
      </button>

      ${this.showForm ? this.renderTransactionForm() : ''}

      <div class="transactions-list">
        <h3 style="margin-bottom: 15px;">최근 거래</h3>
        ${this.getRecentTransactions(5).map(t => this.renderTransactionItem(t)).join('') || '<div class="empty-state">거래 기록이 없습니다</div>'}
      </div>
    `;
  }

  renderTransactions(transactions) {
    return `
      <button class="toggle-form-btn" onclick="app.toggleForm()">
        ${this.showForm ? '❌ 폼 닫기' : '➕ 새 거래 추가'}
      </button>

      ${this.showForm ? this.renderTransactionForm() : ''}

      <div class="transactions-list">
        ${transactions.length > 0 ? transactions.map(t => this.renderTransactionItem(t)).join('') : '<div class="empty-state">거래 기록이 없습니다</div>'}
      </div>
    `;
  }

  renderTransactionForm() {
    return `
      <div class="form-section">
        <form onsubmit="app.handleTransactionSubmit(event)">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div class="form-group">
              <label>유형</label>
              <select id="type" required>
                <option value="expense">지출</option>
                <option value="income">수입</option>
              </select>
            </div>
            <div class="form-group">
              <label>카테고리</label>
              <input type="text" id="category" placeholder="예: 식비, 교통비" required>
            </div>
            <div class="form-group">
              <label>금액</label>
              <input type="number" id="amount" step="0.01" placeholder="0" required>
            </div>
            <div class="form-group">
              <label>설명</label>
              <input type="text" id="description" placeholder="선택사항">
            </div>
          </div>
          <button type="submit" class="button">저장</button>
        </form>
      </div>
    `;
  }

  renderTransactionItem(transaction) {
    const date = new Date(transaction.date);
    const formattedDate = date.toLocaleDateString('ko-KR');
    const typeClass = transaction.type === 'income' ? 'income' : 'expense';
    const sign = transaction.type === 'income' ? '+' : '-';

    return `
      <div class="transaction-item ${typeClass}">
        <div class="transaction-info">
          <div class="transaction-category">${transaction.category}</div>
          ${transaction.description ? `<div class="transaction-description">${transaction.description}</div>` : ''}
          <div class="transaction-date">${formattedDate}</div>
        </div>
        <div style="display: flex; align-items: center; gap: 10px;">
          <span class="transaction-amount ${typeClass}">${sign}₩${transaction.amount.toLocaleString()}</span>
          <button class="delete-btn" onclick="app.deleteTransaction('${transaction.id}')">삭제</button>
        </div>
      </div>
    `;
  }

  getRecentTransactions(count) {
    return [...this.transactions]
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, count);
  }

  toggleAuthMode() {
    this.authMode = this.authMode === 'login' ? 'register' : 'login';
    this.render();
  }

  toggleForm() {
    this.showForm = !this.showForm;
    this.render();
  }

  switchTab(tab) {
    this.currentTab = tab;
    this.showForm = false;
    this.render();
  }

  handleAuthSubmit(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (this.authMode === 'register') {
      this.register(username, password);
    } else {
      this.login(username, password);
    }
  }

  handleTransactionSubmit(event) {
    event.preventDefault();
    const type = document.getElementById('type').value;
    const category = document.getElementById('category').value;
    const amount = document.getElementById('amount').value;
    const description = document.getElementById('description').value;

    this.addTransaction(category, amount, description, type);
  }

  render() {
    const app = document.getElementById('app');
    if (!this.token) {
      app.innerHTML = this.renderAuthPage();
    } else {
      app.innerHTML = this.renderDashboard();
    }
  }
}

const app = new App();
