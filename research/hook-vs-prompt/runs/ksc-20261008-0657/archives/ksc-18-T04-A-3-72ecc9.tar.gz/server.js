const express = require('express');
const jwt = require('jsonwebtoken');
const bcryptjs = require('bcryptjs');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const SECRET = 'your-secret-key-change-this';

const usersFile = path.join(__dirname, 'users.json');
const transactionsFile = path.join(__dirname, 'transactions.json');

app.use(express.json());
app.use(cors());
app.use(express.static('public'));

const initializeFiles = () => {
  if (!fs.existsSync(usersFile)) {
    fs.writeFileSync(usersFile, JSON.stringify([]));
  }
  if (!fs.existsSync(transactionsFile)) {
    fs.writeFileSync(transactionsFile, JSON.stringify([]));
  }
};

const getUsers = () => JSON.parse(fs.readFileSync(usersFile, 'utf8'));
const saveUsers = (users) => fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
const getTransactions = () => JSON.parse(fs.readFileSync(transactionsFile, 'utf8'));
const saveTransactions = (transactions) => fs.writeFileSync(transactionsFile, JSON.stringify(transactions, null, 2));

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

app.post('/api/register', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: '사용자명과 비밀번호를 입력하세요' });
  }

  const users = getUsers();
  if (users.find(u => u.username === username)) {
    return res.status(400).json({ error: '이미 존재하는 사용자명입니다' });
  }

  const hashedPassword = bcryptjs.hashSync(password, 10);
  users.push({ id: Date.now().toString(), username, password: hashedPassword });
  saveUsers(users);

  res.json({ message: '회원가입 완료' });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  const users = getUsers();
  const user = users.find(u => u.username === username);

  if (!user || !bcryptjs.compareSync(password, user.password)) {
    return res.status(401).json({ error: '사용자명 또는 비밀번호가 잘못되었습니다' });
  }

  const token = jwt.sign({ id: user.id, username: user.username }, SECRET, { expiresIn: '24h' });
  res.json({ token });
});

app.post('/api/transactions', authenticateToken, (req, res) => {
  const { category, amount, description, type } = req.body;

  if (!category || !amount || !type) {
    return res.status(400).json({ error: '필수 정보를 입력하세요' });
  }

  const transactions = getTransactions();
  const transaction = {
    id: Date.now().toString(),
    userId: req.user.id,
    category,
    amount: parseFloat(amount),
    description: description || '',
    type,
    date: new Date().toISOString()
  };

  transactions.push(transaction);
  saveTransactions(transactions);

  res.json(transaction);
});

app.get('/api/transactions', authenticateToken, (req, res) => {
  const transactions = getTransactions();
  const userTransactions = transactions.filter(t => t.userId === req.user.id);
  res.json(userTransactions);
});

app.delete('/api/transactions/:id', authenticateToken, (req, res) => {
  const transactions = getTransactions();
  const index = transactions.findIndex(t => t.id === req.params.id && t.userId === req.user.id);

  if (index === -1) {
    return res.status(404).json({ error: '거래 기록을 찾을 수 없습니다' });
  }

  transactions.splice(index, 1);
  saveTransactions(transactions);

  res.json({ message: '삭제되었습니다' });
});

initializeFiles();
app.listen(PORT, () => {
  console.log(`서버가 http://localhost:${PORT}에서 실행 중입니다`);
});
