const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';

function hashPassword(password) {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function setCurrentUser(email) {
  localStorage.setItem(CURRENT_USER_KEY, email);
}

function clearCurrentUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
}

function getTodosKey(email) {
  return `todos_${email}`;
}

function loadTodos(email) {
  return JSON.parse(localStorage.getItem(getTodosKey(email)) || '[]');
}

function saveTodos(email, todos) {
  localStorage.setItem(getTodosKey(email), JSON.stringify(todos));
}

function showAuthScreen() {
  document.getElementById('auth-screen').style.display = 'block';
  document.getElementById('app-screen').style.display = 'none';
}

function showAppScreen() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('app-screen').style.display = 'block';
}

function renderTodos(email, todos) {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(email, next);
      renderTodos(email, next);
    });
    list.appendChild(item);
  });
}

function showError(message) {
  document.getElementById('auth-error').textContent = message;
}

function clearError() {
  document.getElementById('auth-error').textContent = '';
}

document.getElementById('signup-toggle').addEventListener('click', () => {
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('signup-form').style.display = 'block';
  clearError();
});

document.getElementById('login-toggle').addEventListener('click', () => {
  document.getElementById('login-form').style.display = 'block';
  document.getElementById('signup-form').style.display = 'none';
  clearError();
});

document.getElementById('login-form').addEventListener('submit', (event) => {
  event.preventDefault();
  clearError();
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  const users = getUsers();
  if (!users[email]) {
    showError('이메일이 존재하지 않습니다.');
    return;
  }

  if (users[email].password !== hashPassword(password)) {
    showError('비밀번호가 올바르지 않습니다.');
    return;
  }

  setCurrentUser(email);
  document.getElementById('login-email').value = '';
  document.getElementById('login-password').value = '';
  showAppScreen();
  renderTodos(email, loadTodos(email));
});

document.getElementById('signup-form').addEventListener('submit', (event) => {
  event.preventDefault();
  clearError();
  const email = document.getElementById('signup-email').value.trim();
  const password = document.getElementById('signup-password').value;
  const passwordConfirm = document.getElementById('signup-password-confirm').value;

  if (password !== passwordConfirm) {
    showError('비밀번호가 일치하지 않습니다.');
    return;
  }

  const users = getUsers();
  if (users[email]) {
    showError('이미 등록된 이메일입니다.');
    return;
  }

  users[email] = { password: hashPassword(password) };
  saveUsers(users);

  setCurrentUser(email);
  document.getElementById('signup-email').value = '';
  document.getElementById('signup-password').value = '';
  document.getElementById('signup-password-confirm').value = '';

  document.getElementById('login-form').style.display = 'block';
  document.getElementById('signup-form').style.display = 'none';

  showAppScreen();
  renderTodos(email, []);
});

document.getElementById('logout-btn').addEventListener('click', () => {
  clearCurrentUser();
  showAuthScreen();
  document.getElementById('login-form').style.display = 'block';
  document.getElementById('signup-form').style.display = 'none';
});

document.getElementById('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const currentUser = getCurrentUser();
  const input = document.getElementById('new-todo');
  if (input.value.trim() === '') return;
  const todos = loadTodos(currentUser);
  const next = [...todos, { text: input.value.trim(), done: false }];
  saveTodos(currentUser, next);
  renderTodos(currentUser, next);
  input.value = '';
});

const currentUser = getCurrentUser();
if (currentUser) {
  showAppScreen();
  renderTodos(currentUser, loadTodos(currentUser));
} else {
  showAuthScreen();
}
