import Link from 'next/link'
import { getPosts } from '@/lib/posts'

export default function Home() {
  const posts = getPosts()

  return (
    <div className="home">
      <section className="hero">
        <h1>Welcome to My Blog</h1>
        <p>Sharing thoughts and ideas on web development</p>
      </section>

      <section className="posts">
        <h2>Latest Posts</h2>
        {posts.length === 0 ? (
          <p>No posts yet. Check back soon!</p>
        ) : (
          <div className="posts-grid">
            {posts.map((post) => (
              <article key={post.slug} className="post-card">
                <h3><Link href={`/posts/${post.slug}`}>{post.title}</Link></h3>
                <time dateTime={post.date}>{new Date(post.date).toLocaleDateString()}</time>
                <p>{post.excerpt}</p>
                <Link href={`/posts/${post.slug}`} className="read-more">Read More →</Link>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
