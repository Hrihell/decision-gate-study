import Link from 'next/link'
import { getPostBySlug, getAllPostSlugs } from '@/lib/posts'
import { notFound } from 'next/navigation'

export async function generateStaticParams() {
  const slugs = getAllPostSlugs()
  return slugs.map((slug) => ({ slug }))
}

export default function PostPage({ params }: { params: { slug: string } }) {
  const post = getPostBySlug(params.slug)

  if (!post) {
    notFound()
  }

  return (
    <article className="post">
      <header className="post-header">
        <h1>{post.title}</h1>
        <time dateTime={post.date}>{new Date(post.date).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })}</time>
      </header>

      <div className="post-content">
        {post.content}
      </div>

      <footer className="post-footer">
        <Link href="/" className="back-link">← Back to posts</Link>
      </footer>
    </article>
  )
}
