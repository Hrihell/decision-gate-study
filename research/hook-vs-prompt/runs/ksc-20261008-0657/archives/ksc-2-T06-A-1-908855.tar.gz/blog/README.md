# My Blog - Next.js Blog Template

A simple, elegant blog built with Next.js 16, React, and TypeScript.

## Features

- 📝 Simple blog with home page and individual post pages
- ⚡ Fast performance with Next.js
- 🎨 Clean, responsive design with CSS
- 📱 Mobile-friendly layout
- 🔍 SEO-friendly structure
- 📅 Post organization by date

## Project Structure

```
blog/
├── app/
│   ├── layout.tsx         # Root layout with header and footer
│   ├── page.tsx           # Home page showing all posts
│   └── posts/
│       └── [slug]/
│           └── page.tsx   # Individual post pages
├── lib/
│   └── posts.ts           # Post data management utilities
├── styles/
│   └── globals.css        # Global styles
├── posts-data/            # Blog post JSON files
├── public/                # Static assets
└── package.json           # Project dependencies
```

## Getting Started

### Prerequisites

- Node.js 18+ installed

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser

## Adding Posts

Posts are stored as JSON files in the `posts-data/` directory.

Create a new post by adding a JSON file like:

```json
{
  "slug": "my-first-post",
  "title": "My First Post",
  "date": "2024-01-15",
  "excerpt": "A brief description of the post",
  "content": "The full content of the post. You can use line breaks and formatting."
}
```

The `slug` will be used in the URL, so it should be URL-friendly (lowercase, hyphens instead of spaces).

## Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Build for production
- `npm start` - Start the production server
- `npm run lint` - Run ESLint

## Customization

### Styling

All styles are in `styles/globals.css`. Modify CSS variables to change colors and fonts:

```css
:root {
  --primary-color: #0070f3;
  --text-color: #333;
  --bg-color: #f9f9f9;
}
```

### Header and Footer

Edit the layout in `app/layout.tsx` to customize the header and footer content.

## Technology Stack

- **Next.js 16** - React framework
- **React 19** - UI library
- **TypeScript** - Type safety
- **CSS** - Styling

## License

ISC
