:HL["/_next/static/chunks/3eg8o-mnw_h8-.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":{"n":"slug","t":"d","k":"react-hooks-explained","s":[]},"h":96,"c":"$Q3"}]]
1:[["children",{"s":"posts","h":96,"c":"$Q2"}]]
0:{"b":"yw-o8kpsdKGQgs9E37R3v","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
