import fs from 'fs'
import path from 'path'

export interface Post {
  slug: string
  title: string
  date: string
  excerpt: string
  content: string
}

const postsDirectory = path.join(process.cwd(), 'posts-data')

export function getPosts(): Post[] {
  if (!fs.existsSync(postsDirectory)) {
    return []
  }

  const files = fs.readdirSync(postsDirectory)
  const posts = files
    .filter((file) => file.endsWith('.json'))
    .map((file) => {
      const content = fs.readFileSync(path.join(postsDirectory, file), 'utf-8')
      return JSON.parse(content) as Post
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  return posts
}

export function getPostBySlug(slug: string): Post | null {
  const filePath = path.join(postsDirectory, `${slug}.json`)

  if (!fs.existsSync(filePath)) {
    return null
  }

  const content = fs.readFileSync(filePath, 'utf-8')
  return JSON.parse(content) as Post
}

export function getAllPostSlugs(): string[] {
  if (!fs.existsSync(postsDirectory)) {
    return []
  }

  const files = fs.readdirSync(postsDirectory)
  return files.filter((file) => file.endsWith('.json')).map((file) => file.replace('.json', ''))
}
