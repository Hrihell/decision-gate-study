// Preload script - currently empty as we don't need IPC
