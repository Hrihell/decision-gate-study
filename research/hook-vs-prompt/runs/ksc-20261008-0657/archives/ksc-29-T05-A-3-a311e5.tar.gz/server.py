#!/usr/bin/env python3
import http.server
import socketserver
import os
import webbrowser

PORT = 8000
HANDLER = http.server.SimpleHTTPRequestHandler

os.chdir(os.path.dirname(os.path.abspath(__file__)))

with socketserver.TCPServer(("", PORT), HANDLER) as httpd:
    url = f"http://localhost:{PORT}"
    print(f"서버가 {url}에서 실행 중입니다.")
    print("브라우저가 자동으로 열립니다...")
    webbrowser.open(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n서버가 종료되었습니다.")
