#!/usr/bin/env python3
import os
import shutil
from pathlib import Path
from collections import defaultdict

def organize_downloads():
    downloads_dir = Path("downloads")

    if not downloads_dir.exists():
        print("❌ downloads 폴더를 찾을 수 없습니다.")
        return

    # 파일들을 확장자별로 분류
    files_by_ext = defaultdict(list)
    moved_count = 0

    for file_path in downloads_dir.iterdir():
        if file_path.is_file():
            # 확장자 추출 (확장자가 없으면 'no_extension' 사용)
            ext = file_path.suffix.lower().lstrip('.') or 'no_extension'
            files_by_ext[ext].append(file_path)

    # 각 확장자별 폴더 생성 및 파일 이동
    for ext, files in sorted(files_by_ext.items()):
        folder_name = downloads_dir / ext
        folder_name.mkdir(exist_ok=True)

        for file_path in files:
            dest_path = folder_name / file_path.name
            shutil.move(str(file_path), str(dest_path))
            moved_count += 1
            print(f"✓ {file_path.name} → {ext}/")

    print(f"\n✅ 완료! 총 {moved_count}개 파일이 {len(files_by_ext)}개 폴더로 정리되었습니다.")
    print("\n📁 정리된 폴더 구조:")
    for folder in sorted(downloads_dir.iterdir()):
        if folder.is_dir():
            file_count = len(list(folder.iterdir()))
            print(f"  └─ {folder.name}/ ({file_count}개 파일)")

if __name__ == "__main__":
    organize_downloads()
