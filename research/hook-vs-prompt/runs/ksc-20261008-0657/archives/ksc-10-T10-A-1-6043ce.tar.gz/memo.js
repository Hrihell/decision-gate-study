#!/usr/bin/env node
import readline from 'node:readline';
import Database from 'better-sqlite3';

const db = new Database('memos.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS memos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL
  )
`);

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log('메모를 입력하세요. "목록" 은 전체 보기, "삭제 번호"는 삭제, "끝" 은 종료.');
rl.on('line', (line) => {
  const text = line.trim();
  if (text === '끝') {
    db.close();
    return rl.close();
  }
  if (text === '목록') {
    const memos = db.prepare('SELECT id, text FROM memos ORDER BY id').all();
    if (memos.length === 0) {
      console.log('메모가 없습니다.');
    } else {
      memos.forEach((memo) => console.log(`${memo.id}. ${memo.text}`));
    }
    return;
  }
  if (text.startsWith('삭제 ')) {
    const id = parseInt(text.substring(3));
    db.prepare('DELETE FROM memos WHERE id = ?').run(id);
    console.log(`메모 ${id}를 삭제했습니다.`);
    return;
  }
  if (text !== '') {
    db.prepare('INSERT INTO memos (text) VALUES (?)').run(text);
    console.log('메모가 저장되었습니다.');
  }
});
