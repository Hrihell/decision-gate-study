import tkinter as tk
from tkinter import messagebox
import json
import os

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("할 일 목록")
        self.root.geometry("500x600")
        self.root.configure(bg="#f0f0f0")
        
        self.todos = []
        self.data_file = "todos.json"
        self.load_todos()
        
        # 제목
        title_label = tk.Label(
            root, 
            text="📝 할 일 목록", 
            font=("Arial", 18, "bold"),
            bg="#f0f0f0"
        )
        title_label.pack(pady=10)
        
        # 입력 프레임
        input_frame = tk.Frame(root, bg="#f0f0f0")
        input_frame.pack(padx=10, pady=5, fill="x")
        
        self.entry = tk.Entry(
            input_frame, 
            font=("Arial", 12),
            width=35
        )
        self.entry.pack(side="left", padx=5, fill="x", expand=True)
        self.entry.bind("<Return>", lambda e: self.add_todo())
        
        add_btn = tk.Button(
            input_frame,
            text="추가",
            command=self.add_todo,
            bg="#4CAF50",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=15
        )
        add_btn.pack(side="left", padx=5)
        
        # 리스트박스 (프레임으로 감싸기)
        list_frame = tk.Frame(root, bg="white", relief="sunken", bd=1)
        list_frame.pack(padx=10, pady=10, fill="both", expand=True)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side="right", fill="y")
        
        self.listbox = tk.Listbox(
            list_frame,
            font=("Arial", 11),
            yscrollcommand=scrollbar.set,
            relief="flat",
            bg="white"
        )
        self.listbox.pack(fill="both", expand=True)
        scrollbar.config(command=self.listbox.yview)
        self.listbox.bind("<Double-Button-1>", lambda e: self.mark_done())
        
        # 버튼 프레임
        btn_frame = tk.Frame(root, bg="#f0f0f0")
        btn_frame.pack(padx=10, pady=10, fill="x")
        
        delete_btn = tk.Button(
            btn_frame,
            text="✕ 삭제",
            command=self.delete_todo,
            bg="#f44336",
            fg="white",
            font=("Arial", 9, "bold"),
            padx=10
        )
        delete_btn.pack(side="left", padx=5)
        
        clear_btn = tk.Button(
            btn_frame,
            text="🗑️ 완료된 항목 지우기",
            command=self.clear_done,
            bg="#FF9800",
            fg="white",
            font=("Arial", 9, "bold"),
            padx=10
        )
        clear_btn.pack(side="left", padx=5)
        
        # 상태 라벨
        self.status_label = tk.Label(
            root,
            text="",
            font=("Arial", 9),
            bg="#f0f0f0",
            fg="#666"
        )
        self.status_label.pack(pady=5)
        
        self.refresh_list()
    
    def add_todo(self):
        task = self.entry.get().strip()
        if task:
            self.todos.append({"task": task, "done": False})
            self.save_todos()
            self.entry.delete(0, tk.END)
            self.refresh_list()
        else:
            messagebox.showwarning("경고", "할 일을 입력해주세요!")
    
    def delete_todo(self):
        selection = self.listbox.curselection()
        if selection:
            idx = selection[0]
            self.todos.pop(idx)
            self.save_todos()
            self.refresh_list()
        else:
            messagebox.showwarning("경고", "삭제할 항목을 선택해주세요!")
    
    def mark_done(self):
        selection = self.listbox.curselection()
        if selection:
            idx = selection[0]
            self.todos[idx]["done"] = not self.todos[idx]["done"]
            self.save_todos()
            self.refresh_list()
    
    def clear_done(self):
        self.todos = [t for t in self.todos if not t["done"]]
        self.save_todos()
        self.refresh_list()
    
    def refresh_list(self):
        self.listbox.delete(0, tk.END)
        
        pending = sum(1 for t in self.todos if not t["done"])
        done = sum(1 for t in self.todos if t["done"])
        self.status_label.config(
            text=f"대기 중: {pending} | 완료: {done}"
        )
        
        for item in self.todos:
            task = item["task"]
            prefix = "✓ " if item["done"] else "○ "
            display_text = prefix + task
            self.listbox.insert(tk.END, display_text)
            
            if item["done"]:
                self.listbox.itemconfig(self.listbox.size() - 1, fg="#999")
    
    def save_todos(self):
        with open(self.data_file, "w", encoding="utf-8") as f:
            json.dump(self.todos, f, ensure_ascii=False, indent=2)
    
    def load_todos(self):
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, "r", encoding="utf-8") as f:
                    self.todos = json.load(f)
            except:
                self.todos = []

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
