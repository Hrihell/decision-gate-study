#!/usr/bin/env python3
import os
import shutil
from pathlib import Path
from collections import defaultdict

def organize_downloads(downloads_path='downloads'):
    """downloads 폴더의 파일들을 확장자별로 정리합니다."""

    downloads_dir = Path(downloads_path)

    if not downloads_dir.exists():
        print(f"❌ 오류: {downloads_path} 폴더가 없습니다.")
        return

    # 파일들을 확장자별로 분류
    files_by_extension = defaultdict(list)

    for item in downloads_dir.iterdir():
        if item.is_file():
            # 확장자 추출 (확장자가 없으면 'no_extension')
            ext = item.suffix[1:].lower() if item.suffix else 'no_extension'
            files_by_extension[ext].append(item)

    # 각 확장자별로 폴더 생성 및 파일 이동
    for ext, files in sorted(files_by_extension.items()):
        folder_name = ext.upper() if ext != 'no_extension' else 'ETC'
        folder_path = downloads_dir / folder_name

        # 폴더가 없으면 생성
        folder_path.mkdir(exist_ok=True)

        # 파일 이동
        for file in files:
            dest_path = folder_path / file.name
            shutil.move(str(file), str(dest_path))
            print(f"✓ {file.name} → {folder_name}/")

        print(f"📁 [{folder_name}] - {len(files)}개 파일\n")

    print("✅ 정리 완료!")

if __name__ == '__main__':
    organize_downloads()
