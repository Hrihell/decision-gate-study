#!/usr/bin/env node
import readline from 'node:readline';
import Database from 'better-sqlite3';

const db = new Database('memos.db');

// 테이블 초기화
db.exec(`
  CREATE TABLE IF NOT EXISTS memos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log('메모를 입력하세요. "목록" 은 전체 보기, "끝" 은 종료.');
rl.on('line', (line) => {
  const text = line.trim();
  if (text === '끝') {
    db.close();
    return rl.close();
  }
  if (text === '목록') {
    const memos = db.prepare('SELECT id, text FROM memos ORDER BY id').all();
    memos.forEach((memo) => console.log(`${memo.id}. ${memo.text}`));
    return;
  }
  if (text !== '') {
    db.prepare('INSERT INTO memos (text) VALUES (?)').run(text);
  }
});
