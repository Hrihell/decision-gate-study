const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = new sqlite3.Database(':memory:');

db.serialize(() => {
  db.run(`CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    owner_id INTEGER NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'available',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(owner_id) REFERENCES users(id)
  )`);

  db.run(`CREATE TABLE loans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    borrower_id INTEGER NOT NULL,
    lender_id INTEGER NOT NULL,
    borrowed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    returned_at DATETIME,
    FOREIGN KEY(book_id) REFERENCES books(id),
    FOREIGN KEY(borrower_id) REFERENCES users(id),
    FOREIGN KEY(lender_id) REFERENCES users(id)
  )`);

  db.run(`INSERT INTO users (name, email) VALUES ('김민수', 'minsu@example.com')`);
  db.run(`INSERT INTO users (name, email) VALUES ('이진호', 'jinho@example.com')`);
  db.run(`INSERT INTO users (name, email) VALUES ('박지영', 'jiyoung@example.com')`);

  db.run(`INSERT INTO books (title, author, owner_id, description, status) VALUES
    ('혼자 공부하는 파이썬', '윤인성', 1, '파이썬 기초 학습서', 'available')`);
  db.run(`INSERT INTO books (title, author, owner_id, description, status) VALUES
    ('클린 코드', 'Robert C. Martin', 2, '좋은 코드 작성법', 'available')`);
  db.run(`INSERT INTO books (title, author, owner_id, description, status) VALUES
    ('자료구조와 알고리즘', '구종만', 3, '알고리즘 학습서', 'available')`);
});

// 사용자 관련 API
app.get('/api/users', (req, res) => {
  db.all('SELECT * FROM users', (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

app.post('/api/users', (req, res) => {
  const { name, email } = req.body;
  db.run('INSERT INTO users (name, email) VALUES (?, ?)', [name, email], function(err) {
    if (err) {
      res.status(400).json({ error: err.message });
      return;
    }
    res.json({ id: this.lastID, name, email });
  });
});

// 책 관련 API
app.get('/api/books', (req, res) => {
  db.all(`SELECT b.*, u.name as owner_name FROM books b JOIN users u ON b.owner_id = u.id`,
    (err, rows) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      res.json(rows);
    }
  );
});

app.get('/api/books/:id', (req, res) => {
  const { id } = req.params;
  db.get(`SELECT b.*, u.name as owner_name FROM books b JOIN users u ON b.owner_id = u.id WHERE b.id = ?`,
    [id], (err, row) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      res.json(row);
    }
  );
});

app.post('/api/books', (req, res) => {
  const { title, author, owner_id, description } = req.body;
  db.run('INSERT INTO books (title, author, owner_id, description) VALUES (?, ?, ?, ?)',
    [title, author, owner_id, description], function(err) {
      if (err) {
        res.status(400).json({ error: err.message });
        return;
      }
      res.json({ id: this.lastID, title, author, owner_id, description, status: 'available' });
    }
  );
});

// 대출 관련 API
app.get('/api/loans', (req, res) => {
  db.all(`SELECT l.*, b.title, u1.name as borrower_name, u2.name as lender_name
    FROM loans l
    JOIN books b ON l.book_id = b.id
    JOIN users u1 ON l.borrower_id = u1.id
    JOIN users u2 ON l.lender_id = u2.id`,
    (err, rows) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      res.json(rows);
    }
  );
});

app.post('/api/loans', (req, res) => {
  const { book_id, borrower_id, lender_id } = req.body;

  db.serialize(() => {
    db.run('UPDATE books SET status = ? WHERE id = ?', ['borrowed', book_id]);
    db.run('INSERT INTO loans (book_id, borrower_id, lender_id) VALUES (?, ?, ?)',
      [book_id, borrower_id, lender_id], function(err) {
        if (err) {
          res.status(400).json({ error: err.message });
          return;
        }
        res.json({ id: this.lastID, book_id, borrower_id, lender_id });
      }
    );
  });
});

app.post('/api/loans/:id/return', (req, res) => {
  const { id } = req.params;

  db.get('SELECT book_id FROM loans WHERE id = ?', [id], (err, loan) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }

    db.serialize(() => {
      db.run('UPDATE books SET status = ? WHERE id = ?', ['available', loan.book_id]);
      db.run('UPDATE loans SET returned_at = CURRENT_TIMESTAMP WHERE id = ?', [id], function(err) {
        if (err) {
          res.status(400).json({ error: err.message });
          return;
        }
        res.json({ success: true });
      });
    });
  });
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`서버가 포트 ${PORT}에서 실행 중입니다.`);
});
