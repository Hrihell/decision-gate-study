const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function setCurrentUser(username) {
  localStorage.setItem(CURRENT_USER_KEY, username);
}

function getTodos(username) {
  const users = getUsers();
  return users[username]?.todos || [];
}

function saveTodos(username, todos) {
  const users = getUsers();
  if (!users[username]) users[username] = {};
  users[username].todos = todos;
  saveUsers(users);
}

function showError(message) {
  const errorDiv = document.getElementById('auth-error');
  errorDiv.textContent = message;
  errorDiv.style.display = 'block';
  setTimeout(() => {
    errorDiv.style.display = 'none';
  }, 3000);
}

function switchToSignup() {
  document.getElementById('login-form-container').style.display = 'none';
  document.getElementById('signup-form-container').style.display = 'block';
  document.getElementById('auth-error').style.display = 'none';
}

function switchToLogin() {
  document.getElementById('login-form-container').style.display = 'block';
  document.getElementById('signup-form-container').style.display = 'none';
  document.getElementById('auth-error').style.display = 'none';
}

function showAuthScreen() {
  document.getElementById('auth-screen').style.display = 'flex';
  document.getElementById('todo-screen').style.display = 'none';
}

function showTodoScreen(username) {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('todo-screen').style.display = 'flex';
  document.getElementById('user-info').textContent = `${username}님 환영합니다!`;
}

function render(username) {
  const todos = getTodos(username);
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(username, next);
      render(username);
    });
    list.appendChild(item);
  });
}

// 로그인 처리
document.getElementById('login-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;

  const users = getUsers();
  if (!users[username] || users[username].password !== password) {
    showError('사용자명 또는 비밀번호가 잘못되었습니다.');
    return;
  }

  setCurrentUser(username);
  document.getElementById('login-form').reset();
  showTodoScreen(username);
  render(username);
});

// 회원가입 처리
document.getElementById('signup-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('signup-username').value.trim();
  const password = document.getElementById('signup-password').value;
  const passwordConfirm = document.getElementById('signup-password-confirm').value;

  if (!username) {
    showError('사용자명을 입력해 주세요.');
    return;
  }

  if (password.length < 4) {
    showError('비밀번호는 4자 이상이어야 합니다.');
    return;
  }

  if (password !== passwordConfirm) {
    showError('비밀번호가 일치하지 않습니다.');
    return;
  }

  const users = getUsers();
  if (users[username]) {
    showError('이미 존재하는 사용자명입니다.');
    return;
  }

  users[username] = { password, todos: [] };
  saveUsers(users);

  document.getElementById('signup-form').reset();
  switchToLogin();
  showError('가입 완료! 로그인해 주세요.');
});

// 로그아웃 처리
document.getElementById('logout-btn').addEventListener('click', () => {
  localStorage.removeItem(CURRENT_USER_KEY);
  switchToLogin();
  showAuthScreen();
  document.getElementById('login-form').reset();
});

// 할 일 추가
document.getElementById('add-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = getCurrentUser();
  const input = document.getElementById('new-todo');

  if (input.value.trim() === '') return;

  const todos = getTodos(username);
  const next = [...todos, { text: input.value.trim(), done: false }];
  saveTodos(username, next);
  render(username);
  input.value = '';
});

// 폼 전환
document.getElementById('switch-to-signup').addEventListener('click', switchToSignup);
document.getElementById('switch-to-login').addEventListener('click', switchToLogin);

// 초기 화면
const currentUser = getCurrentUser();
if (currentUser) {
  showTodoScreen(currentUser);
  render(currentUser);
} else {
  showAuthScreen();
}
