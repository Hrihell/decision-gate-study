require('dotenv').config();
const express = require('express');
const jwt = require('jsonwebtoken');
const bcryptjs = require('bcryptjs');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'secret';

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

const dataDir = path.join(__dirname, 'data');
const usersFile = path.join(dataDir, 'users.json');
const recordsFile = path.join(dataDir, 'records.json');

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

const getUsers = () => {
  try {
    return JSON.parse(fs.readFileSync(usersFile, 'utf-8'));
  } catch {
    return {};
  }
};

const saveUsers = (users) => {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
};

const getRecords = () => {
  try {
    return JSON.parse(fs.readFileSync(recordsFile, 'utf-8'));
  } catch {
    return [];
  }
};

const saveRecords = (records) => {
  fs.writeFileSync(recordsFile, JSON.stringify(records, null, 2));
};

const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No token' });
  }
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

app.post('/api/auth/register', async (req, res) => {
  const { username, password } = req.body;
  const users = getUsers();

  if (users[username]) {
    return res.status(400).json({ error: 'User already exists' });
  }

  const hashedPassword = await bcryptjs.hash(password, 10);
  users[username] = { password: hashedPassword };
  saveUsers(users);

  res.json({ message: 'User registered' });
});

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const users = getUsers();

  if (!users[username]) {
    return res.status(400).json({ error: 'User not found' });
  }

  const isValid = await bcryptjs.compare(password, users[username].password);
  if (!isValid) {
    return res.status(400).json({ error: 'Invalid password' });
  }

  const token = jwt.sign({ username }, JWT_SECRET);
  res.json({ token });
});

app.post('/api/records', verifyToken, (req, res) => {
  const { category, amount, description, date } = req.body;
  const records = getRecords();

  records.push({
    id: Date.now(),
    username: req.user.username,
    category,
    amount: parseFloat(amount),
    description,
    date: date || new Date().toISOString().split('T')[0],
  });

  saveRecords(records);
  res.json({ message: 'Record added' });
});

app.get('/api/records', verifyToken, (req, res) => {
  const records = getRecords();
  const userRecords = records.filter((r) => r.username === req.user.username);
  res.json(userRecords);
});

app.delete('/api/records/:id', verifyToken, (req, res) => {
  let records = getRecords();
  const recordId = parseInt(req.params.id);
  records = records.filter((r) => !(r.id === recordId && r.username === req.user.username));
  saveRecords(records);
  res.json({ message: 'Record deleted' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
