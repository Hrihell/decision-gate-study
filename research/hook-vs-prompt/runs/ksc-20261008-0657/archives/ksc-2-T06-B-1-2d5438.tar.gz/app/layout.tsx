import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "My Blog",
  description: "A simple blog built with Next.js",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-50">
        <header className="border-b border-slate-200 dark:border-slate-800">
          <nav className="max-w-4xl mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold">My Blog</h1>
              <ul className="flex gap-6">
                <li>
                  <a href="/" className="hover:text-blue-600 dark:hover:text-blue-400">
                    Home
                  </a>
                </li>
                <li>
                  <a href="/posts" className="hover:text-blue-600 dark:hover:text-blue-400">
                    Posts
                  </a>
                </li>
              </ul>
            </div>
          </nav>
        </header>
        <main className="max-w-4xl mx-auto px-4 py-12">
          {children}
        </main>
        <footer className="border-t border-slate-200 dark:border-slate-800 mt-12">
          <div className="max-w-4xl mx-auto px-4 py-6 text-center text-slate-600 dark:text-slate-400">
            <p>&copy; 2024 My Blog. All rights reserved.</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
