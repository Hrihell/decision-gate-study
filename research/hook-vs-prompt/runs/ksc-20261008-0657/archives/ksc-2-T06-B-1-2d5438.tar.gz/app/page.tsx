import Link from "next/link";

const recentPosts = [
  {
    id: 1,
    title: "Getting Started with Next.js",
    excerpt: "Learn the basics of Next.js and how to build modern web applications.",
    date: "2024-01-15",
  },
  {
    id: 2,
    title: "React Hooks Deep Dive",
    excerpt: "Understand the power of React Hooks and how to use them effectively.",
    date: "2024-01-10",
  },
  {
    id: 3,
    title: "Tailwind CSS Tips & Tricks",
    excerpt: "Discover useful techniques to speed up your styling workflow.",
    date: "2024-01-05",
  },
];

export default function Home() {
  return (
    <div>
      <section className="mb-12">
        <h2 className="text-4xl font-bold mb-4">Welcome to My Blog</h2>
        <p className="text-lg text-slate-600 dark:text-slate-400">
          Sharing thoughts and insights about web development, technology, and programming.
        </p>
      </section>

      <section>
        <h3 className="text-2xl font-bold mb-6">Recent Posts</h3>
        <div className="space-y-6">
          {recentPosts.map((post) => (
            <article
              key={post.id}
              className="border border-slate-200 dark:border-slate-800 rounded-lg p-6 hover:shadow-lg dark:hover:shadow-slate-700/50 transition-shadow"
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className="text-xl font-semibold hover:text-blue-600 dark:hover:text-blue-400">
                  <Link href={`/posts/${post.id}`}>
                    {post.title}
                  </Link>
                </h4>
                <time className="text-sm text-slate-500 dark:text-slate-400">
                  {new Date(post.date).toLocaleDateString()}
                </time>
              </div>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                {post.excerpt}
              </p>
              <Link
                href={`/posts/${post.id}`}
                className="text-blue-600 dark:text-blue-400 hover:underline font-medium"
              >
                Read more →
              </Link>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
