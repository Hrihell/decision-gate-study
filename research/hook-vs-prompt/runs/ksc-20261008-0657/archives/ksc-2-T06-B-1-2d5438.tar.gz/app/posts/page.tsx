import Link from "next/link";

const allPosts = [
  {
    id: 1,
    title: "Getting Started with Next.js",
    excerpt: "Learn the basics of Next.js and how to build modern web applications.",
    date: "2024-01-15",
  },
  {
    id: 2,
    title: "React Hooks Deep Dive",
    excerpt: "Understand the power of React Hooks and how to use them effectively.",
    date: "2024-01-10",
  },
  {
    id: 3,
    title: "Tailwind CSS Tips & Tricks",
    excerpt: "Discover useful techniques to speed up your styling workflow.",
    date: "2024-01-05",
  },
  {
    id: 4,
    title: "TypeScript Best Practices",
    excerpt: "Master TypeScript and write more maintainable code.",
    date: "2023-12-28",
  },
  {
    id: 5,
    title: "Web Performance Optimization",
    excerpt: "Learn techniques to make your website faster and more responsive.",
    date: "2023-12-20",
  },
];

export default function Posts() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-8">All Posts</h1>
      <div className="space-y-6">
        {allPosts.map((post) => (
          <article
            key={post.id}
            className="border border-slate-200 dark:border-slate-800 rounded-lg p-6 hover:shadow-lg dark:hover:shadow-slate-700/50 transition-shadow"
          >
            <div className="flex justify-between items-start mb-2">
              <h2 className="text-2xl font-semibold hover:text-blue-600 dark:hover:text-blue-400">
                <Link href={`/posts/${post.id}`}>
                  {post.title}
                </Link>
              </h2>
              <time className="text-sm text-slate-500 dark:text-slate-400 whitespace-nowrap ml-4">
                {new Date(post.date).toLocaleDateString()}
              </time>
            </div>
            <p className="text-slate-600 dark:text-slate-400 mb-4">
              {post.excerpt}
            </p>
            <Link
              href={`/posts/${post.id}`}
              className="text-blue-600 dark:text-blue-400 hover:underline font-medium"
            >
              Read more →
            </Link>
          </article>
        ))}
      </div>
    </div>
  );
}
