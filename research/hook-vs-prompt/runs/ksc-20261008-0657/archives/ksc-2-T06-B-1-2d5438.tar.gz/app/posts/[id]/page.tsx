import Link from "next/link";
import { notFound } from "next/navigation";

const posts: Record<string, {
  id: number;
  title: string;
  date: string;
  content: string;
}> = {
  "1": {
    id: 1,
    title: "Getting Started with Next.js",
    date: "2024-01-15",
    content: `Next.js is a React framework that enables you to build full-stack web applications.

It provides you with production-grade features like:
- Server-side rendering
- Static site generation
- API routes
- Built-in optimization
- Excellent developer experience

Getting started is as simple as running \`npx create-next-app@latest\` and following the prompts.

In this post, we've covered the basics. There's much more to explore in the Next.js documentation!`,
  },
  "2": {
    id: 2,
    title: "React Hooks Deep Dive",
    date: "2024-01-10",
    content: `React Hooks revolutionized how we write React components. They allow you to use state and other React features without writing a class component.

Common hooks include:
- useState: Add state to functional components
- useEffect: Perform side effects in function components
- useContext: Access context values
- useReducer: Complex state management

Hooks follow two important rules:
1. Only call hooks at the top level
2. Only call hooks from React functions

Understanding hooks deeply will make you a better React developer.`,
  },
  "3": {
    id: 3,
    title: "Tailwind CSS Tips & Tricks",
    date: "2024-01-05",
    content: `Tailwind CSS is a utility-first CSS framework that helps you build designs quickly.

Some useful tips:
- Use arbitrary values for custom sizes: \`w-[271px]\`
- Combine modifiers for responsive design: \`md:hover:bg-blue-500\`
- Extract components when you repeat utility combinations
- Use the dark mode modifier: \`dark:bg-slate-950\`
- Configure your theme in \`tailwind.config.js\`

Tailwind's flexibility and consistency make it perfect for building modern UIs.`,
  },
  "4": {
    id: 4,
    title: "TypeScript Best Practices",
    date: "2023-12-28",
    content: `TypeScript adds type safety to JavaScript, helping catch errors before runtime.

Best practices:
- Avoid \`any\` types - be explicit with types
- Use interfaces for object shapes
- Leverage union types for flexible data
- Enable strict mode in tsconfig
- Use type guards for runtime safety

With TypeScript, you write more confident, maintainable code.`,
  },
  "5": {
    id: 5,
    title: "Web Performance Optimization",
    date: "2023-12-20",
    content: `Website performance directly impacts user experience and SEO rankings.

Key techniques:
- Code splitting and lazy loading
- Image optimization and responsive images
- Minifying CSS and JavaScript
- Using a CDN for static assets
- Implementing caching strategies
- Monitoring Core Web Vitals

Next.js has built-in optimizations for many of these concerns!`,
  },
};

export default function Post({ params }: { params: { id: string } }) {
  const post = posts[params.id];

  if (!post) {
    notFound();
  }

  return (
    <div>
      <Link
        href="/posts"
        className="text-blue-600 dark:text-blue-400 hover:underline mb-6 inline-block"
      >
        ← Back to posts
      </Link>

      <article className="prose dark:prose-invert max-w-none">
        <h1 className="text-4xl font-bold mb-2">{post.title}</h1>
        <time className="text-slate-600 dark:text-slate-400 text-sm">
          {new Date(post.date).toLocaleDateString()}
        </time>

        <div className="mt-8 text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
          {post.content}
        </div>
      </article>
    </div>
  );
}
