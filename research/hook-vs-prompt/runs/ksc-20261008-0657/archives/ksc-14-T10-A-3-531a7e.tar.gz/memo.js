#!/usr/bin/env node
import readline from 'node:readline';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dbPath = join(__dirname, 'memos.json');

const loadMemos = () => {
  try {
    return JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
  } catch {
    return [];
  }
};

const saveMemos = (memos) => {
  fs.writeFileSync(dbPath, JSON.stringify(memos, null, 2));
};

let memos = loadMemos();
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log('메모를 입력하세요. "목록" 은 전체 보기, "끝" 은 종료.');
rl.on('line', (line) => {
  const text = line.trim();
  if (text === '끝') {
    return rl.close();
  }
  if (text === '목록') {
    memos.forEach((memo, i) => console.log(`${i + 1}. ${memo}`));
    return;
  }
  if (text !== '') {
    memos.push(text);
    saveMemos(memos);
    console.log('저장됨!');
  }
});
