const API_URL = 'http://localhost:3000';
let currentUserId = null;

async function loadUsers() {
  const res = await fetch(`${API_URL}/api/users`);
  const users = await res.json();
  const select = document.getElementById('currentUser');
  select.innerHTML = '<option value="">사용자 선택</option>';
  users.forEach(user => {
    const option = document.createElement('option');
    option.value = user.id;
    option.textContent = user.name;
    select.appendChild(option);
  });
}

async function loadAllBooks() {
  const res = await fetch(`${API_URL}/api/books`);
  const books = await res.json();
  const container = document.getElementById('allBooks');

  if (books.length === 0) {
    container.innerHTML = '<div class="empty-message">등록된 책이 없습니다</div>';
    return;
  }

  container.innerHTML = books.map(book => `
    <div class="book-card">
      <div class="book-title">${book.title}</div>
      <div class="book-author">저자: ${book.author || '미표기'}</div>
      <div class="book-owner">소유자: ${book.owner_name}</div>
      <div class="book-status ${book.status === 'available' ? 'status-available' : 'status-borrowed'}">
        ${book.status === 'available' ? '이용 가능' : '빌림'}
      </div>
      ${book.status === 'borrowed' ? `
        <div class="borrowed-info">
          ${book.borrower_name}이 ${book.borrowed_date}부터 빌리고 있습니다
        </div>
      ` : ''}
      <div class="book-actions">
        ${currentUserId && book.status === 'available' && book.owner_id != currentUserId ? `
          <button class="btn-borrow" onclick="borrowBook(${book.id})">빌리기</button>
        ` : ''}
        ${currentUserId && book.status === 'borrowed' && book.borrowed_by == currentUserId ? `
          <button class="btn-return" onclick="returnBook(${book.id})">반납하기</button>
        ` : ''}
        ${currentUserId && book.owner_id == currentUserId ? `
          <button class="btn-delete" onclick="deleteBook(${book.id})">삭제</button>
        ` : ''}
      </div>
    </div>
  `).join('');
}

async function loadMyBooks() {
  if (!currentUserId) {
    document.getElementById('myBooks').innerHTML = '<div class="empty-message">사용자를 선택해주세요</div>';
    return;
  }

  const res = await fetch(`${API_URL}/api/my-books/${currentUserId}`);
  const books = await res.json();
  const container = document.getElementById('myBooks');

  const myBooks = books.filter(b => b.owner_id == currentUserId);
  const borrowedBooks = books.filter(b => b.borrowed_by == currentUserId);

  let html = '';
  if (myBooks.length > 0) {
    html += '<h3 style="color: #667eea; margin: 15px 0 10px; font-size: 14px;">내 소유 책</h3>';
    html += myBooks.map(book => `
      <div class="book-card">
        <div class="book-title">${book.title}</div>
        <div class="book-author">저자: ${book.author || '미표기'}</div>
        <div class="book-status ${book.status === 'available' ? 'status-available' : 'status-borrowed'}">
          ${book.status === 'available' ? '이용 가능' : '빌림'}
        </div>
        ${book.status === 'borrowed' ? `
          <div class="borrowed-info">
            누군가 ${book.borrowed_date}부터 빌리고 있습니다
          </div>
        ` : ''}
      </div>
    `).join('');
  }

  if (borrowedBooks.length > 0) {
    html += '<h3 style="color: #667eea; margin: 15px 0 10px; font-size: 14px;">내가 빌린 책</h3>';
    html += borrowedBooks.map(book => `
      <div class="book-card">
        <div class="book-title">${book.title}</div>
        <div class="book-author">저자: ${book.author || '미표기'}</div>
        <div class="book-owner">소유자: ${book.owner_name}</div>
        <div class="borrowed-info">
          ${book.borrowed_date}부터 빌렸습니다
        </div>
        <div class="book-actions">
          <button class="btn-return" onclick="returnBook(${book.id})">반납하기</button>
        </div>
      </div>
    `).join('');
  }

  if (myBooks.length === 0 && borrowedBooks.length === 0) {
    html = '<div class="empty-message">책이 없습니다</div>';
  }

  container.innerHTML = html;
}

async function borrowBook(bookId) {
  if (!currentUserId) {
    alert('사용자를 선택해주세요');
    return;
  }

  await fetch(`${API_URL}/api/borrow/${bookId}/${currentUserId}`, { method: 'POST' });
  loadAllBooks();
  loadMyBooks();
}

async function returnBook(bookId) {
  await fetch(`${API_URL}/api/return/${bookId}`, { method: 'POST' });
  loadAllBooks();
  loadMyBooks();
}

async function deleteBook(bookId) {
  if (!confirm('이 책을 삭제하시겠습니까?')) return;
  // 실제로는 DELETE 엔드포인트를 만들어야 함
  // 여기서는 간단하게 처리
  alert('삭제 기능은 아직 지원하지 않습니다');
}

async function addBook(e) {
  e.preventDefault();

  if (!currentUserId) {
    alert('사용자를 선택해주세요');
    return;
  }

  const title = document.getElementById('bookTitle').value;
  const author = document.getElementById('bookAuthor').value;

  await fetch(`${API_URL}/api/books`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, author, owner_id: currentUserId })
  });

  document.getElementById('addBookForm').reset();
  loadAllBooks();
  loadMyBooks();
}

document.getElementById('currentUser').addEventListener('change', (e) => {
  currentUserId = e.target.value || null;
  loadAllBooks();
  loadMyBooks();
});

document.getElementById('addBookForm').addEventListener('submit', addBook);

// 초기 로드
loadUsers();
loadAllBooks();
