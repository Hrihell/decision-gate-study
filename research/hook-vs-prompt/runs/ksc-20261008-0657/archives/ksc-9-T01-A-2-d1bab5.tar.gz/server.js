const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const db = new sqlite3.Database(':memory:');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// 데이터베이스 초기화
db.serialize(() => {
  db.run(`CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
  )`);

  db.run(`CREATE TABLE books (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    author TEXT,
    owner_id INTEGER NOT NULL,
    status TEXT DEFAULT 'available',
    borrowed_by INTEGER,
    borrowed_date TEXT,
    FOREIGN KEY(owner_id) REFERENCES users(id),
    FOREIGN KEY(borrowed_by) REFERENCES users(id)
  )`);

  // 샘플 사용자
  db.run("INSERT INTO users (name) VALUES ('김민수')");
  db.run("INSERT INTO users (name) VALUES ('이영희')");
  db.run("INSERT INTO users (name) VALUES ('박준호')");

  // 샘플 책
  db.run("INSERT INTO books (title, author, owner_id, status) VALUES ('혼자 공부하는 파이썬', '나동빈', 1, 'available')");
  db.run("INSERT INTO books (title, author, owner_id, status) VALUES ('클린 코드', 'Robert C. Martin', 2, 'available')");
  db.run("INSERT INTO books (title, author, owner_id, status) VALUES ('자료구조와 알고리즘', 'Mark Allen Weiss', 3, 'available')");
});

// API 엔드포인트
app.get('/api/users', (req, res) => {
  db.all('SELECT * FROM users', (err, rows) => {
    res.json(rows);
  });
});

app.get('/api/books', (req, res) => {
  db.all(`SELECT b.*, u.name as owner_name, u2.name as borrower_name
          FROM books b
          LEFT JOIN users u ON b.owner_id = u.id
          LEFT JOIN users u2 ON b.borrowed_by = u2.id`,
    (err, rows) => {
      res.json(rows || []);
    }
  );
});

app.post('/api/books', (req, res) => {
  const { title, author, owner_id } = req.body;
  db.run(
    'INSERT INTO books (title, author, owner_id, status) VALUES (?, ?, ?, ?)',
    [title, author, owner_id, 'available'],
    function(err) {
      if (err) {
        res.status(400).json({ error: err.message });
      } else {
        res.json({ id: this.lastID, title, author, owner_id, status: 'available' });
      }
    }
  );
});

app.post('/api/borrow/:bookId/:userId', (req, res) => {
  const { bookId, userId } = req.params;
  const borrowDate = new Date().toISOString().split('T')[0];

  db.run(
    'UPDATE books SET status = ?, borrowed_by = ?, borrowed_date = ? WHERE id = ?',
    ['borrowed', userId, borrowDate, bookId],
    function(err) {
      if (err) {
        res.status(400).json({ error: err.message });
      } else {
        res.json({ success: true });
      }
    }
  );
});

app.post('/api/return/:bookId', (req, res) => {
  db.run(
    'UPDATE books SET status = ?, borrowed_by = NULL, borrowed_date = NULL WHERE id = ?',
    ['available', bookId],
    function(err) {
      if (err) {
        res.status(400).json({ error: err.message });
      } else {
        res.json({ success: true });
      }
    }
  );
});

app.get('/api/my-books/:userId', (req, res) => {
  const { userId } = req.params;
  db.all(
    `SELECT b.*, u.name as owner_name FROM books b
     LEFT JOIN users u ON b.owner_id = u.id
     WHERE b.owner_id = ? OR b.borrowed_by = ?`,
    [userId, userId],
    (err, rows) => {
      res.json(rows || []);
    }
  );
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`서버가 http://localhost:${PORT}에서 실행 중입니다`);
});
