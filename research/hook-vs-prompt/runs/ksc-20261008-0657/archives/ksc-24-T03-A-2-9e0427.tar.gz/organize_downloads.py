#!/usr/bin/env python3
import os
import shutil
from pathlib import Path

def organize_downloads(downloads_path):
    """downloads 폴더 내의 파일들을 확장자별로 정리합니다."""

    downloads_dir = Path(downloads_path)

    if not downloads_dir.exists():
        print(f"오류: {downloads_path} 폴더를 찾을 수 없습니다.")
        return

    # 폴더 내의 모든 파일을 확장자별로 분류
    files_moved = 0

    for item in downloads_dir.iterdir():
        if item.is_file():
            # 확장자 추출
            if item.suffix:
                extension = item.suffix[1:].lower()  # 점 제거하고 소문자로
            else:
                extension = "no_extension"

            # 확장자별 폴더 생성
            ext_folder = downloads_dir / extension
            ext_folder.mkdir(exist_ok=True)

            # 파일 이동
            destination = ext_folder / item.name
            shutil.move(str(item), str(destination))
            print(f"✓ {item.name} → {extension}/")
            files_moved += 1

    print(f"\n총 {files_moved}개의 파일이 정리되었습니다.")

    # 정리 결과 출력
    print("\n📁 정리된 폴더 구조:")
    for folder in sorted(downloads_dir.iterdir()):
        if folder.is_dir():
            file_count = len(list(folder.iterdir()))
            print(f"  {folder.name}/ ({file_count}개)")

if __name__ == "__main__":
    organize_downloads("downloads")
