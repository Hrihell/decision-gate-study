import discord
from discord.ext import commands
import aiohttp
import os
from dotenv import load_dotenv

load_dotenv()

DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')
WEATHER_API_KEY = os.getenv('WEATHER_API_KEY')

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/weather"

@bot.event
async def on_ready():
    print(f'{bot.user}로 로그인 완료')

@bot.command(name='서울날씨')
async def seoul_weather(ctx):
    """서울의 날씨 정보를 조회합니다."""
    try:
        params = {
            'q': 'Seoul',
            'appid': WEATHER_API_KEY,
            'units': 'metric',
            'lang': 'ko'
        }

        async with aiohttp.ClientSession() as session:
            async with session.get(WEATHER_API_URL, params=params) as response:
                if response.status != 200:
                    await ctx.send('❌ 날씨 정보를 가져올 수 없습니다.')
                    return

                data = await response.json()

        # 날씨 정보 추출
        temp = data['main']['temp']
        feels_like = data['main']['feels_like']
        humidity = data['main']['humidity']
        wind_speed = data['wind']['speed']
        description = data['weather'][0]['description']

        # 이모지 설정
        weather_icons = {
            '맑음': '☀️',
            '구름조금': '⛅',
            '흐림': '☁️',
            '비': '🌧️',
            '소나기': '⛈️',
            '눈': '❄️'
        }
        icon = weather_icons.get(description, '🌤️')

        # 메시지 구성
        embed = discord.Embed(
            title=f"{icon} 서울 날씨",
            color=discord.Color.blue(),
            description=f"**{description}**"
        )
        embed.add_field(name="🌡️ 온도", value=f"{temp}°C", inline=True)
        embed.add_field(name="🤔 체감온도", value=f"{feels_like}°C", inline=True)
        embed.add_field(name="💧 습도", value=f"{humidity}%", inline=True)
        embed.add_field(name="💨 풍속", value=f"{wind_speed} m/s", inline=True)

        await ctx.send(embed=embed)

    except Exception as e:
        print(f'오류: {e}')
        await ctx.send(f'❌ 오류가 발생했습니다: {str(e)}')

@bot.command(name='핑')
async def ping(ctx):
    """봇의 응답 시간을 확인합니다."""
    await ctx.send(f'🏓 Pong! {round(bot.latency * 1000)}ms')

if __name__ == '__main__':
    if not DISCORD_TOKEN:
        print('오류: DISCORD_TOKEN이 설정되지 않았습니다.')
        exit(1)
    if not WEATHER_API_KEY:
        print('오류: WEATHER_API_KEY가 설정되지 않았습니다.')
        exit(1)

    bot.run(DISCORD_TOKEN)
