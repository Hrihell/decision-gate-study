# 서울 날씨 디스코드 봇 🌤️

서울의 실시간 날씨 정보를 디스코드에서 바로 확인할 수 있는 봇입니다.

## 설치 방법

### 1. 필수 라이브러리 설치
```bash
pip install -r requirements.txt
```

### 2. 환경 변수 설정
`.env.example`을 참고하여 `.env` 파일을 만들고 토큰을 입력하세요:

```bash
cp .env.example .env
```

`.env` 파일에 다음을 입력하세요:
```
DISCORD_TOKEN=your_discord_token_here
WEATHER_API_KEY=your_weather_api_key_here
```

### 3. 토큰 발급

#### 디스코드 토큰
1. [Discord Developer Portal](https://discord.com/developers/applications)에 접속
2. "New Application" 클릭
3. 앱 이름 입력 후 생성
4. "Bot" 탭에서 "Add Bot" 클릭
5. "TOKEN" 아래 "Copy" 클릭 → `.env`에 붙여넣기
6. "OAuth2" → "URL Generator"에서 `bot` 스코프와 필요한 권한(메시지 읽기, 메시지 보내기, 임베드 링크 등) 선택
7. 생성된 URL로 봇을 서버에 초대

#### OpenWeatherMap API 키
1. [OpenWeatherMap](https://openweathermap.org/api)에 접속
2. 회원가입 및 로그인
3. API 키 발급
4. `.env`에 입력

## 사용 방법

### 봇 실행
```bash
python bot.py
```

### 명령어

- `!서울날씨` - 서울의 현재 날씨 조회
- `!핑` - 봇의 응답 시간 확인

## 예시

```
사용자: !서울날씨
봇: ☀️ 서울 날씨
맑음
🌡️ 온도: 25°C
🤔 체감온도: 24°C
💧 습도: 60%
💨 풍속: 3.5 m/s
```

## 기능
- 🌡️ 온도, 체감온도 조회
- 💧 습도 정보
- 💨 풍속 정보
- 🎨 보기 좋은 임베드 형식의 메시지
