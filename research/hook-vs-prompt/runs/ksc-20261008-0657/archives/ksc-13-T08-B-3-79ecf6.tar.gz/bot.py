import discord
from discord.ext import commands
import requests
import os
from dotenv import load_dotenv

load_dotenv()

# 설정
DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')
WEATHER_API_KEY = os.getenv('WEATHER_API_KEY')
WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/weather"

# 봇 설정
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user}가 로그인했습니다.')

@bot.command(name='날씨')
async def weather(ctx):
    """서울 날씨를 조회합니다."""
    try:
        params = {
            'q': 'Seoul',
            'appid': WEATHER_API_KEY,
            'units': 'metric',
            'lang': 'ko'
        }

        response = requests.get(WEATHER_API_URL, params=params)
        response.raise_for_status()
        data = response.json()

        # 날씨 정보 추출
        temp = data['main']['temp']
        feels_like = data['main']['feels_like']
        humidity = data['main']['humidity']
        description = data['weather'][0]['description']
        wind_speed = data['wind']['speed']

        # 임베드 메시지 생성
        embed = discord.Embed(
            title='🌤️ 서울 날씨',
            color=discord.Color.blue()
        )
        embed.add_field(name='현재 온도', value=f'{temp}°C', inline=False)
        embed.add_field(name='체감 온도', value=f'{feels_like}°C', inline=True)
        embed.add_field(name='습도', value=f'{humidity}%', inline=True)
        embed.add_field(name='날씨', value=description.capitalize(), inline=False)
        embed.add_field(name='바람 속도', value=f'{wind_speed} m/s', inline=False)

        await ctx.send(embed=embed)

    except requests.exceptions.RequestException as e:
        await ctx.send(f'❌ 날씨 정보를 가져올 수 없습니다: {e}')
    except KeyError:
        await ctx.send('❌ API 응답 형식이 잘못되었습니다.')
    except Exception as e:
        await ctx.send(f'❌ 오류 발생: {e}')

if __name__ == '__main__':
    if not DISCORD_TOKEN:
        print('오류: DISCORD_TOKEN이 설정되지 않았습니다.')
    else:
        bot.run(DISCORD_TOKEN)
