# 서울 날씨 Discord 봇

서울의 실시간 날씨 정보를 Discord에서 확인할 수 있는 봇입니다.

## 설치 방법

### 1. 필수 라이브러리 설치
```bash
pip install -r requirements.txt
```

### 2. 설정 파일 생성
`.env.example`을 `.env`로 복사하고 토큰을 입력합니다.
```bash
cp .env.example .env
```

### 3. 토큰 설정

#### Discord 봇 토큰 얻기
1. [Discord Developer Portal](https://discord.com/developers/applications)에 접속
2. "New Application" 클릭하여 앱 생성
3. "Bot" 탭에서 "Add Bot" 클릭
4. "TOKEN" 섹션에서 토큰 복사
5. `.env` 파일의 `DISCORD_TOKEN`에 붙여넣기

#### OpenWeatherMap API 키 얻기
1. [OpenWeatherMap](https://openweathermap.org/api)에 접속
2. 회원가입 (무료)
3. API 키 생성
4. `.env` 파일의 `WEATHER_API_KEY`에 붙여넣기

### 4. 봇 권한 설정
1. Developer Portal에서 "OAuth2" → "URL Generator" 이동
2. Scopes: `bot` 선택
3. Permissions: `Send Messages`, `Embed Links` 선택
4. 생성된 URL을 브라우저에서 열어 서버에 봇 초대

## 사용 방법

봇이 실행되면 Discord에서 다음 명령어 사용:

```
!날씨
```

봇이 현재 서울의 날씨 정보를 표시합니다.

## 구성 요소

- `bot.py`: 메인 봇 코드
- `requirements.txt`: 필요한 라이브러리
- `.env`: API 토큰 설정 (보안상 Git에 커밋하면 안 됨)
- `.env.example`: 설정 파일 예시

## 실행

```bash
python bot.py
```

## 표시되는 정보

- 현재 온도
- 체감 온도
- 습도
- 날씨 상태
- 바람 속도
