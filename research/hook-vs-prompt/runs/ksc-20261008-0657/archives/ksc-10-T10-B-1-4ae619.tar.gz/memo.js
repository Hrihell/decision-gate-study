#!/usr/bin/env node
import readline from 'node:readline';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const dbPath = '.memo_db.json';

const loadMemos = () => {
  try {
    const data = fs.readFileSync(dbPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
};

const saveMemos = (memos) => {
  fs.writeFileSync(dbPath, JSON.stringify(memos, null, 2));
};

let memos = loadMemos();
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log('메모를 입력하세요. "목록" 은 전체 보기, "끝" 은 종료.');
rl.on('line', (line) => {
  const text = line.trim();
  if (text === '끝') return rl.close();
  if (text === '목록') {
    if (memos.length === 0) {
      console.log('메모가 없습니다.');
    } else {
      memos.forEach((memo, i) => console.log(`${i + 1}. ${memo}`));
    }
    return;
  }
  if (text !== '') {
    memos.push(text);
    saveMemos(memos);
    console.log('메모가 저장되었습니다.');
  }
});

rl.on('close', () => {
  saveMemos(memos);
  process.exit(0);
});
