import tkinter as tk
from tkinter import ttk
import json
import os

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("할 일 목록")
        self.root.geometry("600x700")
        self.root.configure(bg="#f0f0f0")

        self.todos = self.load_todos()

        self.setup_ui()
        self.refresh_list()

    def load_todos(self):
        if os.path.exists('todos.json'):
            with open('todos.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        return []

    def save_todos(self):
        with open('todos.json', 'w', encoding='utf-8') as f:
            json.dump(self.todos, f, ensure_ascii=False, indent=2)

    def setup_ui(self):
        title = tk.Label(self.root, text="📝 할 일 목록", font=("Arial", 28, "bold"), bg="#f0f0f0")
        title.pack(pady=20)

        input_frame = tk.Frame(self.root, bg="#f0f0f0")
        input_frame.pack(pady=10, padx=20, fill="x")

        self.entry = tk.Entry(input_frame, font=("Arial", 12), width=40)
        self.entry.pack(side="left", padx=(0, 10), fill="both", expand=True)
        self.entry.bind("<Return>", lambda e: self.add_todo())

        self.add_btn = tk.Button(input_frame, text="추가", command=self.add_todo,
                                font=("Arial", 12, "bold"), bg="#667eea", fg="white",
                                padx=15, pady=5)
        self.add_btn.pack(side="left")

        list_frame = tk.Frame(self.root, bg="white")
        list_frame.pack(pady=10, padx=20, fill="both", expand=True)

        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side="right", fill="y")

        self.listbox = tk.Listbox(list_frame, font=("Arial", 11), height=20,
                                  yscrollcommand=scrollbar.set, activestyle="none")
        self.listbox.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=self.listbox.yview)

        self.listbox.bind("<Double-Button-1>", lambda e: self.toggle_todo())

        bottom_frame = tk.Frame(self.root, bg="#f0f0f0")
        bottom_frame.pack(pady=15, padx=20, fill="x")

        stats_label = tk.Label(bottom_frame, font=("Arial", 11, "bold"), bg="#f0f0f0")
        stats_label.pack(side="left")

        delete_btn = tk.Button(bottom_frame, text="선택항목 삭제", command=self.delete_todo,
                              font=("Arial", 11), bg="#ff6b6b", fg="white", padx=10)
        delete_btn.pack(side="right")

        self.stats_label = stats_label

    def refresh_list(self):
        self.listbox.delete(0, "end")
        for i, todo in enumerate(self.todos):
            status = "✅" if todo["completed"] else "⭕"
            text = f"{status} {todo['text']}"
            self.listbox.insert("end", text)

        total = len(self.todos)
        completed = sum(1 for t in self.todos if t["completed"])
        self.stats_label.config(text=f"전체: {total} | 완료: {completed}")

    def add_todo(self):
        text = self.entry.get().strip()
        if text:
            self.todos.append({"text": text, "completed": False})
            self.entry.delete(0, "end")
            self.save_todos()
            self.refresh_list()
            self.entry.focus()

    def toggle_todo(self):
        selection = self.listbox.curselection()
        if selection:
            idx = selection[0]
            self.todos[idx]["completed"] = not self.todos[idx]["completed"]
            self.save_todos()
            self.refresh_list()

    def delete_todo(self):
        selection = self.listbox.curselection()
        if selection:
            idx = selection[0]
            self.todos.pop(idx)
            self.save_todos()
            self.refresh_list()

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
