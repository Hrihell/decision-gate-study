window.addEventListener('DOMContentLoaded', () => {
  // Preload script - can add IPC communication here if needed
});
