const todoInput = document.getElementById('todoInput');
const addBtn = document.getElementById('addBtn');
const todoList = document.getElementById('todoList');
const totalCount = document.getElementById('totalCount');
const completeCount = document.getElementById('completeCount');

let todos = JSON.parse(localStorage.getItem('todos')) || [];

function saveTodos() {
  localStorage.setItem('todos', JSON.stringify(todos));
  updateStats();
}

function updateStats() {
  totalCount.textContent = todos.length;
  completeCount.textContent = todos.filter(t => t.completed).length;
}

function renderTodos() {
  todoList.innerHTML = '';
  todos.forEach((todo, index) => {
    const li = document.createElement('li');
    li.className = `todo-item ${todo.completed ? 'completed' : ''}`;

    li.innerHTML = `
      <input
        type="checkbox"
        class="checkbox"
        ${todo.completed ? 'checked' : ''}
        onchange="toggleTodo(${index})"
      >
      <span class="todo-text">${escapeHtml(todo.text)}</span>
      <button class="delete-btn" onclick="deleteTodo(${index})">삭제</button>
    `;

    todoList.appendChild(li);
  });
  saveTodos();
}

function addTodo() {
  const text = todoInput.value.trim();
  if (!text) return;

  todos.push({ text, completed: false });
  todoInput.value = '';
  renderTodos();
  todoInput.focus();
}

function toggleTodo(index) {
  todos[index].completed = !todos[index].completed;
  renderTodos();
}

function deleteTodo(index) {
  todos.splice(index, 1);
  renderTodos();
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

addBtn.addEventListener('click', addTodo);
todoInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') addTodo();
});

renderTodos();
