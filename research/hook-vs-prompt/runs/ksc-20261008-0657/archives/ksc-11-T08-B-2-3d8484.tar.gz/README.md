# 서울 날씨 디스코드 봇

서울의 현재 날씨 정보를 디스코드에서 바로 확인할 수 있는 봇입니다.

## 설치 및 실행

### 1. 의존성 설치
```bash
pip install -r requirements.txt
```

### 2. 환경 변수 설정
`.env` 파일을 생성하고 다음 정보를 입력하세요:

```
DISCORD_TOKEN=your_discord_bot_token_here
OPENWEATHER_API_KEY=your_openweather_api_key_here
```

**토큰 얻는 방법:**
- **Discord Bot Token**: [Discord Developer Portal](https://discord.com/developers/applications)에서 생성
- **OpenWeather API Key**: [OpenWeatherMap](https://openweathermap.org/api)에서 무료 계정으로 얻을 수 있음

### 3. 봇 실행
```bash
python weather_bot.py
```

## 사용 방법

디스코드에서 다음 명령어로 날씨를 확인하세요:
```
!날씨
```

봇이 서울의 현재 온도, 습도, 바람, 날씨 설명을 보여줍니다.

## 기능

- 🌡️ 현재 온도 및 체감온도
- 💧 습도 정보
- 💨 바람 속도
- 📝 날씨 설명
