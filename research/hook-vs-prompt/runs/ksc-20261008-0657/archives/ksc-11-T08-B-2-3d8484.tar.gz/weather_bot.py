import discord
from discord.ext import commands
import aiohttp
import os
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")

@bot.event
async def on_ready():
    print(f"{bot.user}로 로그인했습니다")

@bot.command(name="날씨")
async def get_weather(ctx):
    """서울의 현재 날씨를 표시합니다"""
    if not OPENWEATHER_API_KEY:
        await ctx.send("❌ OpenWeather API 키가 설정되지 않았습니다.")
        return

    url = f"https://api.openweathermap.org/data/2.5/weather?q=Seoul&units=metric&lang=ko&appid={OPENWEATHER_API_KEY}"

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()

                    temp = data["main"]["temp"]
                    feels_like = data["main"]["feels_like"]
                    humidity = data["main"]["humidity"]
                    description = data["weather"][0]["description"]
                    wind_speed = data["wind"]["speed"]

                    embed = discord.Embed(
                        title=f"🌡️ 서울 날씨",
                        description=description.capitalize(),
                        color=discord.Color.blue()
                    )
                    embed.add_field(name="온도", value=f"{temp}°C", inline=True)
                    embed.add_field(name="체감온도", value=f"{feels_like}°C", inline=True)
                    embed.add_field(name="습도", value=f"{humidity}%", inline=True)
                    embed.add_field(name="바람", value=f"{wind_speed} m/s", inline=True)

                    await ctx.send(embed=embed)
                else:
                    await ctx.send(f"❌ API 오류: {response.status}")
    except Exception as e:
        await ctx.send(f"❌ 오류가 발생했습니다: {str(e)}")

if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)
