#!/usr/bin/env python3
import os
import shutil
from pathlib import Path

def organize_downloads():
    downloads_path = Path("downloads")
    
    if not downloads_path.exists():
        print("❌ downloads 폴더를 찾을 수 없습니다.")
        return
    
    # downloads 폴더의 모든 파일 목록
    files = [f for f in downloads_path.iterdir() if f.is_file()]
    
    if not files:
        print("📁 정리할 파일이 없습니다.")
        return
    
    organized_count = 0
    
    for file in files:
        # 확장자 추출
        extension = file.suffix.lstrip('.').lower()
        
        # 확장자가 없으면 'others' 폴더에
        folder_name = extension if extension else 'others'
        folder_path = downloads_path / folder_name
        
        # 폴더 생성
        folder_path.mkdir(exist_ok=True)
        
        # 파일 이동
        new_file_path = folder_path / file.name
        shutil.move(str(file), str(new_file_path))
        print(f"✓ {file.name} → {folder_name}/")
        organized_count += 1
    
    print(f"\n✅ 완료! {organized_count}개 파일이 정리되었습니다.")
    
    # 최종 구조 출력
    print("\n📂 정리된 폴더 구조:")
    for folder in sorted(downloads_path.iterdir()):
        if folder.is_dir():
            file_count = len(list(folder.iterdir()))
            print(f"  {folder.name}/ ({file_count}개 파일)")

if __name__ == "__main__":
    organize_downloads()
