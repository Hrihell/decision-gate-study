const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function setCurrentUser(email) {
  localStorage.setItem(CURRENT_USER_KEY, email);
}

function clearCurrentUser() {
  localStorage.removeItem(CURRENT_USER_KEY);
}

function getTodosKey(email) {
  return `todos_${email}`;
}

function loadTodos() {
  const user = getCurrentUser();
  if (!user) return [];
  return JSON.parse(localStorage.getItem(getTodosKey(user)) || '[]');
}

function saveTodos(todos) {
  const user = getCurrentUser();
  if (user) {
    localStorage.setItem(getTodosKey(user), JSON.stringify(todos));
  }
}

function signup(email, password, confirmPassword) {
  const error = document.getElementById('signup-error');
  error.textContent = '';

  if (!email || !password || !confirmPassword) {
    error.textContent = '모든 필드를 입력해 주세요';
    return;
  }

  if (password !== confirmPassword) {
    error.textContent = '비밀번호가 일치하지 않습니다';
    return;
  }

  if (password.length < 4) {
    error.textContent = '비밀번호는 최소 4자 이상이어야 합니다';
    return;
  }

  const users = getUsers();
  if (users[email]) {
    error.textContent = '이미 가입된 이메일입니다';
    return;
  }

  users[email] = { password };
  saveUsers(users);

  alert('회원가입이 완료되었습니다!');
  document.getElementById('signup-email').value = '';
  document.getElementById('signup-password').value = '';
  document.getElementById('signup-confirm').value = '';
  document.getElementById('login-tab').click();
}

function login(email, password) {
  const error = document.getElementById('login-error');
  error.textContent = '';

  if (!email || !password) {
    error.textContent = '이메일과 비밀번호를 입력해 주세요';
    return;
  }

  const users = getUsers();
  if (!users[email] || users[email].password !== password) {
    error.textContent = '이메일 또는 비밀번호가 잘못되었습니다';
    return;
  }

  setCurrentUser(email);
  showTodoApp();
}

function logout() {
  clearCurrentUser();
  document.getElementById('login-email').value = '';
  document.getElementById('login-password').value = '';
  document.getElementById('login-error').textContent = '';
  showAuthScreen();
}

function showAuthScreen() {
  document.getElementById('auth-section').classList.add('active');
  document.getElementById('todo-section').classList.add('hidden');
}

function showTodoApp() {
  document.getElementById('auth-section').classList.remove('active');
  document.getElementById('todo-section').classList.remove('hidden');
  document.getElementById('current-user').textContent = getCurrentUser();
  renderTodos(loadTodos());
}

function renderTodos(todos) {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(next);
      renderTodos(next);
    });
    list.appendChild(item);
  });
}

document.getElementById('login-tab').addEventListener('click', () => {
  document.getElementById('login-form').style.display = 'block';
  document.getElementById('signup-form').style.display = 'none';
  document.getElementById('login-tab').classList.add('active');
  document.getElementById('signup-tab').classList.remove('active');
});

document.getElementById('signup-tab').addEventListener('click', () => {
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('signup-form').style.display = 'block';
  document.getElementById('signup-tab').classList.add('active');
  document.getElementById('login-tab').classList.remove('active');
});

document.getElementById('login-btn').addEventListener('click', () => {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  login(email, password);
});

document.getElementById('signup-btn').addEventListener('click', () => {
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;
  const confirm = document.getElementById('signup-confirm').value;
  signup(email, password, confirm);
});

document.getElementById('logout-btn').addEventListener('click', logout);

document.getElementById('add-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const input = document.getElementById('new-todo');
  if (input.value.trim() === '') return;
  const next = [...loadTodos(), { text: input.value.trim(), done: false }];
  saveTodos(next);
  renderTodos(next);
  input.value = '';
});

if (getCurrentUser()) {
  showTodoApp();
} else {
  showAuthScreen();
}
