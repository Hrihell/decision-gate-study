import Head from 'next/head';
import Link from 'next/link';
import { GetStaticProps, GetStaticPaths } from 'next';
import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { marked } from 'marked';

interface PostProps {
  title: string;
  date: string;
  content: string;
}

export default function BlogPost({ title, date, content }: PostProps) {
  return (
    <>
      <Head>
        <title>{title} - My Blog</title>
        <meta name="description" content={`Read ${title}`} />
      </Head>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-3xl mx-auto px-4 py-12">
          <Link href="/">
            <div className="text-blue-600 font-medium mb-6 cursor-pointer hover:text-blue-700">
              ← Back to home
            </div>
          </Link>

          <article className="bg-white p-8 rounded-lg shadow-lg">
            <header className="mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                {title}
              </h1>
              <p className="text-gray-500">{date}</p>
            </header>

            <div
              className="prose prose-sm max-w-none text-gray-700 leading-relaxed"
              dangerouslySetInnerHTML={{ __html: content }}
            />
          </article>
        </div>
      </div>
    </>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  const postsDirectory = path.join(process.cwd(), 'posts');
  const filenames = fs.readdirSync(postsDirectory);

  const paths = filenames
    .filter((filename) => filename.endsWith('.md'))
    .map((filename) => ({
      params: {
        slug: filename.replace(/\.md$/, ''),
      },
    }));

  return {
    paths,
    fallback: false,
  };
};

export const getStaticProps: GetStaticProps<PostProps> = async ({ params }) => {
  const { slug } = params as { slug: string };
  const postsDirectory = path.join(process.cwd(), 'posts');
  const filePath = path.join(postsDirectory, `${slug}.md`);
  const fileContents = fs.readFileSync(filePath, 'utf8');
  const { data, content } = matter(fileContents);

  const htmlContent = await marked(content);

  return {
    props: {
      title: data.title || 'Untitled',
      date: data.date || 'No date',
      content: htmlContent,
    },
    revalidate: 60,
  };
};
