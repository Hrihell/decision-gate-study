export interface Post {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
}

export const posts: Post[] = [
  {
    id: '1',
    title: 'Welcome to My Blog',
    excerpt: 'This is my first blog post about getting started with Next.js.',
    content: `
      # Welcome to My Blog

      This is my first blog post! I'm excited to share my thoughts and ideas with you.

      ## Why I Started This Blog

      I wanted to create a platform to share my knowledge and experiences with the world.
      This blog is built with Next.js, React, and Tailwind CSS.

      ## What to Expect

      - Regular posts about web development
      - Tutorials and guides
      - Thoughts on the latest technologies

      Stay tuned for more content!
    `,
    date: '2024-01-15',
    author: 'John Doe',
  },
  {
    id: '2',
    title: 'Getting Started with Next.js',
    excerpt: 'Learn the basics of Next.js and how to build modern web applications.',
    content: `
      # Getting Started with Next.js

      Next.js is a powerful React framework that makes it easy to build modern web applications.

      ## Key Features

      - Server-side rendering
      - Static site generation
      - API routes
      - Built-in optimization

      ## Getting Started

      To get started with Next.js, you can use create-next-app to scaffold a new project.

      Next.js makes building web applications fun and efficient!
    `,
    date: '2024-01-20',
    author: 'John Doe',
  },
  {
    id: '3',
    title: 'Tailwind CSS Tips and Tricks',
    excerpt: 'Discover useful tips and tricks for using Tailwind CSS effectively.',
    content: `
      # Tailwind CSS Tips and Tricks

      Tailwind CSS is a utility-first CSS framework that helps you build beautiful websites quickly.

      ## Tip 1: Use Arbitrary Values

      Tailwind CSS allows you to use arbitrary values for customization.

      ## Tip 2: Optimize Your Build

      Make sure to configure your tailwind.config.js properly to optimize your build size.

      ## Tip 3: Use Responsive Modifiers

      Tailwind CSS makes it easy to create responsive designs with responsive modifiers.

      Happy styling!
    `,
    date: '2024-01-25',
    author: 'Jane Smith',
  },
];

export function getAllPosts(): Post[] {
  return posts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export function getPostById(id: string): Post | undefined {
  return posts.find(post => post.id === id);
}
