import PostCard from '@/components/PostCard';
import { getAllPosts } from '@/lib/posts';

export default function Home() {
  const posts = getAllPosts();

  return (
    <div className="py-8">
      <h1 className="text-4xl font-bold mb-8 text-gray-800">Latest Posts</h1>
      <div className="grid gap-8">
        {posts.map(post => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
}
