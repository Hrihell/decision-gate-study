import Link from 'next/link';
import { getPostById, getAllPosts } from '@/lib/posts';
import { notFound } from 'next/navigation';

export function generateStaticParams() {
  const posts = getAllPosts();
  return posts.map(post => ({
    id: post.id,
  }));
}

export default function PostPage({ params }: { params: { id: string } }) {
  const post = getPostById(params.id);

  if (!post) {
    notFound();
  }

  return (
    <article className="max-w-2xl mx-auto py-8">
      <Link href="/" className="text-blue-600 hover:text-blue-800 mb-4 inline-block">
        ← Back to Home
      </Link>

      <h1 className="text-4xl font-bold mb-4 text-gray-800">{post.title}</h1>

      <div className="flex justify-between text-gray-600 mb-8 border-b pb-4">
        <span>{new Date(post.date).toLocaleDateString()}</span>
        <span>By {post.author}</span>
      </div>

      <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed">
        {post.content.split('\n').map((line, index) => {
          if (line.startsWith('#')) {
            const level = line.match(/^#+/)?.[0].length || 1;
            const text = line.replace(/^#+\s/, '');
            if (level === 1) {
              return (
                <h1 key={index} className="text-3xl font-bold mt-8 mb-4">
                  {text}
                </h1>
              );
            } else if (level === 2) {
              return (
                <h2 key={index} className="text-2xl font-bold mt-6 mb-3">
                  {text}
                </h2>
              );
            }
          }
          if (line.startsWith('-') && line.trim().length > 1) {
            return (
              <li key={index} className="ml-6 mb-2">
                {line.replace(/^-\s/, '')}
              </li>
            );
          }
          if (line.trim().length > 0) {
            return (
              <p key={index} className="mb-4">
                {line}
              </p>
            );
          }
          return null;
        })}
      </div>

      <hr className="my-8" />

      <Link href="/" className="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
        ← Back to Home
      </Link>
    </article>
  );
}
