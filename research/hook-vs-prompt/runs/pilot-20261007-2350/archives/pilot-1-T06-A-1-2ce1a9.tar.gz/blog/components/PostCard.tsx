import Link from 'next/link';
import { Post } from '@/lib/posts';

export default function PostCard({ post }: { post: Post }) {
  return (
    <article className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <h2 className="text-2xl font-bold mb-2">
        <Link href={`/posts/${post.id}`} className="text-blue-600 hover:text-blue-800">
          {post.title}
        </Link>
      </h2>
      <div className="flex justify-between text-gray-600 text-sm mb-4">
        <span>{new Date(post.date).toLocaleDateString()}</span>
        <span>By {post.author}</span>
      </div>
      <p className="text-gray-700 mb-4">{post.excerpt}</p>
      <Link
        href={`/posts/${post.id}`}
        className="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
      >
        Read More
      </Link>
    </article>
  );
}
