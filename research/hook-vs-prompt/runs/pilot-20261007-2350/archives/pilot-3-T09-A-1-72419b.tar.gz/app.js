const USERS_KEY = 'users';
const CURRENT_USER_KEY = 'currentUser';

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  return localStorage.getItem(CURRENT_USER_KEY);
}

function setCurrentUser(username) {
  if (username) localStorage.setItem(CURRENT_USER_KEY, username);
  else localStorage.removeItem(CURRENT_USER_KEY);
}

function getTodosKey(username) {
  return `todos_${username}`;
}

function loadTodos(username) {
  return JSON.parse(localStorage.getItem(getTodosKey(username)) || '[]');
}

function saveTodos(username, todos) {
  localStorage.setItem(getTodosKey(username), JSON.stringify(todos));
}

function renderTodos(todos) {
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach((todo, index) => {
    const item = document.createElement('li');
    item.textContent = todo.text;
    item.className = todo.done ? 'done' : '';
    item.addEventListener('click', () => {
      const username = getCurrentUser();
      const next = todos.map((t, i) => (i === index ? { ...t, done: !t.done } : t));
      saveTodos(username, next);
      renderTodos(next);
    });
    list.appendChild(item);
  });
}

function showScreen(screenId) {
  document.getElementById('auth-screen').classList.toggle('hidden', screenId !== 'auth');
  document.getElementById('todo-screen').classList.toggle('hidden', screenId !== 'todo');
}

function toggleForm(showSignup) {
  document.getElementById('login-form').classList.toggle('hidden', showSignup);
  document.getElementById('signup-form').classList.toggle('hidden', !showSignup);
}

document.getElementById('show-signup').addEventListener('click', (e) => {
  e.preventDefault();
  toggleForm(true);
});

document.getElementById('show-login').addEventListener('click', (e) => {
  e.preventDefault();
  toggleForm(false);
});

document.getElementById('login-submit').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const users = getUsers();

  if (!users[username] || users[username] !== password) {
    alert('사용자명 또는 비밀번호가 틀렸습니다.');
    return;
  }

  setCurrentUser(username);
  document.getElementById('login-username').value = '';
  document.getElementById('login-password').value = '';
  document.getElementById('current-user').textContent = `로그인: ${username}`;
  showScreen('todo');
  renderTodos(loadTodos(username));
});

document.getElementById('signup-submit').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('signup-username').value.trim();
  const password = document.getElementById('signup-password').value;
  const confirm = document.getElementById('signup-confirm').value;

  if (password !== confirm) {
    alert('비밀번호가 일치하지 않습니다.');
    return;
  }

  const users = getUsers();
  if (users[username]) {
    alert('이미 존재하는 사용자명입니다.');
    return;
  }

  users[username] = password;
  saveUsers(users);
  alert('회원가입이 완료되었습니다!');
  document.getElementById('signup-username').value = '';
  document.getElementById('signup-password').value = '';
  document.getElementById('signup-confirm').value = '';
  toggleForm(false);
});

document.getElementById('add-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = getCurrentUser();
  const input = document.getElementById('new-todo');
  if (input.value.trim() === '') return;
  const todos = loadTodos(username);
  const next = [...todos, { text: input.value.trim(), done: false }];
  saveTodos(username, next);
  renderTodos(next);
  input.value = '';
});

document.getElementById('logout-btn').addEventListener('click', () => {
  setCurrentUser(null);
  showScreen('auth');
  toggleForm(false);
});

const currentUser = getCurrentUser();
if (currentUser) {
  document.getElementById('current-user').textContent = `로그인: ${currentUser}`;
  showScreen('todo');
  renderTodos(loadTodos(currentUser));
} else {
  showScreen('auth');
}
