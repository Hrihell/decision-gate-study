export interface Post {
  id: number
  slug: string
  title: string
  date: string
  excerpt: string
  content: string
  author: string
}

export const posts: Post[] = [
  {
    id: 1,
    slug: 'welcome-to-my-blog',
    title: 'Welcome to My Blog',
    date: '2024-10-07',
    excerpt: 'This is the first post on my new Next.js blog. I am excited to share my thoughts and experiences with you!',
    author: 'Admin',
    content: `
# Welcome to My Blog

This is my first blog post! I've created this blog using Next.js, a modern React framework.

## Why Next.js?

Next.js provides:
- Server-side rendering for better performance
- Static generation for fast page loads
- API routes for backend functionality
- Excellent developer experience

I'm excited to share my journey and insights with you. Stay tuned for more posts!
    `,
  },
  {
    id: 2,
    slug: 'getting-started-with-nextjs',
    title: 'Getting Started with Next.js',
    date: '2024-10-06',
    excerpt: 'Learn how to set up your first Next.js project and create dynamic pages with routing.',
    author: 'Admin',
    content: `
# Getting Started with Next.js

Next.js makes it easy to build modern web applications. Here's how to get started:

## Installation

Install Next.js with create-next-app:

\`\`\`bash
npx create-next-app@latest
\`\`\`

## File-Based Routing

One of the best features of Next.js is file-based routing. Simply create files in the app directory and they automatically become routes.

## Learn More

Visit the official Next.js documentation to learn more about advanced features.
    `,
  },
  {
    id: 3,
    slug: 'tailwindcss-for-styling',
    title: 'Tailwind CSS for Styling',
    date: '2024-10-05',
    excerpt: 'Discover how to use Tailwind CSS to build beautiful and responsive user interfaces quickly.',
    author: 'Admin',
    content: `
# Tailwind CSS for Styling

Tailwind CSS is a utility-first CSS framework that helps you build modern designs without leaving your HTML.

## Key Benefits

- **Rapid Development**: Build interfaces quickly with pre-defined utility classes
- **Customizable**: Extend and customize every aspect of the framework
- **Responsive Design**: Built-in responsive design utilities
- **Small File Size**: Only include the CSS you use

## Example

With Tailwind, you can style elements directly in your JSX using utility classes:

\`\`\`jsx
<button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
  Click me
</button>
\`\`\`

This creates a beautiful, responsive button without writing any custom CSS!
    `,
  },
  {
    id: 4,
    slug: 'react-hooks-guide',
    title: 'Understanding React Hooks',
    date: '2024-10-04',
    excerpt: 'A comprehensive guide to React Hooks and how they simplify state management and side effects.',
    author: 'Admin',
    content: `
# Understanding React Hooks

React Hooks are functions that let you use state and other React features in functional components.

## Common Hooks

### useState
Manage state in your component:

\`\`\`jsx
const [count, setCount] = useState(0)
\`\`\`

### useEffect
Perform side effects like fetching data:

\`\`\`jsx
useEffect(() => {
  // Your code here
}, [dependencies])
\`\`\`

### useContext
Access context values without prop drilling

## Benefits

- Simpler component logic
- Better code reuse
- Easier to test and maintain

Learn more about hooks in the React documentation!
    `,
  },
  {
    id: 5,
    slug: 'building-a-blog-with-nextjs',
    title: 'Building a Blog with Next.js',
    date: '2024-10-03',
    excerpt: 'Step-by-step guide to building a fully functional blog using Next.js and dynamic routing.',
    author: 'Admin',
    content: `
# Building a Blog with Next.js

Creating a blog with Next.js is straightforward and allows you to leverage modern web technologies.

## Key Features

1. **Dynamic Routing**: Use \`[slug]\` to create dynamic routes for each blog post
2. **Static Generation**: Generate blog posts at build time for optimal performance
3. **Responsive Design**: Use Tailwind CSS for beautiful, mobile-friendly layouts
4. **Fast Performance**: Next.js optimizes images and code splitting automatically

## File Structure

\`\`\`
app/
├── posts/
│   ├── page.tsx (all posts)
│   └── [slug]/page.tsx (individual post)
\`\`\`

## Getting Posts

Store your posts in a data file and fetch them dynamically:

\`\`\`tsx
import { posts } from '@/data/posts'

export default function Posts() {
  return (
    <div>
      {posts.map(post => (
        <div key={post.id}>
          <h2>{post.title}</h2>
          <p>{post.excerpt}</p>
        </div>
      ))}
    </div>
  )
}
\`\`\`

That's it! You now have a working blog.
    `,
  },
]
