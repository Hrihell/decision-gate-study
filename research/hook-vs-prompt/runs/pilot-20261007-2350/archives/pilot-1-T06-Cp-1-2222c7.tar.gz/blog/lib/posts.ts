import { posts } from '@/data/posts'

export function getAllPosts() {
  return posts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

export function getPostBySlug(slug: string) {
  return posts.find(post => post.slug === slug)
}

export function getPostSlugs() {
  return posts.map(post => post.slug)
}
