'use client'

import Link from 'next/link'

export default function Navigation() {
  return (
    <nav className="bg-primary text-white shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold">
            My Blog
          </Link>
          <div className="space-x-6">
            <Link href="/" className="hover:text-gray-300 transition">
              Home
            </Link>
            <Link href="/posts" className="hover:text-gray-300 transition">
              Posts
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}
