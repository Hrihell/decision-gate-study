export default function Footer() {
  return (
    <footer className="bg-primary text-white mt-12">
      <div className="max-w-6xl mx-auto px-4 py-8 text-center">
        <p>&copy; {new Date().getFullYear()} My Blog. All rights reserved.</p>
        <p className="text-gray-400 text-sm mt-2">Built with Next.js and Tailwind CSS</p>
      </div>
    </footer>
  )
}
