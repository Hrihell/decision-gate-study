const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const db = new sqlite3.Database(':memory:');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

db.serialize(() => {
  db.run(`
    CREATE TABLE users (
      id INTEGER PRIMARY KEY,
      username TEXT UNIQUE,
      password TEXT,
      name TEXT
    )
  `);

  db.run(`
    CREATE TABLE books (
      id INTEGER PRIMARY KEY,
      owner_id INTEGER,
      title TEXT,
      author TEXT,
      description TEXT,
      borrowed_by INTEGER,
      borrowed_at TEXT,
      created_at TEXT,
      FOREIGN KEY(owner_id) REFERENCES users(id),
      FOREIGN KEY(borrowed_by) REFERENCES users(id)
    )
  `);
});

function getCurrentUser(req) {
  const userId = req.cookies.userId;
  if (!userId) return null;
  return new Promise((resolve) => {
    db.get('SELECT * FROM users WHERE id = ?', [userId], (err, user) => {
      resolve(user);
    });
  });
}

app.get('/', async (req, res) => {
  const user = await getCurrentUser(req);
  db.all(`
    SELECT b.*, u.name as owner_name
    FROM books b
    JOIN users u ON b.owner_id = u.id
    WHERE b.borrowed_by IS NULL
  `, (err, books) => {
    res.render('index', { user, books: books || [] });
  });
});

app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', (req, res) => {
  const { username, password, name } = req.body;
  db.run(
    'INSERT INTO users (username, password, name) VALUES (?, ?, ?)',
    [username, password, name],
    function(err) {
      if (err) {
        return res.render('register', { error: '이미 존재하는 계정입니다.' });
      }
      res.redirect('/login');
    }
  );
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get(
    'SELECT * FROM users WHERE username = ? AND password = ?',
    [username, password],
    (err, user) => {
      if (!user) {
        return res.render('login', { error: '로그인 정보가 올바르지 않습니다.' });
      }
      res.cookie('userId', user.id);
      res.redirect('/');
    }
  );
});

app.get('/logout', (req, res) => {
  res.clearCookie('userId');
  res.redirect('/');
});

app.get('/add_book', async (req, res) => {
  const user = await getCurrentUser(req);
  if (!user) return res.redirect('/login');
  res.render('add_book', { user });
});

app.post('/add_book', async (req, res) => {
  const user = await getCurrentUser(req);
  if (!user) return res.redirect('/login');

  const { title, author, description } = req.body;
  db.run(
    'INSERT INTO books (owner_id, title, author, description, created_at) VALUES (?, ?, ?, ?, datetime("now"))',
    [user.id, title, author, description],
    () => res.redirect('/')
  );
});

app.get('/book/:id', async (req, res) => {
  const user = await getCurrentUser(req);
  db.get(
    'SELECT b.*, u.name as owner_name, u2.name as borrower_name FROM books b JOIN users u ON b.owner_id = u.id LEFT JOIN users u2 ON b.borrowed_by = u2.id WHERE b.id = ?',
    [req.params.id],
    (err, book) => {
      res.render('book_detail', { user, book });
    }
  );
});

app.post('/book/:id/borrow', async (req, res) => {
  const user = await getCurrentUser(req);
  if (!user) return res.redirect('/login');

  db.run(
    'UPDATE books SET borrowed_by = ?, borrowed_at = datetime("now") WHERE id = ?',
    [user.id, req.params.id],
    () => res.redirect('/mybooks')
  );
});

app.post('/book/:id/return', async (req, res) => {
  const user = await getCurrentUser(req);
  if (!user) return res.redirect('/login');

  db.run(
    'UPDATE books SET borrowed_by = NULL, borrowed_at = NULL WHERE id = ?',
    [req.params.id],
    () => res.redirect('/mybooks')
  );
});

app.get('/mybooks', async (req, res) => {
  const user = await getCurrentUser(req);
  if (!user) return res.redirect('/login');

  db.all(
    'SELECT * FROM books WHERE owner_id = ? ORDER BY created_at DESC',
    [user.id],
    (err, owned) => {
      db.all(
        'SELECT b.*, u.name as owner_name FROM books b JOIN users u ON b.owner_id = u.id WHERE b.borrowed_by = ? ORDER BY borrowed_at DESC',
        [user.id],
        (err, borrowed) => {
          res.render('mybooks', { user, owned: owned || [], borrowed: borrowed || [] });
        }
      );
    }
  );
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
